<?php
require 'vendor/autoload.php';  // Load PHPSpreadsheet
require 'db.php';  // Database connection

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Fetch Data from nipas_table
$sql = "SELECT * FROM nipas_table";
$result = $conn->query($sql);

// Create Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

if ($result->num_rows > 0) {
    // Get column names
    $columns = array_keys($result->fetch_assoc());
    $result->data_seek(0); // Reset pointer

    // Add Headers
    $colIndex = 1;
    foreach ($columns as $column) {
        $sheet->setCellValueByColumnAndRow($colIndex, 1, $column);
        $colIndex++;
    }

    // Add Data
    $rowIndex = 2;
    while ($row = $result->fetch_assoc()) {
        $colIndex = 1;
        foreach ($columns as $column) {
            $sheet->setCellValueByColumnAndRow($colIndex, $rowIndex, $row[$column]);
            $colIndex++;
        }
        $rowIndex++;
    }
}

// Set Headers for Download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="nipas_data.xlsx"');
header('Cache-Control: max-age=0');

// Save and Download
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
