<?php

session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? ''
];
$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : '';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>DENR LOGIN</title>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
            background: #4DA0B0;  /* fallback for old browsers */
            background: linear-gradient(to top,rgb(116, 199, 156),rgb(81, 155, 68)); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        }
        .logo{
            width:100px;
            height:100px;
            margin-left:170px;
            margin-top:-50px;
        }

        .container {
            margin: 0 15px;
        }
        .form-box {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: none;
        }
        .form-box.active{

            display:block ;
        } 
        h2 {
            font-size: 34px;
            text-align: center;
            margin-bottom: 20px;
        }

        input,
        select{
            width: 100%;
            padding: 12px;
            background: #eee;
            border-radius: 6px;
            border: none;
            outline: none;
            font-size: 16px;
            color: #333;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #33a34d;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color:rgb(255, 255, 255);
            font-weight: 500;
            margin-bottom: 20px;
            transition: 0.5s;
        }
        button:hover {
            background:rgb(42, 172, 81);
        }

        p {
            font-size: 14.5px;
            text-align: center;
            margin-bottom: 10px;
        }

        p a {
            color:rgb(42, 172, 81);
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
        .error-message {
            padding: 12px;
            background: #f8d7da;
            border-radius: 6px;
            font-size: 16px;
            color: #a42834;
            text-align: center;
            margin-bottom: 20px;
        }
        @media only screen and (max-width: 600px) {
        .logo{
            width:100px;
            height:100px;
            margin-left:130px;
            margin-top:-50px;
            }
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
            background-color: #3a6d3b;
            background: linear-gradient(0deg, rgb(21, 109, 43) 0%, rgba(9,121,22,1) 40%, rgb(41, 161, 85) 100%);
            background-repeat: no-repeat;
            background-size: cover;
        }
        }
    </style>

</head>

<body>
    <div class="container">
    <img src="https://upload.wikimedia.org/wikipedia/commons/e/e8/Logo_of_the_Department_of_Environment_and_Natural_Resources.svg" class="logo"></img>
    <h1 style="text-align: center; color: #eee; text-shadow: #333;">DENR CALABARZON</h1>
        <div class="form-box <?= isActiveForm('login', $activeForm);?>"id="login-form">
            <form action="login_register.php" method="post">
                <h2>Login</h2>
                <?= showError($errors['login']); ?>
                <input type="email" name="email" placeholder="Email ex: John@denr.com" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="login">Login</button>
                <p>Don't have an account? <a href="register.php">Register</a></p>
            </form>
        </div>

        <div class="form-box <?= isActiveForm('register', $activeForm);?>" id="register-form">
            <form action="login_register.php" method="post">
                <h2>Register</h2>
                <?= showError($errors['register']); ?>
                <input type="text" name="name" placeholder="Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <select name="role" required>
                    <option value="">--Select Role--</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <button type="submit" name="register">Register</button>
                <p>Already have an account? <a href="#" onclick="showForm('login-form')">Login</a></p>
            </form>
        </div>
    
        </div>
        <script src="script.js"></script>

</body>

</html>