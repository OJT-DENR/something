<?php
require 'db.php';

// Fetch records from the database
$query = "SELECT * FROM nipas_table";

if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    
    if (!empty($search)) { 
        // Search by ID or Received By
        $query = "SELECT * FROM nipas_table WHERE DATS LIKE '%$search%' OR actioned LIKE '%$search%' OR Location LIKE '%$search%'";
    }
}
$result = $conn->query($query);

// Handle Delete All Request
if (isset($_POST['delete_all'])) {
    $conn->query("TRUNCATE TABLE nipas_table"); // Deletes all records and resets auto-increment
    header("Location: updatenipas.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIPAS Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(to bottom, #1f618d 0%, #1d8348 100%);}
        .container { max-width: 100%; margin: auto; background: linear-gradient(to bottom, #1f618d 0%, #1d8348 100%); padding: 20px; border-radius: 8px; }
        .table-container { background-color: black;max-width: fit-content; max-height: 510px; overflow-y: auto; border: 1px solid grey; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; background-color: #1d8348;}
        th, td {  padding: 8px; text-align: center; border: 1px solid #ddd; }
        th { background-color:rgb(0, 0, 0); color: white; }
        .back-btn { border:none;
        border-radius:5px;
        position:top: 100px; right: 120px ;
        font-size: 15px;
        padding: 10px 20px;
        cursor: pointer;
        background:rgb(62, 156, 106);
        width:5%;
        color:white; margin-bottom: 20px;}
    </style>
</head>
<body style="background: linear-gradient(to bottom, #1f618d 0%, #1d8348 100%); background-size: cover;">

<div class="container">
    <h2 class="text-center my-4" style="color:rgb(255, 255, 255); text-shadow: none; font-size: 300%; font-weight: 700;">NIPAS Records</h2>

    <button class="back-btn" onclick="window.location.href='user_page.php';">Back</button>

    <form method="POST" onsubmit="return confirmDeleteAll();" class="mb-3">
        <button type="submit" name="delete_all" class="btn btn-danger" style="margin-left: 90%; margin-top: -120px;">Delete All Data</button>
    </form>

    <!-- Search & Delete Form -->
    <form method="POST" class="mb-3 d-flex" style="margin-top: -30px;">
        <input type="text" name="search" class="form-control me-2" placeholder="Search by ID or actioned By..." value="<?php echo isset($_POST['search']) ? htmlspecialchars($_POST['search']) : ''; ?>">
        <button type="submit" class="btn btn-primary">Search</button>
   
    </form>



    <div class="table-container" style="margin">
        <table class="table table-striped table-bordered text-center">
            <thead class="table-dark">
                <tr >
                    <th style="background-color: rgb(31, 29, 29); color:white;">ID</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">DATS</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Received by</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Dates</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Time</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Originating Office</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Actioned By</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Position</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Applicant Name</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Company</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Owner Representative</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Location</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Barangay</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Municipality</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Province</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">No. of Applied</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">No. of Applied (words)</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Letter</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Contact Person</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Contact No.</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Lot Data</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Approved</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">PSU, PSD, CSD</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Total</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">SPA</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Secretary</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">D.O.S</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Others</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Inspection</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Map Prepared</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Geotagged</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Amount of Payment</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Amount of Payment (Words)</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Findings (Protected & Within)</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Purpose of Application</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Remarks</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Link</th>
                    <th style="background-color: rgb(31, 29, 29); color:white;">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['dats']; ?></td>
                    <td><?php echo $row['received']; ?></td>
                    <td><?php echo $row['date']; ?></td>
                    <td><?php echo $row['time']; ?></td>
                    <td><?php echo $row['originating']; ?></td>
                    <td><?php echo $row['actioned']; ?></td>
                    <td><?php echo $row['position']; ?></td>
                    <td><?php echo $row['applicant']; ?></td>
                    <td><?php echo $row['company']; ?></td>
                    <td><?php echo $row['OwnerRepresentative']; ?></td>
                    <td><?php echo $row['location']; ?></td>
                    <td><?php echo $row['brgy']; ?></td>
                    <td><?php echo $row['municity']; ?></td>
                    <td><?php echo $row['province']; ?></td>
                    <td><?php echo $row['NoApplied']; ?></td>
                    <td><?php echo $row['NoAppword']; ?></td>
                    <td><?php echo $row['LetterTF']; ?></td>
                    <td><?php echo $row['ContactP']; ?></td>
                    <td><?php echo $row['ContactN']; ?></td>
                    <td><?php echo $row['LotData']; ?></td>
                    <td><?php echo $row['approved']; ?></td>
                    <td><?php echo $row['ppc']; ?></td>
                    <td><?php echo $row['total']; ?></td>
                    <td><?php echo $row['spa']; ?></td>
                    <td><?php echo $row['sec']; ?></td>
                    <td><?php echo $row['DoS']; ?></td>
                    <td><?php echo $row['others']; ?></td>
                    <td><?php echo $row['inspect']; ?></td>
                    <td><?php echo $row['map']; ?></td>
                    <td><?php echo $row['geo']; ?></td>
                    <td><?php echo $row['amount']; ?></td>
                    <td><?php echo $row['totalwords']; ?></td>
                    <td><?php echo $row['findings']; ?></td>
                    <td><?php echo $row['purpose']; ?></td>
                    <td><?php echo $row['remarks']; ?></td>
                    <td><?php echo $row['Links']; ?></td>
                    

                       
                        <td>
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id']; ?>">Edit</button><br><br>
                            
                            <a href="certification.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Download NIPAS Certification</a> <br></br>
                            <a href="certmore.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Download NIPAS Certification More Lots</a> <br></br>
                            <a href="assesmentform.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Download Assessment Form</a> <br> <br>
                            <a href="memorandum.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Memoramdum Form</a>
                        </td>
                    </tr>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?= $row['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header" style="background-color: rgb(26, 112, 94); color: white;">
                                    <h5 class="modal-title">Edit Record ID: <?= $row['id']; ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="update1.php" method="POST">
                                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                        
                                        <?php foreach ($row as $key => $value) { 
                                            if ($key !== "id") { ?>
                                                <div class="mb-3">
                                                    <label class="form-label"><?= ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                                                    <input type="text" name="<?= $key; ?>" class="form-control" value="<?= htmlspecialchars($value); ?>">
                                                </div>
                                        <?php } } ?>

                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function confirmDeleteAll() {
    return confirm("Are you sure you want to delete ALL records? This action cannot be undone.");
}
</script>

</body>
</html>

<?php $conn->close(); ?>
