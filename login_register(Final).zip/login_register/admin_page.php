<!DOCTYPE html>
<html>
    
<head>
    
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  padding: 10px;
  background-image: url("https://github.com/OJT-DENR/images/blob/main/Main_Back.png?raw=true");
  background-size:102%, 101%;
  background-position:center;
  background-repeat:no-repeat;
}

/* Header/Blog Title */
.header {
  padding: 10px;
  text-align: center;
  background-image: url("https://github.com/OJT-DENR/images/blob/main/DENR.png?raw=true"), linear-gradient(to bottom right, #229954, #5dade2);
  background-position:center;
  background-size:100%, 400%;
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.32);
  opacity:0.8;
}

.header h1 {
  font-size: 70px;
}


/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.32);
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color:rgb(212, 255, 222);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #f5b7b1;
  color: black;
}

/* Create two unequal columns that floats next to each other */
/* Left column */
.leftcolumn {   
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.32);
  float: left;
  width: 75%;
}

/* Right column */
.rightcolumn {
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.32);
  float: left;
  width: 25%;
  background-color:rgba(214, 255, 226, 0);
  padding-left: 20px;
}

/* Fake image */
.fakeimg {
  background-image:url("https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/a6829201-5fed-4355-ad6a-2613e8d7feca/djafsjf-db31dc46-cbaf-4614-aaa4-f7b36322f014.jpg/v1/fill/w_1024,h_683,q_75,strp/jungle_solitude_iii_by_pbwells_djafsjf-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2E2ODI5MjAxLTVmZWQtNDM1NS1hZDZhLTI2MTNlOGQ3ZmVjYVwvZGphZnNqZi1kYjMxZGM0Ni1jYmFmLTQ2MTQtYWFhNC1mN2IzNjMyMmYwMTQuanBnIiwiaGVpZ2h0IjoiPD02ODMiLCJ3aWR0aCI6Ijw9MTAyNCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS53YXRlcm1hcmsiXSwid21rIjp7InBhdGgiOiJcL3dtXC9hNjgyOTIwMS01ZmVkLTQzNTUtYWQ2YS0yNjEzZThkN2ZlY2FcL3Bid2VsbHMtNC5wbmciLCJvcGFjaXR5Ijo5NSwicHJvcG9ydGlvbnMiOjAuNDUsImdyYXZpdHkiOiJjZW50ZXIifX0.VbWzf7AIdglgrYhp7jtTP4ZciRL7vWmQo99ggZTUL4A");
  background-color: blue;
  width: 100%;
  padding: 20px;
}
.pic {
  background-image:url("https://github.com/OJT-DENR/images/blob/main/DENR.png?raw=true");
  background-color: blue;
  width: 100%;
  padding: 10px;
  
}

/* Add a card effect for articles */
.card {
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.32);
  background-color: white;
  padding: 20px;
  margin-top: 20px;
}

/* Clear floats after the columns */
.row::after {
  content: "";
  display: table;
  clear: both;
}

/* Footer */
.footer {
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.32);
  padding: 20px;
  text-align: center;
  background: #ddd;
  margin-top: 20px;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .topnav a {
    float: none;
    width: 100%;
  }
}
</style>
</head>
<body>
    

<div class="header">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Logo_of_the_Department_of_Environment_and_Natural_Resources.svg/2048px-Logo_of_the_Department_of_Environment_and_Natural_Resources.svg.png" alt="Cinque Terre" width="200" height="200">
  <h1 style="color: white">DENR - Prototype Docu System</h1>
  <p style="color: white">Website built for your database needs.</p>
</div>

<div class="topnav">
  <a href="#">Link</a>

  <a href="javascript:history.back()" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
  
      <h1>PAMB Clearance</h1>
      <h5>Pamb about</h5>
      <div class="fakeimg" style="height:200px;">Image</div>
      <p>Some text..</p>
      <p>Sup bossing, dto mo p0h ilagay yung mga shits para dun sa BAMBI clearance. You heard?</p>
      <div>
      
  <button  style="position:top: 100px; right: 120px ;font-size: 15px; padding: 10px 20px;">PAMB</button>
</form>
</div>
    </div>
    <div class="card">
      <h2>NIPAS Certification</h2>
      <h5>about Nipas</h5>
      <div class="fakeimg" style="height:200px;">Image</div>
      <p>Some text..</p>
      <p>Sup bossing, dto mo p0h ilagay yung mga shits para dun sa BAMBI clearance. You heard?</p>
      <div>
      
  <button  style="position:top: 100px; right: 120px ;font-size: 15px; padding: 10px 20px;">NIPASS</button>
</div>
    </div>
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>About Me</h2>
      <div class="pic" style="height:100px;"></div>
      <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
      
    </div>
    <div class="card">
      <h3>DENR Mission</h3>
      <p>blah blah blah blah blah </p>
      <h3>DENR Vision</h3>
      <p>blah blah blah blah blah </p>
    </div>
    <div class="card">
      <h3>for more info:</h3>
      <a href="https://denr.gov.ph/" >Click me  </a>
    </div>
  </div>
</div>

<div class="footer">
  <h2>Footer</h2>
</div>

</body>
</html>


