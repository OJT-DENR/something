<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "test_db";

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from URL
$id = $_GET['id'];
$sql = "SELECT * FROM users WHERE id = $id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
</head>
<body>
    <h2>Update User Data</h2>
    <form action="update_process.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">

        <label>ID:</label>
        <span style="font-weight: bold;"><?php echo $user['id']; ?></span><br><br>

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $user['name']; ?>" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required><br><br>

        <label for="age">Age:</label>
        <input type="number" id="age" name="age" value="<?php echo $user['age']; ?>" required><br><br>

        <label for="gender">Gender:</label>
        <select id="gender" name="gender" required>
            <option value="Male" <?php if ($user['gender'] == "Male") echo "selected"; ?>>Male</option>
            <option value="Female" <?php if ($user['gender'] == "Female") echo "selected"; ?>>Female</option>
            <option value="Other" <?php if ($user['gender'] == "Other") echo "selected"; ?>>Other</option>
        </select><br><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="<?php echo $user['phone']; ?>" required><br><br>

        <label for="address">Address:</label>
        <textarea id="address" name="address" required><?php echo $user['address']; ?></textarea><br><br>

        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
