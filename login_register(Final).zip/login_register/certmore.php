<?php
require 'vendor/autoload.php'; // Ensure Dompdf is installed
require 'db.php'; // Database connection

use Dompdf\Dompdf;
use Dompdf\Options;

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate ID input
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No valid ID provided.");
}

$id = intval($_GET['id']); // Sanitize ID

// Fetch data from database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if record exists
if ($result->num_rows == 0) {
    die("Error: No record found with ID " . $id);
}

$row = $result->fetch_assoc();

// Fetch necessary data
$LotN1 = isset($row['LotN1']) ? htmlspecialchars($row['LotN1']) : 'N/A';
$LotN2 = isset($row['LotN2']) ? htmlspecialchars($row['LotN2']) : 'N/A';
$LotN3 = isset($row['LotN3']) ? htmlspecialchars($row['LotN3']) : 'N/A';
$LotN4 = isset($row['LotN4']) ? htmlspecialchars($row['LotN4']) : 'N/A';
$LotN5 = isset($row['LotN5']) ? htmlspecialchars($row['LotN5']) : 'N/A';
$LotN6 = isset($row['LotN6']) ? htmlspecialchars($row['LotN6']) : 'N/A';
$TCT1 = isset($row['TCT1']) ? htmlspecialchars($row['TCT1']) : 'N/A';
$TCT2 = isset($row['TCT2']) ? htmlspecialchars($row['TCT2']) : 'N/A';
$TCT3 = isset($row['TCT3']) ? htmlspecialchars($row['TCT3']) : 'N/A';
$TCT4 = isset($row['TCT4']) ? htmlspecialchars($row['TCT4']) : 'N/A';
$TCT5 = isset($row['TCT5']) ? htmlspecialchars($row['TCT5']) : 'N/A';
$TCT6 = isset($row['TCT6']) ? htmlspecialchars($row['TCT6']) : 'N/A';
$Area1 = isset($row['Area1']) ? htmlspecialchars($row['Area1']) : 'N/A';
$Area2 = isset($row['Area2']) ? htmlspecialchars($row['Area2']) : 'N/A';
$Area3 = isset($row['Area3']) ? htmlspecialchars($row['Area3']) : 'N/A';
$Area4 = isset($row['Area4']) ? htmlspecialchars($row['Area4']) : 'N/A';
$Area5 = isset($row['Area5']) ? htmlspecialchars($row['Area5']) : 'N/A';
$Area6 = isset($row['Area6']) ? htmlspecialchars($row['Area6']) : 'N/A';
$applicant = isset($row['applicant']) ? htmlspecialchars($row['applicant']) : 'N/A';
$purpose = isset($row['purpose']) ? htmlspecialchars($row['purpose']) : 'N/A';
$amount = isset($row['amount']) ? htmlspecialchars($row['amount']) : 'N/A';
$totalwords = isset($row['totalwords']) ? htmlspecialchars($row['totalwords']) : 'N/A';

$Area_sqm2 = isset($row['Area_sqm2']) ? htmlspecialchars($row['Area_sqm2']) : 'N/A';
$Area_sqm3 = isset($row['Area_sqm3']) ? htmlspecialchars($row['Area_sqm3']) : 'N/A';
$findings = isset($row['findings']) ? htmlspecialchars($row['findings']) : 'N/A';
$location = isset($row['location']) ? htmlspecialchars($row['location']) : 'N/A';
$noapplied = isset($row['NoApplied']) ? htmlspecialchars($row['NoApplied']) : 'N/A';




$areas = [];
$tcts = [];
$lotNumbers = []; // Store Lot Numbers
$totalArea = 0.0000; // Default total to 4 decimal places


// Fetch all columns from the database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Error: No record found.");
}

// Loop through dynamically (up to $noapplied)
for ($i = 1; $i <= $noapplied; $i++) {
    $lotKey = "LotN" . $i;
    $tctKey = "TCT" . $i;
    $areaKey = "Area" . $i;

    // Validate Lot Number field
    $lotNumbers[] = !empty($row[$lotKey]) ? htmlspecialchars($row[$lotKey]) : "N/A";

    // Validate TCT field
    $tcts[] = !empty($row[$tctKey]) ? htmlspecialchars($row[$tctKey]) : "N/A";

    // Validate Area field
    if (is_numeric($row[$areaKey])) {
        $areaValue = floatval($row[$areaKey]); // Convert to float
        $areas[] = $areaValue; // Store the value
        $totalArea += $areaValue; // Add to total
    } else {
        $areas[] = 0.0000; // Default if invalid
    }
}

// Initialize table HTML
// Initialize table HTML
$tableHTML = "";

if ($noapplied > 1) {
    $tableHTML .= '<table border="1" cellspacing="0" cellpadding="0" style="width: 95%; line-height: 0.6; border-collapse: collapse; font-size: 16px; text-align: center; margin-left:20px;">';

    // Table Header
    $tableHTML .= "<tr style='font-weight: bold;'>
                    <th style='width: 70%;'>Lot No.</th>
                    <th style='width: 80%;'>TCT No.</th>
                    <th style='width: 30%;'>Area (ha)</th>
                   </tr>";

    // Loop through all applied lots
    foreach ($areas as $index => $areaValue) {
        $tableHTML .= "<tr>
                      <td>" . $lotNumbers[$index] . "</td>
                       <td>" . $tcts[$index] . "</td>
                        <td>" . number_format($areaValue / 10000, 4) . "</td>
                       </tr>";
    }

    // Total Row
    $tableHTML .= "<tr style='font-weight: bold;'>
                    <td colspan='2' style='text-align:right; padding-right:15px;'>TOTAL</td>
                    <td style='text-align:center;'>" . number_format($totalArea / 10000, 4) . "</td>
                   </tr>";

    $tableHTML .= '</table>';
} else {
    $tableHTML .= '<p style="font-weight: bold; text-align: center; margin-top:10px;">No table. You have only 1 or no lots.</p>';
}









// Dompdf options
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);
$backgroundImage = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/Legal.png";
$dompdf = new Dompdf($options);

$backgroundImage2 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI_Header2.png";
$backgroundImage3 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI_Footer.png";


//padding body: top, right, bottom, left
// Start HTML generation
$html = '

        

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        @page { size: Legal; margin: 100px 0px 80px 0px; }

        body {
            line-height: 1.1;
            font-family: "Times New Roman", serif;
            font-size: 16px;
            padding: 0px 60px 100px 70px;
            text-align: justify;
            margin-left:-10px;
        }

        .header-content {
            position: fixed;
            top: -90px; /* also relative to margin */
            left: 0;
            right: 0;
            height: 110px;
            background: url("' . $backgroundImage2 . '") no-repeat;
            background-size: cover;
        }

        .footer-content {
            position: fixed;
            bottom: -80px; /* also relative to margin */
            left: 0;
            right: 0;
            height: 100px;
            background: url("' . $backgroundImage3 . '") no-repeat;
            background-size: cover;
        }

        .content { font-size: 16px; line-height: 1.2; }
        h2, h4 { text-align: center; font-weight: bold; }
        .approved-section2 { text-align: center; line-height: 0.9; margin-left: 285px; }
        table {
        width: 50%;
        border-collapse: collapse;
        font-size: 18px; /* Same as body text */
        text-align: center;
    }
    th, td {
        border: 1px solid black;
        padding: 8px;
        font-size: 16px; /* Ensures table text matches body font size */
    }
    .underline {
        border-bottom: 1px solid black;
        display: inline-block;
        width: 100px;
    }
    .underline2 {
        border-bottom: 1px solid black;
        display: inline-block;
        width: 120px;
    }
    .signature {
    
        text-align: center;
        margin-top: 40px;
        margin-right: 230px;
    }
    </style>
</head>
<body >
            <div class="header-content" style="background-color: red;"></div>
            <div class="footer-content" style="background-color: blue;"></div>


    <div class="content" style="margin-left:40px; margin-right:50px;">
        <p></p>
        <p></p>
        <h2>CERTIFICATION</h2>
        <h4 style="margin-top:-20px;">NIPAS Certification No. <span class="underline"></span></h4>

        <p><strong>TO WHOM IT MAY CONCERN:</strong></p>
        <p style="text-indent:40px;">
            This is to certify that based on the verification made by this Office, the following lots located at '.$location.' with an area of <strong> '.  number_format($totalArea/10000, 4) . ' hectares 
            </strong> are '.$findings.'</strong>.
        </p>

        <!-- Display table or message -->
        <div>' . $tableHTML . '</div>

        <p style="text-indent:40px;">
            This Certification is issued in accordance with the provision of DAO No. 2022-10, otherwise known as the Revised DENR Manual of Authorities 
            on Technical Matters, and as requested by <strong>' . $applicant . '</strong>,'.$findings.' for the purpose of <strong>' . $purpose . '</strong>.
        </p>

        <p style="margin-top:20px; text-indent:40px;">
            A verification fee amounting to <strong>'.$totalwords.' (<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>' . $amount . ')</strong> was paid under  
            <strong>OR No.</strong> <span class="underline2"></span> dated <span class="underline2"></span>.
        </p>

        <p style="margin-top:32px; text-indent:40px;">
            Issued this day of <strong><span class="underline2"></span></strong> at Mayapa Main Road, along SLEX, Brgy. Mayapa, Calamba City, Laguna.
        </p>
        <p></p>
        <div class="approved-section2">
            <p style="margin-top:0px;"><strong>NILO B. TAMORIA</strong>, <em>CESO III</em> <br>Regional Executive Director</p>
        </div>

        <p>Recommending Approval:</p>

        <div class="signature">
            <p style="margin-top:-5px;"><strong>ERIBERTO B. SAÑOS</strong>, <em>CESE</em> <br>OIC-Assistant Regional Director <br> for Technical Services</p>
        </div>
    </div>
</body>
</html>';

// Load HTML to Dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('Legal', 'portrait');
$dompdf->render();

// Force file download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="NIPAS_Certification_' . $applicant . '.pdf"');
echo $dompdf->output();

exit;
?>
