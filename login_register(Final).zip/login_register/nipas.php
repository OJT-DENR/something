<?php
 //Database connection
 $host = "localhost"; 
 $user = "root"; // Default username for localhost
 $password = ""; // Default password is empty
 $dbname = "nipas_db"; // Your database name

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

 //Get next auto-increment ID for `nipas_table`
$sql = "SHOW TABLE STATUS LIKE 'nipas_table'";
$result = $conn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
  $next_id = $row['Auto_increment']; // Get the next auto-increment ID
} else {
  $next_id = 1; // Default to 1 if query fails
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIPAS Form</title>
    <script>
          function showFieldGroups() {
        const noApplied = parseInt(document.querySelector('[name="NoApplied"]').value) || 0;

        for (let i = 1; i <= 10; i++) {
            const group = document.getElementById(`group${i}`);
            if (i <= noApplied) {
                group.style.display = "block";
            } else {
                group.style.display = "none";
                // Optionally clear values when hiding
                group.querySelectorAll("input").forEach(input => input.value = '');
            }
        }

        countFilledFields(); // Optional: update count display too
    }

    document.addEventListener("DOMContentLoaded", () => {
        const noAppliedInput = document.querySelector('[name="NoApplied"]');
        noAppliedInput.addEventListener("input", showFieldGroups);
    });
    function countFilledFields() {
        let count = 0;
        for (let i = 1; i <= 10; i++) {
            let tct = document.querySelector(`[name="TCT${i}"]`).value.trim();
            let lot = document.querySelector(`[name="LotN${i}"]`).value.trim();
            let area = document.querySelector(`[name="Area${i}"]`).value.trim();
            if (tct && lot && area) count++;
        }

        const noApplied = parseInt(document.querySelector('[name="NoApplied"]').value) || 0;
        const status = document.getElementById("filledStatus");

        if (count >= noApplied) {
            status.textContent = `✅ ${count} / ${noApplied} entries filled.`;
            status.style.color = "green";
        } else {
            status.textContent = `⚠️ ${count} / ${noApplied} entries filled. Please complete all.`;
            status.style.color = "red";
        }
    }

    function setupFieldListeners() {
        const fields = document.querySelectorAll('[name^="TCT"], [name^="LotN"], [name^="Area"], [name="NoApplied"]');
        fields.forEach(field => {
            field.addEventListener("input", countFilledFields);
        });
    }

    document.addEventListener("DOMContentLoaded", setupFieldListeners);
</script>
    <style>
        body {
            font-family: sans-serif;
            background: linear-gradient(to bottom, #1f618d 0%, #1d8348 100%);
            padding: 40px;
        }
        .container {
            width: auto;
            border: 13px solid rgb(26, 112, 94);
            border-radius: 25px;
            box-shadow: 0 0 10px rgb(5, 26, 23);
            background: linear-gradient(to bottom, #dad299 0%, #b0dab9 90%);
            padding: 30px;
            border-radius: 25px;
            max-width: 50%;
            margin: auto;
        }
        h1 { text-align: center; }
        label { font-weight: bold; display: block; margin-top: 10px; display:inline-block; *display: inline;}

        input { width: 17%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputLink { width: 98.5%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputLocation { width: 82%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputOwner { width: 68.9%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputOrigin { width: 51.5%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputPosition { width: 43.5%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputCompany { width: 41.6%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        .inputApp { width: 26.4%; padding: 8px; margin-top: 5px; border-radius: 5px; }

        textarea { width: 98.5%; padding: 8px; margin-top: 5px; border-radius: 5px; border: 2px solid black;}

        button {
            background-color: black;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            color: #fff;
            background:rgb(145, 146, 147);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
        }

        .btn:hover {
            opacity: 0.9;
            transform: scale(1.05);

        }

        .TrueFalseStyle{ width: 15%; padding: 8px; margin-top: 5px; border-radius: 5px; border: solid black, 2px;}

        .btn.buttonPDF{
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            
            background:rgb(26, 112, 94);
            border: 3px solid black;
            border-radius: 20px;
            border-color:rgb(30, 74, 85);

            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
            height: fit-content;
            width: fit-content;
            font-weight: 500;
        }
        .divBorder{
            padding-left: 10px;
            padding-right: 15px;
            border:3px solid black;
            border-radius: 15px;
            border-color:rgb(255, 255, 255);
        }
        .divID{
            padding-left: 10px;
            padding-right: 15px;
            border:none;
            border-radius: 15px;
            text-align: left;
            font-size: 200%;
        }
    </style>
</head>
<body>
<a href="user_page.php" class="btn buttonPDF">< Back</a>
<p></p>
<p></p>

    <div class="container">
        
        <form action="submit2.php" method="POST">
            
                
            <p style="margin-top: -20px;"></p>

            <div class="divBorder">
                <h1>NIPAS Form</h1>

                <div class="divID">
                    
                    <label>ID:</label>
                    <span><b><?php echo $next_id; ?></b></span>
                    <input type="hidden" name="id" value="<?php echo $next_id; ?>">
                </div>
                <br>
                
                <label>&nbsp;&nbsp;DATS:</label>
                <input type="text" name="dats">
                
                <label> &nbsp;&nbsp; Receive:</label>
                <input type="text" name="Received">

            
                <label>&nbsp;&nbsp;Date:</label>
                <input type="text" name="Date" >
                
                <br><br>

                <label>&nbsp;&nbsp;Time:</label>
                <input type="text" name="Time" >

                <label>&nbsp;&nbsp;&nbsp; Originating:</label>
                <input type="text" name="Originating" class="inputOrigin">

                <br><br>

                <label>&nbsp;&nbsp;Actioned by:&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </label>
                <input type="text" name="actioned" >

                <label>&nbsp;&nbsp;&nbsp;Position:</label>
                <input type="text" name="position" class="inputPosition">

                <br><br>
                
                <label>&nbsp;&nbsp;Applicant Name:</label>
                <input type="text" name="Applicant" >
                
                <label>&nbsp;&nbsp;&nbsp;Company:</label>
                <input type="text" name="Company" class="inputCompany">

                <br><br>

                <label>&nbsp;&nbsp;Owner Representative:</label>
                <input type="text" name="OwnerRepresentative" class="inputOwner">

                <br><br>

                <label>&nbsp; Location: &nbsp;&nbsp;</label>
                <input type="text" name="Location" class="inputLocation">

                <br><br>
                
                <label> &nbsp; BRGY:</label>
                <input type="text" name="BRGY" >
                
                <label> &nbsp;&nbsp; City:</label>
                <input type="text" name="MuniCity" >
                
                <label> &nbsp;&nbsp; Province:</label>
                <input type="text" name="Province" >
                <br><br>
            </div>

            <br><br>

        <div class="divBorder">
        <br>
        <p style="text-align:center; font-size: large;" > <strong> REQUIRMENTS </strong></p>
        
            <label>No Applied:</label>
            <input type="text" name="NoApplied" class="inputApp">
            <p id="filledStatus" style="font-weight:bold; font-size: 14px; color: red;"></p>

            
            <label>No Applied (words):</label>
            <input type="text" name="NoAppword" >

            <br><br>

            <label>Letter:</label>
            <select name="LetterTF" id="LetterTF" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <label>&nbsp;&nbsp; &nbsp;&nbsp; ContactP:</label>
            <input type="text" name="ContactP" >
            
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ContactN:</label>
            <input type="text" name="ContactN" >

            <br><br>
            <div style="border: 3px solid rgb(255, 255, 255); border-radius: 15px; background-color:rgba(214, 235, 208, 0.34);">
            <p style="text-align:center; font-size: large;" > <strong> No. Applied fill-up form: </strong></p>
            <br>
            <div class="tct-group" id="group1" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT1" placeholder="TCT 1">
            <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN1" placeholder="Lot Number 1">
            <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area1" placeholder="Area (ha) 1">
            <br><br>
            </div>
            <div class="tct-group" id="group2" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT2" placeholder="TCT 2">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN2" placeholder="Lot Number 2">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area2" placeholder="Area (ha) 2">
            <br><br>
            </div>
            <div class="tct-group" id="group3" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT3" placeholder="TCT 3">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN3" placeholder="Lot Number 1">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area3" placeholder="Area (ha) 1">
            <br><br>
            </div>
            <div class="tct-group" id="group4" style="display:none;">
            <label>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TCT:</label>
            <input type="text" name="TCT4" placeholder="TCT 4">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN4" placeholder="Lot Number 4">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area4" placeholder="Area (ha) 4">
            <br><br>
            </div>
            <div class="tct-group" id="group5" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT5" placeholder="TCT 5">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN5" placeholder="Lot Number 5">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area5" placeholder="Area (ha) 5">
            <br><br>
            </div>
            <div class="tct-group" id="group6" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT6" placeholder="TCT 6">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN6" placeholder="Lot Number 6">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area6" placeholder="Area (ha) 6">
            <br><br>
            </div>
            <div class="tct-group" id="group7" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT7" placeholder="TCT 7">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN7" placeholder="Lot Number 7">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area7" placeholder="Area (ha) 7">
            <br><br>
            </div>
            <div class="tct-group" id="group8" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT8" placeholder="TCT 8">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN8" placeholder="Lot Number 8">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area8" placeholder="Area (ha) 8">
            <br><br>
            </div>
            <div class="tct-group" id="group9" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT9" placeholder="TCT 9">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN9" placeholder="Lot Number 9">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area9" placeholder="Area (ha) 9">
            <br><br>
            </div>
            <div class="tct-group" id="group10" style="display:none;">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
            <input type="text" name="TCT10" placeholder="TCT 10">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
            <input type="text" name="LotN10" placeholder="Lot Number 10">
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
            <input type="text" name="Area10" placeholder="Area (ha) 10">
            <br><br>
            </div>
            </div>
            <br><br>

            
            <label>LotData:</label>
            <input type="text" name="LotData" >

            <label> &nbsp;&nbsp;&nbsp;Approved:</label>

            <select name="Approved" id="Approved" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <label> &nbsp;&nbsp;&nbsp; PSU/PSD/CSD</label>
            <input type="text" name="PPC" >

            <br><br>

            <label>Total: &nbsp;&nbsp;&nbsp; </label>
            <input type="text" name="Total" >

            <label> &nbsp;&nbsp;&nbsp; SPA:</label>

            <select name="SPA" id="SPA" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
            
            <label> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;  &nbsp; Secretary:</label>

            <select name="Sec" id="Sec" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
            <br><br>
            <label>Deed of Sale:</label>

            <select name="DoS" id="DoS" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
        
            <label> &nbsp;&nbsp;Others:</label>
            <input type="text" name="Others" >

            <label> &nbsp;&nbsp;Inspection:</label>

            <select name="Inspect" id="Inspect" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <br><br>
            
            <label>Map Prep:</label>

            <select name="Map" id="Map" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Geotagged Photos:</label>

            <select name="geo" id="geo" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <br><br>
        </div>

        <br><br>

        <div class="divBorder">
        <br><br>

            <label>Amount:</label>
            <input type="text" name="Amount" >

            <label>Total Words:</label>
            <input type="text" name="TotalWords" >
            <br><br>
            <label>Findings (Protected & Within):</label><br><br>
            <textarea name="Findings" ></textarea>
            <br><br>
            <label>Purpose:</label><br><br>
            <textarea name="Purpose" ></textarea>
            <br><br>
            <label>Remarks:</label><br><br>
            <textarea name="Remarks" ></textarea>

            <br><br>

            <label>Link:</label>
            <br><br>
            <input type="text" name="links" class="inputLink">
            <br><br>
        </div>
            <button type="submit">Submit</button>
        </form>
        
    </div>
</body>
</html>
