<?php
require 'vendor/autoload.php'; // Ensure Dompdf is installed
require 'db.php'; // Database connection

use Dompdf\Dompdf;
use Dompdf\Options;

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate ID input
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No valid ID provided.");
}

$id = intval($_GET['id']); // Sanitize ID

// Fetch data from database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if record exists
if ($result->num_rows == 0) {
    die("Error: No record found with ID " . $id);
}

$row = $result->fetch_assoc();

// Newly added database fields
$noapplied = isset($row['NoApplied']) ? htmlspecialchars($row['NoApplied']) : 'N/A';
$TCT1 = isset($row['TCT1']) ? htmlspecialchars($row['TCT1']) : 'N/A';
$applicant = isset($row['applicant']) ? htmlspecialchars($row['applicant']) : 'N/A';
$purpose = isset($row['purpose']) ? htmlspecialchars($row['purpose']) : 'N/A';
$amount = isset($row['amount']) ? htmlspecialchars($row['amount']) : 'N/A';
$totalwords = isset($row['totalwords']) ? htmlspecialchars($row['totalwords']) : 'N/A';
$Area1 = isset($row['Area1']) ? htmlspecialchars($row['Area1']) : 'N/A';
$findings = isset($row['findings']) ? htmlspecialchars($row['findings']) : 'N/A';
$location = isset($row['location']) ? htmlspecialchars($row['location']) : 'N/A';
// Dompdf options
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true); // Allow external images
$backgroundImage = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMB_Updated_HeaderFooter.png";
$backgroundImage2 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Header.png";
$backgroundImage3 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Footer.png";
$dompdf = new Dompdf($options);


$areas = [];
$tcts = [];
$lotNumbers = []; // Store Lot Numbers
$totalArea = 0.0000; // Default total to 4 decimal places

if (!$row) {
    die("Error: No record found.");
}

// Loop through dynamically (up to $noapplied)
for ($i = 1; $i <= $noapplied; $i++) {
    $lotKey = "LotN" . $i;
    $tctKey = "TCT" . $i;
    $areaKey = "Area" . $i;

    // Validate Lot Number field
    $lotNumbers[] = !empty($row[$lotKey]) ? htmlspecialchars($row[$lotKey]) : "N/A";

    // Validate TCT field
    $tcts[] = !empty($row[$tctKey]) ? htmlspecialchars($row[$tctKey]) : "N/A";

    // Validate Area field
    if (is_numeric($row[$areaKey])) {
        $areaValue = floatval($row[$areaKey]); // Convert to float
        $areas[] = $areaValue; // Store the value
        $totalArea += $areaValue; // Add to total
    } else {
        $areas[] = 0.0000; // Default if invalid
    }
}

// Define HTML content with proper data
//padding body: top, right, bottom, left
$html = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
    @page { 
            size: A4; 
            margin: 100px 0px 80px 0px;
                    

           }

        body {
            line-height: 1.1;
            font-family: "Times New Roman", serif;
            font-size: 16px;
            padding: 0px 20px 100px 70px; 
            text-align: justify;
            
            
        }
        .header-content {
            position: fixed;
            top: -100px; /* also relative to margin */
            left: 0;
            right: 0;
            height: 122px;
            background: url("' . $backgroundImage2 . '") no-repeat;
            background-size: cover;
        }

        .footer-content {
            position: fixed;
            bottom: -80px; /* also relative to margin */
            left: 0;
            right: 0;
            height: 100px;
            background: url("' . $backgroundImage3 . '") no-repeat;
            background-size: cover;
        }

        .content {
            padding-right:30px;
            font-size: 16px;
            line-height: 1.2;
        }

        .content2 {
            padding-right:30px;
            font-size: 16px;
            line-height: 1.2;
        }

        Cert{
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            
        }
        NOM{
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            margin-top:-20px;
        }
        .signature {
            text-align: center;
            margin-top: 40px;
            margin-right: 230px;
        }
        .underline {
            border-bottom: 1px solid black;
            display: inline-block;
            width: 150px;
        }
        .underline1 {
            border-bottom: 1px solid black;
            display: inline-block;
            width: 100px;
        }
        .marginTop{
            margin-top:-20px;
        }
        .approved-section2 {
            text-align: center;
            line-height: 0.9;
            display: flex;
            align-items: flex-end; /* Aligns content to the right */
            flex-direction: column;
             /* Ensures text is aligned to the right */
            margin-left: 285px; /* Adjust as needed */
        }
        span {
            content: "\20B1";
            }

        .marginLow{
            text-align:center;
            margin-top:-20px;
        }
        .marginLow2{
            text-align:center;
            margin-top:-20px;
            margin-bottom:-3px;
        }

        .PuntaRight{
        text-align:right;
        margin-bottom:-20px;
        }    
    </style>
</head>
<body>
            <div class="header-content" style="background-color: red;"></div>
            <div class="footer-content" style="background-color: blue;"></div>
            
<br>
    <div class="content" style="margin-top:30px; margin-left:20px; margin-right:30px;">
    <p>
        <h2 style="text-align: center;
            font-weight: bold;">CERTIFICATION</h2>
        <h5 style="text-align: center;
            font-weight: bold;
            font-size: 16px; margin-top:-20px;">NIPAS Certification No. <span class="underline1"></span></h5>

        <p><strong>TO WHOM IT MAY CONCERN:</strong></p>

        <p style="text-indent:40px;">
            This is to certify that based on the verification made by this Office, <strong> Lot ' .$noapplied. '</strong> covered by
            <strong> TCT No. ' . $TCT1 . '</strong> located at <strong>' . $location . '</strong> with an area of <strong>'. number_format($totalArea/10000, 4) . ' hectares</strong> 
            is <strong>'.$findings.'</strong>.
        </p>

        <p style="text-indent:40px;">
            This Certification is issued in accordance with the provision of DAO No. 2022-10, otherwise known as the Revised DENR Manual of Authorities 
            on Technical Matters, and as requested by <strong>' . $applicant . '</strong>, for the purpose of <strong>' . $purpose . '</strong>.
        </p>

        <p style="margin-top:20px; text-indent:40px;">
            A verification fee amounting to <strong>' . $totalwords . ' (<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>' . $amount . ')</strong> was paid under  
            <strong>OR No.</strong> <span class="underline"></span> 
            dated <span class="underline"></span>.
        </p>

        <p style="margin-top:32px; text-indent:40px;">
            Issued this day of <strong><span class="underline"></span> </strong>at Mayapa Main Road, along SLEX, Brgy. Mayapa, Calamba City, Laguna.
        </p>

        <br><br><br>

        <div class="approved-section2">
            <p><strong>NILO B. TAMORIA</strong>, <em>CESO III</em> <br>
            Regional Executive Director</p>
        </div>

        <p>Recommending Approval:</p>

        <div class="signature">
            <p><strong> ERIBERTO B. SAÑOS</strong>, <em>CESE</em> <br>OIC-Assistant Regional Director <br> for Technical Services</p>
        </div>
    </div>
    

</body>
</html>';

// Load HTML to Dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait'); // Set paper size
$dompdf->render(); // Render PDF

// Force file download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="NIPAS_Certification_' . $applicant . '.pdf"');
echo $dompdf->output();

exit;
?>
