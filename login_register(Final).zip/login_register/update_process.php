<?php
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? null;
    $clearance_no = $_POST['clearance_no'] ?? null;
    $nameofpa = $_POST['NameOfPA'] ?? null;
    $proponent = $_POST['proponent'] ?? null;
    $Purpose = $_POST['Purpose'] ?? null;
    $Resolution_No = $_POST['Resolution_No'] ?? null;
    $Resolution_Title = $_POST['Resolution_Title'] ?? null;
    $PAMB_Meeting_data = $_POST['PAMB_Meeting_data'] ?? null;
    $Description_Title = $_POST['Description_Title'] ?? null;
    $Des_cription = $_POST['Des_cription'] ?? null;
    $Terms_Conditions = $_POST['Terms_Conditions'] ?? null;
    $rest_riction = $_POST['rest_riction'] ?? null;
    $director_name = $_POST['Director_Name'] ?? null;
    $position = $_POST['Position'] ?? null;


    $stmt = $conn->prepare("UPDATE clearance SET 
        clearance_no=?, 
        NameOfPA=?, 
        proponent=?, 
        Purpose=?, 
        Resolution_No=?, 
        Resolution_Title=?, 
        PAMB_Meeting_data=?, 
        Description_Title=?, 
        Des_cription=?, 
        Terms_Conditions=?, 
        rest_riction=? ,
        Director_Name=?,
        Position=?
        WHERE id=?");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssssssssssssi", 
    $clearance_no, $nameofpa, $proponent, $Purpose, $Resolution_No, 
    $Resolution_Title, $PAMB_Meeting_data, $Description_Title, 
    $Des_cription, $Terms_Conditions, $rest_riction, $director_name,$position, $id
);

    if ($stmt->execute()) {
        echo "<script>alert('Record Updated Successfully!'); window.location='PAMBIDATA.php';</script>";
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
