<?php
// Database connection
$host = "localhost";
$user = "root"; // Default username
$password = ""; // Default password is empty
$dbname = "nipas_db"; // Your database name

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data safely
$dats = isset($_POST['dats']) ? $_POST['dats'] : null;
$received = isset($_POST['Received']) ? $_POST['Received'] : null;
$date = isset($_POST['Date']) ? $_POST['Date'] : null;
$time = isset($_POST['Time']) ? $_POST['Time'] : null;
$originating = isset($_POST['Originating']) ? $_POST['Originating'] : null;
$actioned = isset($_POST['actioned']) ? $_POST['actioned'] : null;
$position = isset($_POST['position']) ? $_POST['position'] : null;
$applicant = isset($_POST['Applicant']) ? $_POST['Applicant']: null;
$company = isset($_POST['Company']) ? $_POST['Company'] : null;
$ownerrepresentative = isset($_POST['OwnerRepresentative']) ? $_POST['OwnerRepresentative'] : null;
$location = isset($_POST['Location']) ? $_POST['Location'] : null;
$brgy = isset($_POST['BRGY']) ? $_POST['BRGY'] : null;
$municity = isset($_POST['MuniCity']) ? $_POST['MuniCity'] : null;
$province = isset($_POST['Province']) ? $_POST['Province'] : null;
$noapplied = isset($_POST['NoApplied']) ? $_POST['NoApplied'] : null;
$noappword = isset($_POST['NoAppword']) ? $_POST['NoAppword'] : null;
$lettertf = isset($_POST['LetterTF']) ? $_POST['LetterTF'] : null;
$contactp = isset($_POST['ContactP']) ? $_POST['ContactP'] : null;
$contactn = isset($_POST['ContactN']) ? $_POST['ContactN'] : null;
$tct1 = isset($_POST['TCT1']) ? $_POST['TCT1'] : null;
$tct2 = isset($_POST['TCT2']) ? $_POST['TCT2'] : null;
$tct3 = isset($_POST['TCT3']) ? $_POST['TCT3'] : null;
$tct4 = isset($_POST['TCT4']) ? $_POST['TCT4'] : null;
$tct5 = isset($_POST['TCT5']) ? $_POST['TCT5'] : null;
$tct6 = isset($_POST['TCT6']) ? $_POST['TCT6'] : null;
$tct7 = isset($_POST['TCT7']) ? $_POST['TCT7'] : null;
$tct8 = isset($_POST['TCT8']) ? $_POST['TCT8'] : null;
$tct9 = isset($_POST['TCT9']) ? $_POST['TCT9'] : null;
$tct10 = isset($_POST['TCT10']) ? $_POST['TCT10'] : null;
$LotN1= isset($_POST['LotN1']) ? $_POST['LotN1'] : null;
$LotN2 = isset($_POST['LotN2']) ? $_POST['LotN2'] : null;
$LotN3 = isset($_POST['LotN3']) ? $_POST['LotN3'] : null;
$LotN4= isset($_POST['LotN4']) ? $_POST['LotN4'] : null;
$LotN5 = isset($_POST['LotN5']) ? $_POST['LotN5'] : null;
$LotN6 = isset($_POST['LotN6']) ? $_POST['LotN6'] : null;
$LotN7 = isset($_POST['LotN7']) ? $_POST['LotN7'] : null;
$LotN8= isset($_POST['LotN8']) ? $_POST['LotN8'] : null;
$LotN9 = isset($_POST['LotN9']) ? $_POST['LotN9'] : null;
$LotN10 = isset($_POST['LotN10']) ? $_POST['LotN10'] : null;
$Area1 = isset($_POST['Area1']) ? $_POST['Area1'] : null;
$Area2 = isset($_POST['Area2']) ? $_POST['Area2'] : null;
$Area3 = isset($_POST['Area3']) ? $_POST['Area3'] : null;
$Area4 = isset($_POST['Area4']) ? $_POST['Area4'] : null;
$Area5 = isset($_POST['Area5']) ? $_POST['Area5'] : null;
$Area6 = isset($_POST['Area6']) ? $_POST['Area6'] : null;
$Area7 = isset($_POST['Area7']) ? $_POST['Area7'] : null;
$Area8 = isset($_POST['Area8']) ? $_POST['Area8'] : null;
$Area9 = isset($_POST['Area9']) ? $_POST['Area9'] : null;
$Area10 = isset($_POST['Area10']) ? $_POST['Area10'] : null;
$lotdata = isset($_POST['LotData']) ? $_POST['LotData'] : null;

$approved = isset($_POST['Approved']) ? $_POST['Approved'] : null;
$ppc = isset($_POST['PPC']) ? $_POST['PPC'] : null;

$total = isset($_POST['Total']) ? $_POST['Total'] : null;
$spa = isset($_POST['SPA']) ? $_POST['SPA'] : null;
$sec = isset($_POST['Sec']) ? $_POST['Sec'] : null;
$dos = isset($_POST['DoS']) ? $_POST['DoS'] : null;
$others = isset($_POST['Others']) ? $_POST['Others'] : null;
$inspect = isset($_POST['Inspect']) ? $_POST['Inspect'] : null;
$map = isset($_POST['Map']) ? $_POST['Map'] : null;
$geo = isset($_POST['geo']) ? $_POST['geo'] : null;
$amount = isset($_POST['Amount']) ? $_POST['Amount'] : null;
$totalwords = isset($_POST['TotalWords']) ? $_POST['TotalWords'] : null;
$findings = isset($_POST['Findings']) ? $_POST['Findings'] : null;
$purpose = isset($_POST['Purpose']) ? $_POST['Purpose'] : null;
$remarks = isset($_POST['Remarks']) ? $_POST['Remarks'] : null;
$links = isset($_POST['links']) ? $_POST['links'] :null;

// Prepare and execute SQL statement
$stmt = $conn->prepare("INSERT INTO nipas_table 
    (dats, Received, date, time, originating, actioned,position, Applicant, Company, ownerrepresentative, location, brgy, Municity, province, NoApplied, NoAppword, lettertf, contactp, contactn, tct1,tct2,tct3,tct4,tct5,tct6,tct7,tct8,tct9,tct10, LotN1,LotN2,LotN3,LotN4,LotN5,LotN6,LotN7,LotN8,LotN9,LotN10, Area1,Area2,Area3,Area4,Area5,Area6,Area7,Area8,Area9,Area10, LotData, area_sqm2, approved, ppc, area_sqm3, total, spa, sec, dos, others, inspect, map, geo, amount, TotalWords, findings, purpose, remarks, links) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

$stmt->bind_param("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", 
    $dats, $received, $date, $time, $originating, $actioned, $position , $applicant, $company, $ownerrepresentative, $location, $brgy, $municity, $province, $noapplied, $noappword, $lettertf, $contactp, $contactn, $tct1,$tct2,$tct3,$tct4,$tct5,$tct6,$tct7,$tct8,$tct9,$tct10, $LotN1,$LotN2,$LotN3,$LotN4,$LotN5,$LotN6,$LotN7,$LotN8,$LotN9,$LotN10, $Area1,$Area2,$Area3,$Area4,$Area5,$Area6,$Area7,$Area8,$Area9,$Area10, $lotdata, $area_sqm2, $approved, $ppc, $area_sqm3, $total, $spa, $sec, $dos, $others, $inspect, $map, $geo, $amount, $totalwords, $findings, $purpose, $remarks, $links);

    if ($stmt->execute()) {
        echo "<script>alert('Data saved successfully!'); window.location.href='nipas.php';</script>";
    } else {
        echo "<script>alert('Error: Could not save data.'); window.location.href='form.html';</script>";
    }

$stmt->close();
$conn->close();
?>
