<?php

session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? ''
];
$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : '';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>Full-Stack Login & Register Form With User & Admin Page | Codehal</title>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
            background: #4DA0B0;  /* fallback for old browsers */
            background: linear-gradient(to top,rgb(116, 199, 156),rgb(81, 155, 68)); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        }

        .container {
            margin: 0 15px;
        }
        .form-box {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: none;
        }
        .form-box.active{

            display:block ;
        } 
        h2 {
            font-size: 34px;
            text-align: center;
            margin-bottom: 20px;
        }

        input,
        select{
            width: 100%;
            padding: 12px;
            background: #eee;
            border-radius: 6px;
            border: none;
            outline: none;
            font-size: 16px;
            color: #333;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 12px;
            background:rgb(35, 131, 57);
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color:rgb(255, 255, 255);
            font-weight: 500;
            margin-bottom: 20px;
            transition: 0.5s;
        }
        button:hover {
            background:rgb(42, 172, 81);
        }

        p {
            font-size: 14.5px;
            text-align: center;
            margin-bottom: 10px;
        }

        p a {
            color:rgb(195, 239, 208);
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
        .error-message {
            padding: 12px;
            background: #f8d7da;
            border-radius: 6px;
            font-size: 16px;
            color: #a42834;
            text-align: center;
            margin-bottom: 20px;
        }
        @media only screen and (max-width: 600px) {
        
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
            background-color: #3a6d3b;
            background: linear-gradient(0deg, rgb(21, 109, 43) 0%, rgba(9,121,22,1) 40%, rgb(41, 161, 85) 100%);
            background-repeat: no-repeat;
            background-size: cover;
        }
        h2 {
            font-size: 34px;
            text-align: center;
            margin-bottom: 20px;
            color: whitesmoke;
        }
        button {
            width: 100%;
            padding: 12px;
            background:rgb(67, 194, 96);
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color:rgb(255, 255, 255);
            font-weight: 500;
            margin-bottom: 20px;
            transition: 0.5s;
        }
        }
    </style>

</head>

<body>
    <div class="container">
        <div class id="register-form">
            <form action="login_register.php" method="post">
                <h2 style="color: #eee;">Register</h2>
                <?= showError($errors['register']); ?>
                <input type="text" name="name" placeholder="Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <select name="role">
                    <option value="user">User</option>
                </select>
                <button type="submit" name="register">Register</button>
                <p>Already have an account? <a href="index.php">Login</a></p>
            </form>
        </div>
    
        </div>
        <script src="script.js"></script>

</body>

</html>