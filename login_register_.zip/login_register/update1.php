<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? null;
    
    if (!$id) {
        echo "Error: No ID provided.";
        exit;
    }

    // Collect all POST data except ID
    $columns = array_keys($_POST);
    unset($columns[array_search('id', $columns)]); // Remove ID from column list
    
    $updates = [];
    foreach ($columns as $column) {
        if (!empty($_POST[$column])) {  // Only update if data is provided
            $updates[] = "$column = '" . $conn->real_escape_string($_POST[$column]) . "'";
        }
    }

    if (empty($updates)) {
        // If no fields are updated, just redirect back silently
        header("Location: updatenipas.php");
        exit;
    }

    // Run update query
    $query = "UPDATE nipas_table SET " . implode(", ", $updates) . " WHERE id = $id";
    
    if ($conn->query($query)) {
        header("Location: updatenipas.php?update=success");
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
