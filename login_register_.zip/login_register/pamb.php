<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get next ID (Auto-Increment)
$sql = "SHOW TABLE STATUS LIKE 'clearance'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$next_id = $row['Auto_increment']; // Get next auto-increment ID

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>

        body{
            font-family: sans-serif;
            color: black;
            background: linear-gradient(to bottom,rgb(46, 88, 117) 0%,  #1d8348 100%);
            padding: 20px;
            background-repeat: repeat-y;
        }


        .answer{
                background: linear-gradient(to bottom, #dad299 0%, #b0dab9 90%);
                padding: 30px;
                border-radius: 20px;
        }

        form {
        width: 1200px;
        margin: 10px auto;
        padding: 0px;
        border: 6px solid rgb(26, 112, 94);
        border-radius: 25px;
        box-shadow: 0 0 10px rgb(5, 26, 23);
        }
        
        h1{
            color:black;
        }

        h3{
            color:black;
        }

        label {
        margin-bottom: 5px;
        color:black;
        font-weight: bold ;
        }

        input[type="text"]{
            box-sizing: border-box;
            height:30px;
            border-radius: 6px;
            width:425px;
        }
        

        select {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 2px solid rgb(37, 198, 131);
        border-radius: 4px;
        box-sizing: border-box;
        }

        input[type="textBRGY"]{
            box-sizing: border-box;
            height:30px;
            border-radius: 6px;
            width:200px;
        }

        input[type="PrimaryID"]{
            box-sizing: border-box;
            height:30px;
            border-radius: 6px;
            width:125px;
        }


        input[type="submit"] {
        background-color:rgb(2, 2, 2);
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        }

        .notes {
        text-align:center;
        font-size:25px;
        }

        input[type="submit"]:hover {
        background-color:rgb(152, 163, 152);
        
        }
        input[type="textBRGY"]:hover {
        background-color:rgb(152, 163, 152);
        }
        input[type="text"]:hover {
        background-color:rgb(152, 163, 152);
        }
        textarea [type="text"]:hover {
        background-color:rgb(152, 163, 152);
        }

        textarea {
        resize: none;
        border: 2px solid black;
        border-radius: 15px;
        height: 100px;
        width: 1130px;
        text-align: left;
        background-color: rgb(244, 244, 244);
        
        
        }
        .buttonPDF{
        border:none;
        border-radius:5px;
        position:top: 100px; right: 120px ;
        font-size: 15px;
        padding: 10px 20px;
        cursor: pointer;
        background:rgb(0, 0, 0);
        width:100%;
        color:white;

        }
        
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            
            color:white;

            background:rgb(26, 112, 94);
            border: 3px solid black;
            border-radius: 20px;
            border-color:rgb(30, 74, 85);

            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
            height: fit-content;
            width: fit-content;
            font-weight: 500;
        }
        .btn:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

</style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Form</title>
</head>
<body>

<a href="user_page.php" class="btn">< Back</a>


        <form action="submit.php" method="POST">
        <div class="answer"> <h1>Fill Up the Clearance Form</h1>
        <div>
        </div>
    
   
        <label class="label">ID:</label>
        <span style="font-weight: bold; color: black"><?php echo $next_id; ?></span>
        <input type="hidden" name="id" value="<?php echo $next_id; ?>"><br><br>
        
        
        <label class="label" for="clearance_no">Clearance No: &nbsp;</label>
        <input type="text" id="clearance_no" name="clearance_no" required>

        <label class="label" for="NameOfPA">&nbsp;&nbsp;&nbsp;&nbsp;Name Of PA:</label>
        <input type="text" id="NameOfPA" name="NameOfPA" required><br><br>

        <label class="label" for="proponent">Proponent: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input type="text" id="proponent" name="proponent" required>

        <label class="label" for="Purpose">&nbsp;&nbsp;&nbsp;&nbsp;Purpose: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input type="text" id="Purpose" name="Purpose" required><br><br>

        <label class="label" for="Resolution_No">Resolution No:</label>
        <input type="text" id="Resolution_No" name="Resolution_No" rows="3" cols="50" required></><br><br>

        <label class="label" for="Resolution_Title">Resolution Title:</label><br><br>
        <textarea id="Resolution_Title" name="Resolution_Title" rows="3" cols="50" required></textarea><br><br>
        

        <label class="label" for="PAMB_Meeting_data">PAMB Meeting Date:</label>
        <input type="text"  id="PAMB_Meeting_data" name="PAMB_Meeting_data" rows="3" cols="50" required></input> <br><br><br><br>

        <label class="label" for="Description_Title">Description Title: &nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input type="text" id="Description_Title" name="Description_Title" rows="3" cols="50" required></b><br><br>

        <label class="label" for="Des_cription">Description:</label><br><br>
        <textarea id="Des_cription" name="Des_cription" rows="3" cols="2000" required></textarea><br><br>

        <label class="label" for="Terms_Conditions">Terms and Conditions:</label><br><br>
        <textarea id="Terms_Conditions" name="Terms_Conditions" rows="3" cols="2000" required></textarea><br><br>

        <label class="label" for="rest_riction">Restrictions (Optional):</label><br><br>
        <textarea id="rest_riction" name="rest_riction" rows="3" cols="2000"></textarea><br><br><br><br>

        <label class="label" for="Director_Name">Director:</label>
        <input type="text" id="Director_Name" name="Director_Name" rows="3" cols="50" required></b>

        <label class="label" for="Position">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Position:</label>
        <input type="text" id="Position" name="Position" rows="3" cols="50" required></b><br><br>



        <button class = "buttonPDF" type="submit">Save Database</button>
    </form>

</body>
</html>
