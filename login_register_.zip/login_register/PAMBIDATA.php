<?php
// Connect to MySQL
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default query: Show all records
$query = "SELECT * FROM clearance";

// Search by ID only
if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    
    if (!empty($search)) { 
        // Search by ID or Received By
        $query = "SELECT * FROM Clearance WHERE id LIKE '%$search%' OR proponent LIKE '%$search%' OR Resolution_Title LIKE '%$search%' OR Resolution_No LIKE '%$search%' OR PAMB_Meeting_data LIKE '%$search%'";
    }
}


$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>

        body{
            
            font-family: sans-serif;
            background: linear-gradient(to bottom, #1f618d 0%, #1d8348 100%);
            background-repeat: repeat-x;
            
            }

    .button-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .button-container button {
        padding: 10px 15px;
        font-size: 16px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
    }

    .clear-btn {
        background-color: red;
        color: white;
    }

    .search-btn {
        background-color: blue;
        color: white;
    }

    .back-btn {
        background-color: rgb(62, 156, 106);
        color: white;
    }

    .button-container form {
        margin: 0;
    }
</style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAMB Clearance Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <div class="button-container">
        <!-- Back Button -->
        <button class="back-btn" onclick="window.location.href='user_page.php';">Back</button>
        <!-- Clear All Data Button -->
        <form action="clear.php" method="post">
            <button type="submit" class="clear-btn" onclick="return confirm('Are you sure you want to delete all records and reset IDs?');">
                Clear All Data
            </button>
        </form>
    </div>

    </button>
</form>

    <style>
        body { padding: 20px; }
        table { background-color: white; max-height: 300px;}
        .container { margin-right:50%; max-width: 200%; max-height: 500px;}
    </style>
    
</head>


<body style="background-color: #1d8348;">

<div class="container">
    <h2 class="text-center my-4" style="color:rgb(255, 255, 255); text-shadow: none; font-size: 300%; font-weight: 700;">PAMB Clearance Records</h2>
    <a href="download_all.php" class="btn btn-success mb-3">Download All Records</a>
    <!-- Search Bar (Search by ID Only) -->
    <form method="POST" class="mb-3 d-flex">
        <input type="text" name="search" class="form-control me-2" placeholder="Search by ID..." value="<?php echo isset($_POST['search']) ? htmlspecialchars($_POST['search']) : ''; ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        
    </form>
    

    <!-- Table -->
    <table class="table table-striped table-bordered text-center">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Clearance No.</th>
                <th>Name of PA</th>
                <th>Proponent</th>
                <th>Purpose</th>
                <th>Resolution No.</th>
                <th>Resolution title</th>
                <th>PAMB meeting date</th>
                <th>Description title</th>
                <th>Description</th>
                <th>Terms and Conditions</th>
                <th>Restrictions</th>
                <th>Actions</th>
                
                
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['clearance_no']; ?></td>
                    <td><?php echo $row['NameOfPA']; ?></td>
                    <td><?php echo nl2br($row['proponent']); ?></td>
                    <td><?php echo nl2br($row['Purpose']); ?></td>
                    <td><?php echo nl2br($row['Resolution_No']); ?></td>
                    <td><?php echo nl2br($row['Resolution_Title']); ?></td>
                    <td><?php echo nl2br($row['PAMB_Meeting_data']); ?></td>
                    <td><?php echo nl2br($row['Description_Title']); ?></td>
                    <td><?php echo nl2br($row['Des_cription']); ?></td>
                    <td><?php echo nl2br($row['Terms_Conditions']); ?></td>
                    <td><?php echo nl2br($row['rest_riction']); ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#updateModal<?php echo $row['id']; ?>">Update</button> <br><br>
                        <a href="generate_pdf.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Download PDF</a><br><br>
                       
                    </td>
                    
                </tr>

                <!-- Update Modal -->
                <div class="modal fade" id="updateModal<?php echo $row['id']; ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content" style="width: 150%; margin-left:-150px;">
                            <div class="modal-header" style="background-color: rgb(26, 112, 94); color: white;">
                                <h5 class="modal-title" >Update Record ID: <?php echo $row['id']; ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form action="update_process.php" method="POST">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                                    <div class="mb-3">
                                        <label class="form-label">Clearance No.:</label>
                                        <input type="text" name="clearance_no" class="form-control" value="<?php echo $row['clearance_no']; ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Name of PA:</label>
                                        <input type="text" name="NameOfPA" class="form-control" value="<?php echo $row['NameOfPA']; ?>" required>
                                    </div>

                                  
                                    <div class="mb-3">
                                        <label class="form-label">Proponent:</label>
                                        <input type="text" name="proponent" class="form-control" value="<?php echo $row['proponent']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Purpose:</label>
                                        <input type="text" name="Purpose" class="form-control" value="<?php echo $row['Purpose']; ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Resolution No.:</label>
                                        <input type="text" name="Resolution_No" class="form-control" value="<?php echo $row['Resolution_No']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Resolution Title:</label>
                                        
                                        <textarea name="Resolution_Title" rows="3" cols="2000" class="form-control" required> <?php echo $row['Resolution_Title']; ?> </textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">PAMB Meeting Date:</label>
                                        <input type="text" name="PAMB_Meeting_data" class="form-control" value="<?php echo $row['PAMB_Meeting_data']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Description Title:</label>
                                        <input type="text" name="Description_Title" class="form-control" value="<?php echo $row['Description_Title']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Description:</label>
                                        <input type="text" name="Des_cription" class="form-control" value="<?php echo $row['Des_cription']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Terms and Conditions:</label>
                                        
                                        <textarea name="Terms_Conditions" rows="3" cols="2000" class="form-control" required> <?php echo $row['Terms_Conditions']; ?> </textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Restrictions:</label>
                                        
                                        <textarea name="rest_riction" rows="3" cols="2000" class="form-control" > <?php echo $row['rest_riction']; ?> </textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Director:</label>
                                        <input type="text" name="Director_Name" class="form-control" value="<?php echo $row['Director_Name']; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Position:</label>
                                        <input type="text" name="Position" class="form-control" value="<?php echo $row['Position']; ?>" required>
                                    </div>


                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
