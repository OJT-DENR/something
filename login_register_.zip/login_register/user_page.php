<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
<script>
        function updateTime() {
            const optionsTime = { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true };
            const optionsDate = { timeZone: "Asia/Manila", weekday: "long", year: "numeric", month: "long", day: "numeric" };
            
            const time = new Date().toLocaleTimeString("en-US", optionsTime);
            const date = new Date().toLocaleDateString("en-US", optionsDate);
            
            document.getElementById("time").innerText = time;
            document.getElementById("date").innerText = date;
        }
        setInterval(updateTime, 1000);

</script>
<script>
    function myFunction() {
      document.getElementById("myDropdown").classList.toggle("show");
    }
    
    function filterFunction() {
      const div = document.getElementById("myDropdown");
      const a = div.getElementsByTagName("a");
      for (let i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          a[i].style.display = "";
        } else {
          a[i].style.display = "none";
        }
      }
    }
</script>
<style>
    .TimeYes{
          position: relative;
          text-align: right;
          color: burlywood;
          top: -30px;
          font-style: Times;
          margin-right: 10px;
        }
    body {
            font-family: Arial, sans-serif;
            background: #4DA0B0;  /* fallback for old browsers */
            background: linear-gradient(to top,rgb(116, 199, 156),rgb(81, 155, 68)); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
            background-repeat: no-repeat;
            background-size: cover;
            
        }
    .header {
            background: rgba(0, 0, 0, 0.7);
            
            text-align: center;
            color: #fff;
            position: absolute;
            width:100%;
            margin-left:-8px;
            margin-top:-10px;
            height: 140px;
    }
    h2{
      font-weight: 1000;
      margin-top: -2px;
    }
    
    .fakeimg{
        background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI%202.png");
        background-size: contain;
        height: 280px;
        background-repeat: no-repeat;

    }
    .fakeimg2{
        background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS%202.png");
        background-size: contain;
        height: 280px;
        background-repeat: no-repeat;

    }
    .image {
        
            display: block;
            margin-left: auto;
            margin-right: auto;
            border-radius: 15px;
    }
    .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            font-style: oblique;
            color: whitesmoke;
            background:rgb(28, 98, 39);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
            height: fit-content;
            width: fit-content;
            font-weight: 500;
        }
        .btn.secondary {
            background:rgb(28, 98, 39);
        }
        .btn.Fourth {
            background:rgb(28, 98, 39);
        }
        .btn.Three {
            background:rgb(28, 98, 39);
        }
        .btn.LogOut {
        margin: 10px;
        padding: 12px 24px;
        font-size: 1em;
        color: #fff;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background 0.3s, transform 0.2s;
        text-decoration: none;
        background: #a3342c;
        position: relative;
        left: 0px;
        top: 20px;
        }
        .btn:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }
        
        .leftcolumn {   
        
        float: left;
        width: 73%;
        
        }
        .hero h1 {
            font-size: 3em;
            margin-bottom: 10px;
        }
        .hero p {
            font-size: 1.2em;
            margin-bottom: 20px;
        }
        .DesignContainers{
            background-color:rgb(124, 171, 111);
            background-image: linear-gradient(315deg, #ffffff7b 0%, #ffffff40 40%);
            text-align: left; height: 50%; border:2px solid #58b05a;
            border-radius: 0px;
            width: 70%;
            padding-left: 1%;
            
        }
        .imageLogo{
        align-items: center;
        height: 200px;
        width: 200px;
        }
        .centered {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        }

        .rightcolumn {
        float: right;
        width: 25%;
        text-align: justified;
        font-size: 14px;
        }
        .card {
        background-color: rgb(199, 249, 182);
        padding: 20px;
        margin-top: 20px;
        height: fit-content;
        }
        .row::after {
        display: table;
        clear: both;
        
        }
        .content {
            text-align: center;
            padding: 25px;
            background: #1e1e1e;
            color: #fff;
            border-top-left-radius: 70px;
            border-top-right-radius: 70px;
            margin-bottom:-8px;
            margin-left:-8px;
            margin-right:-8px;
            margin-top: 68%;
            width: auto;
            padding-bottom: 15px;
        }
        .pics{
        height: 130px;
        width: 130px;
        align-items: right;
        
        }
        .brdrsSmall{
            border: 3px solid rgb(103, 181, 115);
            border-style: outset;
        }
        .pBottom{
          margin-bottom:-2px;
        }
        @media only screen and (max-width: 600px) {
        body {
          background-color: lightblue;
          width: fit-content;
          }
          .pics{
          height: 20px;
          width: 50px;
          align-items: right;
        }
        .imageLogo{
        align-items: center;
        height: 70px;
        width: 70px;
        margin-bottom: -20px;
        }
        .fakeimg{
        background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI%202.png");
        background-size: contain;
        height: 100px;
        background-repeat: no-repeat;
        }
        .fakeimg2{
        background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS%202.png");
        background-size: contain;
        height: 100px;
        background-repeat: no-repeat;
        }
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            font-style: oblique;
            color: whitesmoke;
            background:rgb(28, 98, 39);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
            height: fit-content;
            width: fit-content;
            font-weight: 500;
        }
        .btn.LogOut {
        margin: 0px;
        padding: 6px 15px;
        font-size: 15px;
        color: #fff;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background 0.3s, transform 0.2s;
        text-decoration: none;
        background: #a3342c;
        position: relative;
        left: 0px;
        top: 90px;
        }
        .leftcolumn {   
        float: left;
        width: 100%;
        }
        .rightcolumn {
        float: right;
        width: 100%;
        text-align: justified;
        font-size: 14px;
        }
        .content {
            text-align: center;
            padding: 25px;
            background: #1e1e1e;
            color: #fff;
            border-top-left-radius: 70px;
            border-top-right-radius: 70px;
            margin-bottom:-8px;
            margin-left:-8px;
            margin-right:-8px;
            margin-top: 68%;
            width: auto;
            padding-bottom: 15px;
            height: fit-content;
        }
        .TimeYes{
          position: relative;
          text-align: right;
          color: whitesmoke;
          top: -30px;
          font-style: Times;
          margin-right: 10px;
          font-size: small;
        }
        }
</style>
</head>
<body>
    <div class="header">
        <h1 style="margin-top: 40px; text-align: center; font-weight: 800; color: #f6f6f6;">  DENR - Prototype Docu System</h1>
        <p class="TimeYes" id ="time" style="margin-top: -20px;"></p>
        <p class="TimeYes" id ="date"></p>
        
    </div>

    <a href="index.php" class="btn LogOut">Log-out</a>
    

    <br><br><br><br><br><br>
    <div class="imageLogo" style="width: 100%; margin-top:0px; ">
        <div class="brdrsSmall" style="background-color:rgba(8, 41, 11, 0.37);">
    <img src="https://upload.wikimedia.org/wikipedia/commons/e/e8/Logo_of_the_Department_of_Environment_and_Natural_Resources.svg" class="imageLogo" style="padding-left:43.2%; margin-top: 15px;"></img>
    <h1 style="text-align: center; color:floralwhite;">DENR - Prototype Docu System</h1>
    <p style="text-align: center; color:floralwhite;">Website built for your database needs.</p>
        </div>
    </div>
    <br><br><br><br><br><br><br><br>
    <div class="row">
        <div class="leftcolumn">
          <div class="card" style="border-radius: 0%; border: 3px solid rgb(183, 239, 151);
            border-style: outset;">
        
            <h2>PAMB Clearance</h2>
            
            <div class="fakeimg"></div>
            
      <div>
        <a href="pamb.php" class="btn">PAMB</a>
        <a href="PAMBIDATA.php" class="btn secondary">DATABASE</a>
      </div>

    </div>
          <div class="card" style="border-radius: 0%; border: 3px solid rgb(183, 239, 151);
            border-style: outset;">
            <h2>NIPAS Certification</h2>
            
            <div class="fakeimg2"></div>
            
        <div>
            <a href="nipas.php" class="btn Three">NIPAS</a>
            <a href="updatenipas.php" class="btn Fourth">DATABASE</a>
        </div>
    </div>

      </div>
        <div class="rightcolumn">
          <div class="card" style="border: 3px solid rgb(183, 239, 151);
            border-style: outset;">
            
            <h2>About the site:</h2>
            
            <p class="pBottom">This website offers DENR CDD employees to help automate the process of making PDF forms for each NIPAS and PAMB documents whilst giving them a proper database where each input can be documented and updated.</p>
            
          </div>
          <div class="card" style="border: 3px solid rgb(183, 239, 151);
            border-style: outset;">
            <h2>DENR Mission-</h2>
            <p class="pBottom">To mobilize our citizenry in protecting, conserving, and managing the environment and natural resources for the present and future generations. </p>
            <h2 style="margin-top: 15px;">DENR Vision-</h2>
            <p class="pBottom">A nation enjoying and sustaining its natural resources and a clean and healthy environment.</p>
          </div>
          <div class="card" style="border: 3px solid rgb(183, 239, 151);">
            <h2 style="margin-bottom: 13px; margin-top: 3px; ">ARTS:</h2>
            <div>
            <img src="https://raw.githubusercontent.com/OJT-DENR/something/refs/heads/main/DENR_PXL_logo.png" class="pics"></img>

            </div>
            
            
          </div>
        </div>
    </div>

    <div class="content">
        <h2>To learn more about DENR and other related topics</h2>
        <p>Go visit: <a href="https://calabarzon.emb.gov.ph/online-services/?appgw_azwaf_jsc=f2JKgLpU9asbPh6V8cjemUHRw0svkdd2yid0w7K4Roo" style="color: white;"> DENR online services </a></p>
    </div>

    
    
</body>
</html>


