<?php
require 'vendor/autoload.php'; // Load Dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

// Database Connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all records from clearance table
$query = "SELECT * FROM clearance";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    // Initialize Dompdf
    $options = new Options();
    $options->set('defaultFont', 'Arial');
    $dompdf = new Dompdf($options);

    // Start HTML content for the PDF
    $html = "
    <h2 style='text-align: center;'>Clearance Records</h2>
    <table border='1' cellspacing='0' cellpadding='5' width='100%'>
        <tr>
            
                <th>Clearance No.</th>
                <th>Name of PA</th>
                <th>Proponent</th>
                <th>Purpose</th>
                <th>Resolution No.</th>
                <th>Resolution title</th>
                <th>PAMB meeting date</th>
                <th>Description title</th>
                <th>Description</th>
                <th>Terms and Conditions</th>
             
        </tr>";

    // Loop through each row and add it to the table
    while ($row = $result->fetch_assoc()) {
        $html .= "
        <tr>
            <td>{$row['clearance_no']}</td>
            <td>{$row['NameOfPA']}</td>
            <td>{$row['proponent']}</td>
            <td>{$row['Purpose']}</td>
            <td>{$row['Resolution_No']}</td>
            <td>{$row['Resolution_Title']}</td>
            <td>{$row['PAMB_Meeting_data']}</td>
            <td>{$row['Description_Title']}</td>
            <td>{$row['Des_cription']}</td>
            <td>{$row['Terms_Conditions']}</td>
            <td>{$row['rest_riction']}</td>
        
        </tr>";
    }

    $html .= "</table>";

    // Load HTML into Dompdf
    $dompdf->loadHtml($html);
    $dompdf->setPaper('legal', 'landscape');
    $dompdf->render();

    // Output the PDF for download
    $dompdf->stream("clearance_records.pdf", ["Attachment" => 1]);
} else {
    echo "No records found!";
    
}

$conn->close();
?>
