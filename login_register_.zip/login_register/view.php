<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM clearance");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Records</title>
</head>
<body>

    <h2>Existing Clearance Records</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Clearance No.</th>
            <th>Proponent</th>
            <th>Activity</th>
            <th>PAMB Meeting</th>
            <th>Activity Description</th>
            <th>Subject to Compliance With</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['clearance_no']; ?></td>
                <td><?php echo $row['proponent']; ?></td>
                <td><?php echo nl2br($row['activity']); ?></td>
                <td><?php echo nl2br($row['pamb_meeting']); ?></td>
                <td><?php echo nl2br($row['activity_description']); ?></td>
                <td><?php echo nl2br($row['subject_to_compliance']); ?></td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>

<?php $conn->close(); ?>
