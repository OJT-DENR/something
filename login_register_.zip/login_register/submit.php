<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data safely
$clearance_no = $_POST['clearance_no'] ?? null;
$nameofpa = $_POST['NameOfPA'] ?? null;
$proponent = $_POST['proponent'] ?? null;
$Purpose = $_POST['Purpose'] ?? null;
$Resolution_No = $_POST['Resolution_No'] ?? null;
$Resolution_Title = $_POST['Resolution_Title'] ?? null;
$PAMB_Meeting_data = $_POST['PAMB_Meeting_data'] ?? null;
$Description_Title = $_POST['Description_Title'] ?? null;
$Des_cription = $_POST['Des_cription'] ?? null;
$Terms_Conditions = $_POST['Terms_Conditions'] ?? null;
$rest_riction = $_POST['rest_riction'] ?? null;
$director_name = $_POST['Director_Name'] ?? null;
$position = $_POST['Position'] ?? null;

// Prepare statement
$stmt = $conn->prepare("INSERT INTO clearance 
    (clearance_no, NameOfPA, proponent, Purpose, Resolution_No, Resolution_Title, PAMB_Meeting_data, Description_Title, Des_cription, Terms_Conditions, rest_riction, Director_Name, Position) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");

// Check if prepare() was successful
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

// Bind parameters - make sure the number of variables matches the placeholders
$stmt->bind_param("sssssssssssss", 
    $clearance_no, $nameofpa, $proponent, $Purpose, $Resolution_No, 
    $Resolution_Title, $PAMB_Meeting_data, $Description_Title, 
    $Des_cription, $Terms_Conditions, $rest_riction ,$director_name , $position
);

// Execute statement and check for errors
if ($stmt->execute()) {
    echo "<script>alert('Data saved successfully!'); window.location.href='pamb.php';</script>";
} else {
    echo "<script>alert('Error: Could not save data.'); window.location.href='form.html';</script>";
}

// Close connections
$stmt->close();
$conn->close();
?>
