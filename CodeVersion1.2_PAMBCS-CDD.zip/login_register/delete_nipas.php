<?php
require 'db.php'; // make sure this connects to your DB

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);

    // Optional: check if it exists first before deleting
    $stmt = $conn->prepare("DELETE FROM nipas_table WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: updatenipas.php?msg=deleted");
        exit();
    } else {
        echo "Failed to delete record.";
    }
}
?>