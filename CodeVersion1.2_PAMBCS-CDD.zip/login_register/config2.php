<?php
$host = "localhost"; // Change this if needed
$user = "root"; // Your database username
$pass = ""; // Your database password
$dbname = "nipas_db"; // Database name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
