<?php
require 'vendor/autoload.php'; // Ensure Dompdf is installed
require 'db.php'; // Database connection

use Dompdf\Dompdf;
use Dompdf\Options;

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate ID input
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No valid ID provided.");
}

$id = intval($_GET['id']); // Sanitize ID

// Fetch data from database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if record exists
if ($result->num_rows == 0) {
    die("Error: No record found with ID " . $id);
}

$row = $result->fetch_assoc();

// Newly added database fields
$LotN = isset($row['LotN']) ? htmlspecialchars($row['LotN']) : 'N/A';
$TCT = isset($row['TCT']) ? htmlspecialchars($row['TCT']) : 'N/A';
$applicant = isset($row['applicant']) ? htmlspecialchars($row['applicant']) : 'N/A';
$purpose = isset($row['purpose']) ? htmlspecialchars($row['purpose']) : 'N/A';
$amount = isset($row['amount']) ? htmlspecialchars($row['amount']) : 'N/A';
$totalWords = isset($row['totalwords']) ? htmlspecialchars($row['totalwords']) : 'N/A';
$Area1 = isset($row['area1']) ? htmlspecialchars($row['area1']) : 'N/A';
$findings = isset($row['findings']) ? htmlspecialchars($row['findings']) : 'N/A';
$location = isset($row['location']) ? htmlspecialchars($row['location']) : 'N/A';
$actioned = isset($row['actioned']) ? htmlspecialchars($row['actioned']) : 'N/A';
$position = isset($row['position']) ? htmlspecialchars($row['position']) : 'N/A';
$noappword = isset($row['NoAppword']) ? htmlspecialchars($row['NoAppword']): 'N/A'; 
$noapplied = isset($row['NoApplied']) ? htmlspecialchars($row['NoApplied']) : 'N/A';
$Director = isset($row['Director']) ? htmlspecialchars($row['Director']) : 'N/A';
$director_pos = isset($row['director_pos']) ? htmlspecialchars($row['director_pos']) : 'N/A';
$ChiefCDD = isset($row['ChiefCDD']) ? htmlspecialchars($row['ChiefCDD']) : 'N/A';
$ChiefCDDPos = isset($row['ChiefCDDPos']) ? htmlspecialchars($row['ChiefCDDPos']) : 'N/A';


$x = 50;
$x *= $noapplied;


// Dompdf options
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true); // Allow external images
$dompdf = new Dompdf($options);

$backgroundImage = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/download.png";

// Define HTML content with proper data
$html = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
    @page { 
        size: A4; 
        margin:0px;
    }
    body {
        line-height: 1.1;
        font-family: "Times New Roman", serif;
        font-size: 16px;
        padding: 30px 30px 30px 70px;
        text-align: justify;
        background-image: url("' . $backgroundImage . '");
        background-repeat: no-repeat;
        background-size: cover;    
    }
    .activity-box {
        border: 1px solid black;
        padding: 10px;
        margin: 20px 0;
    }
    .content {
        padding-right:30px;
        font-size: 16px;
        line-height: 1.2;
    }
    .content2 {
        padding-right:40px;
        padding-left:10px;
        padding-top:10px;
        margin-bottom:20px;
        font-size: 16px;
        line-height: 1.2;
    }
    h2, h4 {
        text-align: center;
        font-weight: bold;
    }
    .signature {
        text-align: center;
        margin-top: 40px;
        margin-right: 230px;
    }
    .underline {
        border-bottom: 1px solid black;
        display: inline-block;
        width: 85px;
    }
    .marginTop{
        margin-top:-20px;
    }
    .approved-section2 {
        text-align: center;
        line-height: 0.9;
        display: flex;
        align-items: flex-end; /* Aligns content to the right */
        flex-direction: column;
        margin-left: 285px; /* Adjust as needed */
    }
    span {
        content: "\20B1";
    }
    .marginLow{
        text-align:center;
        margin-top:-20px;
    }
    .marginLow2{
        text-align:center;
        margin-top:-20px;
        margin-bottom:-3px;
    }
    .PuntaRight{
        text-align:right;
        margin-bottom:-20px;
    }
    TableContainer{
        margin-top:-5px; 
        margin-bottom:-5px;
        font-size: 16px;
    }
    .Prepared{
        text-align:center;
        margin-top: 15px;
    }
    </style>
</head>
<body style="margin-left:20px; margin-right:30px;">
    <div class="content2">
        <p style="text-align:right">(Annex A)</p>
        <p></p>

        <p style="margin-Bottom:20px; text-align:center">Republic of the Philippines</p>
        <p class="marginLow"><strong>DEPARTMENT OF ENVIRONMENT AND NATURAL RESOURCES</strong></p>
        <p class="marginLow">OFFICE: Regional Office No. 4A (CALABARZON)</p>
        <p class="marginLow">Office Address: DENR IV-A (CALABARZON) COMPOUND</p>
        <p class="marginLow">DICOT BUILDING,Mayapa, Main Road</p>
        <p class="marginLow2">Along SLEX, Brgy. Mayapa, Calamaba City, Laguna</p>

        <br>

        <p style="margin-bottom:-20px; text-align:right; margin-right:91px;"><strong>BILL NUMBER: &nbsp;&nbsp;</strong>2025-</p>
        <p style="text-indent:140px; line-height: -10; text-align:right; ">________________</p>
        <p style="margin-top:-15px; margin-bottom:-20px; text-align:right; margin-right:24px;"><strong>RESPONSIBILITY CENTER: &nbsp;
        </strong>CDD-PAMBCS</p>
        <p style="text-indent:150px; line-height: -10; text-align:right;">________________</p>
        <p style="margin-top:-15px; margin-bottom:-20px; text-align:right; margin-right:140px;"><strong>DATE:</strong></p>
        <p style="text-indent:150px; line-height: -10; text-align:right; ">________________</p>

        <p></p>

        <p style="text-align: center; margin-bottom:-3px;"><strong>ASSESMENT FORM</strong></p>
        <br>

        <p style="margin-bottom:-20px;"><strong>NAME/PAYEE: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>'.$applicant.'</p>
        <p style="text-indent:137px; line-height: -10;">_____________________________________</p>
        <p style="margin-top:-15px; margin-bottom:-20px;"><strong>ADDRESS: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </strong>'.$location.'</p>
        <p style="text-indent:137px; line-height: -10;">_____________________________________</p>

    <div class="TableContainer">
    <table style="width:105%; border-collapse: collapse; text-align: center; font-size: 16px; margin-left:-10px;">
        <tr>
            <td style="border: 1px solid black;">LEGAL BASIS (DAO/SEC)</td>
            <td style="border: 1px solid black;">DESCRIPTION AND COMPUTATION OF FEES AND/OR CHARGES ASSESSED</td>
            <td style="border: 1px solid black;"><p style="margin-bottom:-12px;"></p>QUANTITY</td>
            <td style="border: 1px solid black; width: 100px;"><p style="margin-bottom:-16px;"></p>AMOUNT(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>)</td>
        </tr>
        <tr style="height: 80px;">
            <td style="border: 1px solid black; padding: 8px;">&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>
            DAO 2022-10 &nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br></td>
            <td style="border: 1px solid black; padding: 8px;">NIPAS CERTIFICATION FEE <br>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>50.00 PER LOT)</td>
            <td style="border: 1px solid black; padding: 8px;">'.$noapplied.' lots</td>
            <td style="border: 1px solid black; padding: 8px;"> '.$x.' </td>
        </tr>
        <tr>
            <td style="border: 1px solid black; padding: 8px;"></td>
            <td style="text-align: right;border: 1px solid black; padding: 8px;"><strong>TOTAL</strong></td>
            <td style="border: 1px solid black; padding: 8px;"></td>
            <td style="border: 1px solid black; padding: 8px;"><strong>'.$x.'</strong></td>
        </tr>
    </table>
    </div>

    <p></p>
    <p style="text-align:center;">Prepared By: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Reviewed By:</p>
    
    <p></p>
    <p></p>
    <table style="width:105%; border:none; text-align: left;">
    <tr>
        <th style="width:250px;"> <strong>'.$actioned.' </strong></th>
        <th style="width:60px;" ></th>
        <th style="width:180px;"> <strong> &nbsp; '.$ChiefCDD.' </strong></th>
        <th style="width:60px;" ></th>
    </tr>
    </table>
    <p style="margin-top:-20px;"></p>
    <p style="margin-top:-20px;"></p>
    <table style="width:100%; border: 1px solid black; border-collapse:collapse; border-color: white;">
    <tr>
        <th style="width:10px; border: 1px solid black; border-color: white;"></th>
        <td style=" text-align:center;"> '.$position.' </td>
        <th style="width:80px; border: 1px solid black; border-color: white;"></th>
        <td style="width:180px; text-align:center; border: 1px solid black; border-color: white;">&nbsp; &nbsp; '.$ChiefCDDPos.'</td>
        <th style="width:60px; border: 1px solid black; border-color: white;" ></th>
    </tr>
    </table>
    <p style="margin-top:-20px;">  </p>
    </div>

</body>
</html>';

    // &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    // &nbsp;&nbsp;&nbsp;&nbsp; VICTOR D. OMBAJINO </strong> 

// Load HTML to Dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait'); // Set paper size
$dompdf->render(); // Render PDF

// Force file download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Assesmentform_Form_' . $applicant . '.pdf"');
echo $dompdf->output();

exit;
?>