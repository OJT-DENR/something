<?php

require 'db.php';

$allowed_columns = ['DATS', 'actioned', 'Location', 'Applicant', 'ControlNumber', 'Findings', 'Purpose', 'Company', 'DateReleased'];

// Default query
$query = "SELECT * FROM nipas_table";
$conditions = [];

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $search = trim($conn->real_escape_string($_POST['search'] ?? ''));
    $filter = trim($_POST['filter'] ?? 'all');
    $from = $_POST['from_month'] ?? '';
    $to = $_POST['to_month'] ?? '';

    // Handle search
    if (!empty($search)) {
        if ($filter === 'all') {
            $searchParts = array_map(function($col) use ($search) {
                return "$col LIKE '%$search%'";
            }, $allowed_columns);
            $conditions[] = '(' . implode(' OR ', $searchParts) . ')';
        } elseif (in_array($filter, $allowed_columns)) {
            $conditions[] = "$filter LIKE '%$search%'";
        }
    }

    // Handle date range filter using DateReleased
    if (!empty($from) && !empty($to)) {
        $fromDate = date('Y-m-01', strtotime($from));
        $toDate = date('Y-m-t', strtotime($to));
        $conditions[] = "(STR_TO_DATE(DateReleased, '%M %e %Y') BETWEEN '$fromDate' AND '$toDate')";
    }

    // Append WHERE clause if conditions exist
    if (!empty($conditions)) {
        $query .= ' WHERE ' . implode(' AND ', $conditions);
    }
}


// Execute the final query
$result = $conn->query($query);
$total_results = $result->num_rows;

// Handle Delete All Request
if (isset($_POST['delete_all'])) {
    $conn->query("TRUNCATE TABLE nipas_table");
    header("Location: updatenipas.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<!-- DataTables CSS and JS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Required by DataTables -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIPAS Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>

body {
    font-family: Arial, sans-serif; 
    background-color: rgba(21, 86, 50, 0.73);
}
.container { 
    max-width: 100%; 
    margin: auto; 
    /*background-image: linear-gradient(-225deg,rgb(59, 98, 156) 0%,rgb(37, 128, 114) 51%,rgb(29, 128, 87) 100%);*/
    padding: 20px; border-radius: 8px; }
.   iner { 
    background-color:rgba(29, 131, 72, 0); 
    width: 100%; 
    height: auto; 
    border: none; 
    border-radius: 5px; 
}
table { 
    width: 100%; 
    border-collapse: collapse; 
    background-color: #1d8348;  
    overflow-x: scroll;
}
th, td {  
    padding: 8px; 
    text-align: center; 
    border: 1px solid #ddd; 
    height: 50%;
}
th { 
    color: white; 
}
.back-btn { 
    border:none;
    border-radius:5px; 
    position:top: 100px; 
    right: 120px ; 
    font-size: 15px; 
    padding: 10px 20px; 
    cursor: pointer; 
    background-color:rgb(14, 111, 97); 
    width:5%; 
    margin-top:-5px; 
    color:white;
    margin-bottom: -20px;
}
.btn:hover {
    opacity: 0.9; 
    transform: scale(1.05);
}
/* Container alignment */
#nipasTable_wrapper_outside {
    margin-top: 20px;
    display: flex;
    justify-content: center;
}
/* Pagination buttons */
.dataTables_paginate {
    display: flex; 
    gap: 8px; 
    flex-wrap: wrap;
}
/* Base button style */
.dataTables_paginate .paginate_button {
    background-color: #f0f0f0; 
    border: 1px solid #ccc; 
    padding: 6px 12px; 
    border-radius: 6px;
    color: #333; 
    font-size: 14px; 
    cursor: pointer; 
    transition: all 0.2s ease; 
    font-style: normal;
}
/* Hover effect */
.dataTables_paginate .paginate_button:hover {
    background-color: #007bff; 
    color: white; 
    border-color: #007bff;
}
/* Active page button */
.dataTables_paginate .paginate_button.current {
    background-color: #007bff; 
    color: white !important; 
    border-color: #0056b3; 
    font-weight: bold; 
    font-style: normal;
}
/* Disabled buttons */
.dataTables_paginate .paginate_button.disabled {
    background-color: #eaeaea; 
    color: #aaa !important; 
    border-color: #ddd; 
    cursor: not-allowed;
}
/* Style the page length selector */
.dataTables_length {
    background-color:rgba(245, 245, 245, 0);
    padding: 10px; 
    border-radius: 6px;
    color: white;
}
/* Style the page info */
.dataTables_info {
    background-color:rgba(245, 245, 245, 0); 
    padding: 0px; 
    border-radius: 6px; 
    color: white; 
    font-weight: bold;
}
/* Style the pagination (already styled, but adjusted for consistency) */
.dataTables_paginate {
    background-color: #f5f5f5; /* Dirty white */ 
    padding: 10px; 
    border-radius: 6px; 
    text-decoration: none; 
    font-style: normal;
}
.btn-success{
    background-color:rgb(45, 167, 65);
    transition: background 0.3s, transform 0.2s;
}
.btn-danger{
    transition: background 0.3s, transform 0.2s;
}
.btn-primary{
    transition: background 0.3s, transform 0.2s;
}

</style>
</head>
<script>

    var mouseclick = new Audio();
    mouseclick.src = "https://uploads.sitepoint.com/wp-content/uploads/2023/06/1687569402mixkit-fast-double-click-on-mouse-275.wav";

</script>
<body>

    <div class="container">
        <button class="back-btn" onmousedown="mouseclick.play()" onclick="window.location.href='user_page.php';">Back</button>
            
        <h2 class="text-center my-4" style="color:rgb(255, 255, 255); text-shadow: none; font-size: 300%; font-weight: 700; margin-top: -30px;">NIPAS Records</h2>
        <a href="download_allnipas.php?search=<?= urlencode($_POST['search'] ?? '') ?>&filter=<?= urlencode($_POST['filter'] ?? 'all') ?>" class="btn btn-success mb-3">Download Records PDF</a>
        <a href="download_allnipasex.php?search=<?= urlencode($_POST['search'] ?? '') ?>&filter=<?= urlencode($_POST['filter'] ?? 'all') ?>" class="btn btn-success mb-3">Download Records XLSX</a>
    
        <!-- Search Form -->
    <form method="POST" class="mb-3 d-flex flex-wrap gap-2 align-items-center" style="margin-top: -5px;">
    <input type="text" name="search" class="form-control me-2" placeholder="Search..." value="<?= isset($_POST['search']) ? htmlspecialchars($_POST['search']) : ''; ?>">

    <select name="filter" class="form-select me-2" style="max-width: 200px;">
        <option value="all" <?= (isset($_POST['filter']) && $_POST['filter'] == 'all') ? 'selected' : ''; ?>>All Fields</option>
        <option value="DATS" <?= (isset($_POST['filter']) && $_POST['filter'] == 'DATS') ? 'selected' : ''; ?>>DATS</option>
        <option value="actioned" <?= (isset($_POST['filter']) && $_POST['filter'] == 'actioned') ? 'selected' : ''; ?>>Actioned By</option>
        <option value="Location" <?= (isset($_POST['filter']) && $_POST['filter'] == 'Location') ? 'selected' : ''; ?>>Location</option>
        <option value="Applicant" <?= (isset($_POST['filter']) && $_POST['filter'] == 'Applicant') ? 'selected' : ''; ?>>Applicant</option>
        <option value="Company" <?= (isset($_POST['filter']) && $_POST['filter'] == 'Company') ? 'selected' : ''; ?>>Company</option>
        <option value="ControlNumber" <?= (isset($_POST['filter']) && $_POST['filter'] == 'ControlNumber') ? 'selected' : ''; ?>>Control Number</option>
        <option value="findings" <?= (isset($_POST['filter']) && $_POST['filter'] == 'findings') ? 'selected' : ''; ?>>Findings</option>
        <option value="Purpose" <?= (isset($_POST['filter']) && $_POST['filter'] == 'Purpose') ? 'selected' : ''; ?>>Purpose</option>
        <option value="DateReleased" <?= (isset($_POST['filter']) && $_POST['filter'] == 'DateReleased') ? 'selected' : ''; ?>>DateReleased</option>

    </select>

    <label style="color:white;">From:</label>
    <input type="month" name="from_month" class="form-control" value="<?= $_POST['from_month'] ?? '' ?>" style="max-width: 160px;">

    <label style="color:white;">To:</label>
    <input type="month" name="to_month" class="form-control" value="<?= $_POST['to_month'] ?? '' ?>" style="max-width: 160px;">

    <button type="submit" class="btn btn-primary">Search</button>
    </form>

        <!--Search Notification-->
        <?php if (!empty($search)): ?>
        <div class="alert alert-info" style="background-color:  rgba(116, 174, 202, 0.54); color: white; border:none;">
            Found <strong><?= $total_results; ?></strong> result(s) for "<strong><?= htmlspecialchars($search); ?></strong>" 
            in <strong><?= $filter === 'all' ? 'all columns' : ucfirst(str_replace('_', ' ', $filter)); ?></strong>.
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center my-3" id="nipasTable_controls_outside"></div>
            <div class="table-container">
                    <table id="nipasTable" class="table table-striped table-bordered text-center" >
                        <thead class="table-dark">
                            <tr >
                                <th style="background-color: rgb(31, 29, 29); color:white;">ID</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">DATS</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Received by</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Date  (M/D/Yr)</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Time</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Originating Office</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Actioned By</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Position</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Applicant Name</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Company</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Owner Representative</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Location</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">No. of Applied</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Letter</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Contact Person</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Contact No.</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Lot Data</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Approved</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">PSU, PSD, CSD</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Total</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">SPA</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Secretary</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">D.O.S</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Others</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Inspection</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Map Prepared</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Geotagged</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Amount of Payment</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Amount of Payment (Words)</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Findings (Protected & Within)</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Purpose of Application</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Remarks</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Link</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Control Number</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Date Approved</th>
                                 <th style="background-color: rgb(31, 29, 29); color:white;">Date Released</th>
                                <th style="background-color: rgb(31, 29, 29); color:white;">Actions</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['dats']; ?></td>
                                    <td><?php echo $row['received']; ?></td>
                                    <td><?php echo $row['date']; ?></td>
                                    <td><?php echo $row['time']; ?></td>
                                    <td><?php echo $row['originating']; ?></td>
                                    <td><?php echo $row['actioned']; ?></td>
                                    <td><?php echo $row['position']; ?></td>
                                    <td><?php echo $row['applicant']; ?></td>
                                    <td><?php echo $row['company']; ?></td>
                                    <td><?php echo $row['OwnerRepresentative']; ?></td>
                                    <td><?php echo $row['location']; ?></td>
                                    <td><?php echo $row['NoApplied']; ?></td>
                                    <td><?php echo $row['LetterTF']; ?></td>
                                    <td><?php echo $row['ContactP']; ?></td>
                                    <td><?php echo $row['ContactN']; ?></td>
                                    <td><?php echo $row['LotData']; ?></td>
                                    <td><?php echo $row['approved']; ?></td>
                                    <td><?php echo $row['ppc']; ?></td>
                                    <td><?php echo $row['total']; ?></td>
                                    <td><?php echo $row['spa']; ?></td>
                                    <td><?php echo $row['sec']; ?></td>
                                    <td><?php echo $row['DoS']; ?></td>
                                    <td><?php echo $row['others']; ?></td>
                                    <td><?php echo $row['inspect']; ?></td>
                                    <td><?php echo $row['map']; ?></td>
                                    <td><?php echo $row['geo']; ?></td>
                                    <td><?php echo $row['amount']; ?></td>
                                    <td><?php echo $row['totalwords']; ?></td>
                                    <td><?= substr(htmlspecialchars($row['findings']), 0, 110) . '...'; ?></td>
                                    <td><?= substr(htmlspecialchars($row['purpose']), 0, 110) . '...'; ?></td>
                                    <td><?= substr(htmlspecialchars($row['remarks']), 0, 110) . '...'; ?></td>
                                    <td><?php echo $row['Links']; ?></td>
                                    <td><?php echo $row['ControlNumber']; ?></td>
                                    <td><?php echo $row['DateApproved']; ?></td>
                                       <td><?php echo $row['DateReleased']; ?></td>
                                    <td>
                                    <form method="POST" action="delete_nipas.php" onsubmit="return confirm('Are you sure you want to delete this record?');">
                                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form><br>
                                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id']; ?>">Edit</button><br><br>

                                    <a href="certification.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Download NIPAS Certification</a> <br></br>
                                    <a href="certmore.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Download NIPAS Certification More Lots</a> <br></br>
                                    <a href="assesmentform.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Download Assessment Form</a> <br> <br>
                                    <a href="memorandum.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm">Memoramdum Form</a><br> <br>
                      
                                    </td>
                                </tr>
                                <!-- Edit Modal -->
                                    <div class="modal fade" id="editModal<?= $row['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header" style="background-color: rgb(26, 112, 94); color: white;">
                                                    <h5 class="modal-title">Edit Record ID: <?= $row['id']; ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="update1.php" method="POST">
                                                        <input type="hidden" name="id" value="<?= $row['id']; ?>">

                                                        <!-- Show 'Created By' at the top, read-only -->
                                                        <?php if (isset($row['created_by'])): ?>
                                                            <div class="mb-3">
                                                                <label class="form-label">Created By:</label>
                                                                <input type="text" class="form-control" value="<?= htmlspecialchars($row['created_by']); ?>" readonly>
                                                            </div>
                                                        <?php endif; ?>

                                                        <?php foreach ($row as $key => $value): 
                                                            if ($key !== "id" && $key !== "created_by") { ?>
                                                                <div class="mb-3">
                                                                    <label class="form-label"><?= ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                                                                    <input type="text" name="<?= $key; ?>" class="form-control" value="<?= htmlspecialchars($value); ?>">
                                                                </div>
                                                        <?php } endforeach; ?>

                                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>

                            <?php } ?>
                        </tbody>
                        
                    </table>
                <div id="nipasTable_wrapper_outside"></div>
            </div>
    </div>

    <!--Delete All Script-->
    <script>
        function confirmDeleteAll() {
            return confirm("Are you sure you want to delete ALL records? This action cannot be undone.");
        }
    </script>

    <script>
        $(document).ready(function() {
            var table = $('#nipasTable').DataTable({
                "searching": false,
                "lengthMenu": [5,10, 25],
                "pageLength": 5,
                paging: true,
                scrollY: '450px',
                scrollCollapse: true,
                scrollX: true,
                responsive: true,
                dom: '<"top"lf>rt<"bottom"ip><"clear">'
            });

            // Move the pagination controls
            $('#nipasTable_wrapper .dataTables_paginate').appendTo('#nipasTable_wrapper_outside');
            $('#nipasTable_wrapper .dataTables_length').appendTo('#nipasTable_controls_outside');
            $('#nipasTable_wrapper .dataTables_info').appendTo('#nipasTable_controls_outside');
        });
    </script>   
</body>
</html>
<?php $conn->close(); ?>
