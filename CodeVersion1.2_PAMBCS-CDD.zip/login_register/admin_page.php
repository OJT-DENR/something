<?php
// Connect to MySQL
$host = "localhost";
$user = "root";
$password = "";
$dbname = "users_db";
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default query: Show all records
$query = "SELECT * FROM users";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_changes'])) {
    $id = intval($_POST['edit_id']);
    $name = $_POST['edit_name'];
    $new_password = $_POST['edit_password'];

    if (!empty($new_password)) {
        // New password provided — hash and update
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET name = ?, password = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $hashed_password, $id);
    } else {
        // Password left blank — keep existing
        $stmt = $conn->prepare("UPDATE users SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $id);
    }

    $stmt->execute();
    $stmt->close();

    // Redirect after update
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$result = $conn->query($query);
?>


<!DOCTYPE html>
<html lang="en">

<script>
function openEditModal(id, name, password) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_password').value = password;

    var modal = new bootstrap.Modal(document.getElementById('editUserModal'));
    modal.show();
}
</script>
<script>
function togglePassword() {
    var x = document.getElementById("edit_password");
    x.type = x.type === "password" ? "text" : "password";
}
</script>

<script>
  function updateTime() {
    const optionsTime = { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true };
    const optionsDate = { timeZone: "Asia/Manila", weekday: "long", year: "numeric", month: "long", day: "numeric" };
            
    const time = new Date().toLocaleTimeString("en-US", optionsTime);
    const date = new Date().toLocaleDateString("en-US", optionsDate);
            
    document.getElementById("time").innerText = time;
    document.getElementById("date").innerText = date;

    document.querySelectorAll('.editBtn').forEach(button => {
  button.addEventListener('click', () => {
    const id = button.dataset.id;
    const name = button.dataset.name;

    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;

    // DO NOT set value for password
    document.getElementById('edit_password').value = ''; // always blank
  });
});

  }
  setInterval(updateTime, 1000);
</script>
<head>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>
    /* Reset & Base */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: 'Segoe UI', sans-serif;
  color: #333;
}
.TimeYes{
  position: relative;
  text-align: right;
  color: rgb(252, 252, 252);
  top: 12px;
  font-style: Times;
  margin-right: 0px;
}
.Emblem{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/Seal_of_the_Department_of_Environment_and_Natural_Resources.svg.png");
  background-size: 60px 60px;
  background-repeat: no-repeat;
  height: 60px;
  margin-top:0px;
  margin-left:-40px;
}
/* Header */
header {
  background-color: rgba(21, 86, 50, 0.937);
  display: flex;
  justify-content: space-between;
  padding: 20px 10%;
  align-items: center;
  color: white;
  box-shadow: 0px 5px 5px rgb(53, 53, 53);
  height: 90px;
}
.NIPASpic{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Icon.png");
  background-size: contain;
  height: 200px;
  background-repeat: no-repeat;
  background-position: center;
}
.PAMBpic{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMB_Icon.png");
  background-size: contain;
  height: 200px;
  background-repeat: no-repeat;
  background-position: center;
}
.btn {
  display: inline-block;
  margin: 10px;
  padding: 8px 15px;
  font-size: 1em;
  font-style: oblique;
  color: whitesmoke;
  background:rgb(28, 98, 39);
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.3s, transform 0.2s;
  text-decoration: none;
  height: fit-content;
  width: fit-content;
  font-weight: 500;
}
.btn.delete {
  font-style: normal;
  font-weight: 400;
  background: #a3342c;
}
.btn.LogOut {
  font-style: normal;
  font-weight: 400;
  color:white;
  margin-right: -4px;
  background: #a3342c;
}
.btn.HowTo{
  font-style: normal;
  font-weight: 400;
  color:white;
  background:rgb(67, 153, 80);            
}
.btn.Create{
  font-style: normal;
  font-weight: 400;
  color:white;
  background:rgb(34, 125, 116);            
}
.btn.close{
  font-style: normal;
  font-weight: 400;
  color:white;
  padding: 5px 10px;
  border: 1px solid #a3342c;
  background:rgb(224, 110, 110);            
}
.btn.secondary {
  background:rgb(28, 98, 39);
}
.btn.Databases {
  margin-top: 10px;
  padding: 8px 12px;
  background: #24ab58;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  font-style: normal;
  font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
}
.btn.Three {
  background:rgb(28, 98, 39);
}
.btn:hover {
  opacity: 0.9;
  transform: scale(1.05);
}
.logo {
  font-size: 24px;
  font-weight: bold;
}
nav ul {
  display: flex;
  list-style: none;
}
nav ul li {
  margin-left: 20px;
}
nav ul li a {
  color: white;
  text-decoration: none;
  font-weight: 700;
}

/* Hero Section */
.hero {
  position: relative;
  text-align: center;
}
.hero img {
  width: 100%;
  height: auto;
}
.hero-caption {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
}
/* Features */
.features {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 40px 10%;
  background: #f9f9f9;
}
.feature-card {
  width: 100%;
  background: rgb(234, 234, 234);
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.234);
}
.feature-card .icon {
  font-size: 40px;
}
.feature-card button {
  margin-top: 10px;
  padding: 8px 12px;
  background: #0095ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.feature-card button:hover {
  background: #0077cc;
}
/*Calendar Features*/
.features2 {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 40px 10%;
  background: #f9f9f9;
}
.feature-card2 {
  width: 900px;
  height: 500px;
  background: white;
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}
.feature-card2 .icon {
  font-size: 40px;
}
.feature-card2 button {
  margin-top: 10px;
  padding: 8px 12px;
  background: #0095ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.feature-card2 button:hover {
  background: #0077cc;
}
/* Footer */
footer {
  background-color: rgba(21, 86, 50, 0.937);
  color: white;
  padding: 30px 10%;
}
.footer-brand {
  margin-bottom: 20px;
}
.footer-links {
  display: flex;
  justify-content: space-between;
}
.footer-links div h4 {
  margin-bottom: 10px;
}
.footer-links ul {
  list-style: none;
}
.footer-links ul li {
  margin-bottom: 0px;
  margin-left: -30px;
}
.footer-links ul li a {
  color: white;
  text-decoration: none;
}
.footer-copy {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
}
/**/
table { background-color: white; max-height: 300px;}
.container { margin-right:50%; max-width: 200%; max-height: 500px;}
/** */
#transition-panel {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #97ba9f;
  z-index: 9999;
  transform: translateY(-100%);
  transition: transform 1s ease-in-out;
  pointer-events: none;
}

#transition-panel.active {
  transform: translateY(0%);
}
/** */
#transition-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 9999;
  pointer-events: none;
  display: flex;
}
.transition-panel {
  flex: 1;
  height: 100%;
  transform: translateY(-100%);
  background-color: #97ba9f;
  transition: transform 0.6s ease-in-out;
}
#transition-container.active .transition-panel {
  transform: translateY(0%);
}
#transition-container.active .panel1 { transition-delay: 0s; }
#transition-container.active .panel2 { transition-delay: 0.1s; }
#transition-container.active .panel3 { transition-delay: 0.2s; }
#transition-container.active .panel4 { transition-delay: 0.3s; }
#transition-container.active .panel5 { transition-delay: 0.4s; }

/* Change pagination container background or spacing */
  .dataTables_paginate {
    margin-top: 20px;
    color: #24ab58;
  }

  /* Base style for pagination buttons */
  .dataTables_wrapper .dataTables_paginate .paginate_button {
    background-color: white;
    color:rgb(3, 3, 3);
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s ease;
  }

  /* Hover effect */
  .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    color: white !important;
  }

  /* Current active page */
  .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    color: white !important;
  }

  /* Disabled buttons */
  .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
    color: #ccc !important;
    border-color: #ccc !important;
    cursor: not-allowed;
  }

</style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
</head>

<body>
  <!-- Header -->
  <header>
    <div class="Emblem"> <p class="logo" style="margin-left:70px; margin-top:13px;">CDD - NIPAS & PAMB Management System</p></div> 
      <nav>
        <p class="TimeYes" id ="time" style="margin-top:-10px;"></p>
        <p class="TimeYes" id ="date" style="margin-top:-10px;"></p>
      </nav>
  </header>

  <header style="height: 50px;">
    <div class="logo"></div>
    <nav>
      <ul style="margin-top:20px;">
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
        <li><a href="https://github.com/OJT-DENR/something/raw/refs/heads/main/PAMBCS-CDD-AdminManuscript.pdf" download class="btn HowTo" onmousedown="mouseclick.play()">Download Manuscript</a></li>
        <li><a href="index.php" class="btn LogOut">Log-out</a></li>
      </ul>
    </nav>
  </header>

  <!-- Features -->
  <section class="features">
  <div class="feature-card">
    <!-- Table -->
    <div class="otherButtonsDiv">
      <a href="register.php" class="btn Create">Create Account</a>
      <a href="PAMBI_admin.php" class="btn HowTo">PAMB Database</a>
      <a href="updatenipas_admin.php" class="btn HowTo">NIPAS Database</a>
    </div>

    <table id="adminTable" class="table table-striped table-bordered text-center">
        <thead class="table-dark">
            <tr >
              <th>Name</th>
              <th>Email</th>
              <th style="width: 10%;">Actioned</th>  
            </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td>
              <form method="POST" action="delete_user.php" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <button type="submit" class="btn delete" onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
              </form>
                <button class="btn HowTo" onclick="openEditModal('<?php echo $row['id']; ?>', '<?php echo htmlspecialchars($row['name']); ?>', '<?php echo htmlspecialchars($row['password']); ?>')">
                Edit</button>
              <!-- Edit Modal -->
              <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <form method="POST">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                        <button type="button" class="btn close" data-bs-dismiss="modal" aria-label="Close">X</button>
                      </div>
                      <div class="modal-body">
                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="mb-3">
                          <label class="form-label">Name:</label>
                          <input type="label" name="edit_name" id="edit_name" class="form-control">
                        </div>
                        <div class="mb-3">
                          <label class="form-label">Password:</label>
                          <input type="password" name="edit_password" id="edit_password" class="form-control">
                          <input type="checkbox" onclick="togglePassword()" class="form-check-input mt-2"> Show Password
                        </div>
                      </div>
                        <div class="modal-footer">
                          <button type="submit" name="save_changes" class="btn btn-success">Save changes</button>
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                  </form>
                </div>
              </div>
            </td>   
            </tr>
          <?php } ?>
        </tbody>
    </table>
  </div>
  </section>
  <!-- Footer -->
  <footer>
    <div class="footer-brand">
      <h2>CDD - NIPAS & PAMB Management System</h2>
    </div>
    <div class="footer-links">
      <div>
        <h4>Company</h4>
        <ul>
          <li><p>About</p></li>
          <li><p>This website offers DENR CDD employees to help automate the process <br>of making PDF forms for each NIPAS and PAMB documents
            whilst giving <br>them a proper database where each input can be documented and updated.</p></li>
            <br>
          <li><p>Mission</p></li>
          <li><p>To mobilize our citizenry in protecting, conserving, and managing the <br>
            environment and natural resources for the present and future
            generations.</p></li>
            <br>
          <li><p>Vision</p></li>
          <li><p>A nation enjoying and sustaining its natural resources and a clean and <br>healthy environment.</p></li>
        </ul>
      </div>
      <div>
        <h4>Community</h4>
        <ul>
          <li><a href="https://calabarzon.denr.gov.ph/">Official Website</a></li>
          
        </ul>
      </div>
    </div>
    <p class="footer-copy">© 2025 DENR Region 4A</p>
  </footer>

<!-- Transition Panels -->
<!-- Transition Animation Panels -->
<div id="transition-container">
  <div class="transition-panel panel1"></div>
  <div class="transition-panel panel2"></div>
  <div class="transition-panel panel3"></div>
  <div class="transition-panel panel4"></div>
  <div class="transition-panel panel5"></div>
</div>


<script>
  
document.addEventListener("DOMContentLoaded", () => {
  const transitionContainer = document.getElementById("transition-container");

  const animatedLinks = document.querySelectorAll(
    'a[href="register.php"], a[href="PAMBI_admin.php"], a[href="updatenipas_admin.php"], a[href="index.php"]'
  );

  animatedLinks.forEach(link => {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      transitionContainer.classList.add("active");

      const href = this.getAttribute("href");
      setTimeout(() => {
        window.location.href = href;
      }, 800); // adjust to match panel animation timing
    });
  });
});
</script>



</body>
<script>
  $(document).ready(function() {
  $('#adminTable').DataTable({
    "pageLength": 3,
    "lengthMenu": [3, 5, 10],
    "lengthChange": true,
    "searching": false,
    "ordering": true,
    "info": true
  });
});

</script>

</html>

<?php $conn->close(); ?>
