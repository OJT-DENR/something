<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['name'])) {
    header("Location: login.php");
    exit;
}

// Grab user name from session
$user_name = $_SESSION['name'];

 //Database connection
 $host = "localhost"; 
 $user = "root"; // Default username for localhost
 $password = ""; // Default password is empty
 $dbname = "nipas_db"; // Your database name

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
 //Get next auto-increment ID for `nipas_table`
$sql = "SHOW TABLE STATUS LIKE 'nipas_table'";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
  $next_id = $row['Auto_increment']; // Get the next auto-increment ID
} else {
  $next_id = 1; // Default to 1 if query fails
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIPAS Form</title>
    <script>
        function showFieldGroups() {
        const noApplied = parseInt(document.querySelector('[name="NoApplied"]').value) || 0;
        for (let i = 1; i <= 20; i++) {
            const group = document.getElementById(`group${i}`);
            if (i <= noApplied) {
                group.style.display = "block";
            } else {
                group.style.display = "none";
                // Optionally clear values when hiding
                group.querySelectorAll("input").forEach(input => input.value = '');
            }
        }
        countFilledFields(); // Optional: update count display too
    }
    document.addEventListener("DOMContentLoaded", () => {
        const noAppliedInput = document.querySelector('[name="NoApplied"]');
        noAppliedInput.addEventListener("input", showFieldGroups);
    });
    function countFilledFields() {
        let count = 0;
        for (let i = 1; i <= 20; i++) {
            let tct = document.querySelector(`[name="TCT${i}"]`).value.trim();
            let lot = document.querySelector(`[name="LotN${i}"]`).value.trim();
            let area = document.querySelector(`[name="Area${i}"]`).value.trim();
            if (tct && lot && area) count++;
        }
        const noApplied = parseInt(document.querySelector('[name="NoApplied"]').value) || 0;
        const status = document.getElementById("filledStatus");
        if (count >= noApplied) {
            status.textContent = `✅ ${count} / ${noApplied} entries filled.`;
            status.style.color = "green";
        } else {
            status.textContent = `⚠️ ${count} / ${noApplied} entries filled. Please complete all.`;
            status.style.color = "red";
        }
    }
    function setupFieldListeners() {
        const fields = document.querySelectorAll('[name^="TCT"], [name^="LotN"], [name^="Area"], [name="NoApplied"]');
        fields.forEach(field => {
            field.addEventListener("input", countFilledFields);
        });
    }
    document.addEventListener("DOMContentLoaded", setupFieldListeners);

          var mouseclick = new Audio();
          mouseclick.src = "https://uploads.sitepoint.com/wp-content/uploads/2023/06/1687569402mixkit-fast-double-click-on-mouse-275.wav";

    </script>
    <style>
        body {
            font-family: sans-serif;
            background-image: linear-gradient(-225deg,rgb(80, 121, 103) 0%,rgb(53, 167, 150) 51%,rgb(108, 187, 154) 100%);
            padding: 40px;
        }
        .container {
            width: auto;
            border: 4px solid rgb(26, 112, 94);
            border-radius: 10px;
            box-shadow: 0 0 10px rgb(5, 26, 23);
            background: linear-gradient(to bottom,rgb(237, 232, 196) 0%,rgb(177, 207, 183) 90%);
            padding: 30px;
            border-radius: 10px;
            max-width: 80%;
            margin: auto;
        }
        h1 {
            text-align: Left; 
        }
        label { 
            font-weight: bold; display: block; margin-top: 10px; display:inline-block; *display: inline;
        }
        input { 
            width: 17%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputLink { 
            width: 98.5%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputNoApp { 
            width: 33%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputLocation { 
            width: 88.2%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputOwner { 
            width: 80.2%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputOrigin { 
            width: 51.5%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputPosition { 
            width: 45%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputCompany { 
            width: 56.9%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputApp { 
            width: 5%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputDirector { 
            width: 25%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputBRGY { 
            width: 25%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputProvince { 
            width: 23.9%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputAct { 
            width: 30%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        .inputRanks { 
            width: 5%; padding: 8px; margin-top: 5px; border-radius: 2px; 
        }
        textarea {
            resize: none;
            border: 2px solid black;
            border-radius: 6px;
            height: 200px;
            overflow-y: scroll;
            width: 1109px;
            text-align: left;
            background-color: rgb(244, 244, 244);
        }
        button {
            background-color: black;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            color: #fff;
            background:rgb(145, 146, 147);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
        }

        .btn:hover {
            opacity: 0.9;
            transform: scale(1.05);

        }
        .TrueFalseStyle{ 
            width: 8.5%; padding: 8px; margin-top: 5px; border-radius: 2px; border: solid black, 2px;
        }
        .btn.buttonPDF{
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 1em;
            background:rgb(26, 112, 94);
            border: 3px solid black;
            border-radius: 20px;
            border-color:rgb(30, 74, 85);
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-decoration: none;
            height: fit-content;
            width: fit-content;
            font-weight: 500;
        }
        .divBorder{
            padding-left: 10px;
            padding-right: 15px;
            border:3px solid black;
            border-radius: 5px;
            border-color:rgba(255, 255, 255, 0.76);
        }
        .divID{
            padding-left: 10px;
            padding-right: 15px;
            border:none;
            border-radius: 15px;
            text-align: left;
            font-size: 200%;
        }
        .inputDirector{
            width: 28%; padding: 8px; margin-top: 5px; border-radius: 2px ; border: 2px solid rgb(5, 26, 23);
        }
    </style>
</head>
<body>
    <a href="user_page.php" class="btn buttonPDF" onmousedown="mouseclick.play()">< Back</a>
    <p></p>
    <p></p>
    <div class="container">
        <form action="submit2.php" method="POST">
            <p style="margin-top: -20px;"></p>
            <div class="divBorder">
                <h1>NIPAS Certificate Form</h1>
                <div class="divID">
                    <label>ID:</label>
                    <span><b><?php echo $next_id; ?></b></span>
                    <input type="hidden" name="id" value="<?php echo $next_id; ?>">
                </div><br>
                        <label class="label">Created By:</label>
        <span style="font-weight: bold; color: black"><?php echo htmlspecialchars($user_name); ?></span>
        <input type="hidden" name="created_by" value="<?php echo htmlspecialchars($user_name); ?>"><br><br>
                
                <label>&nbsp;&nbsp;DATS:</label>
                <input type="text" name="dats">
                
                <label> &nbsp;&nbsp; Recieve:</label>
                <input type="text" name="Received" placeholder="Recieved by:">

                <label>&nbsp;&nbsp;Date:</label>
                <input type="text" name="Date" placeholder="Month/Date/Year">
                
                <label>&nbsp;&nbsp;Time:</label>
                <input type="text" name="Time" >
                <br><br>

                <label>&nbsp;&nbsp;Originating Office:</label>
                <input type="text" name="Originating" class="inputOrigin">
                <br><br>

                <label>&nbsp;&nbsp;Actioned by:&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </label>
                <input type="text" name="actioned" class="inputAct">

                <label>&nbsp;&nbsp;&nbsp;Position:</label>
                <input type="text" name="position" class="inputPosition">
                <br><br>
                
                <label>&nbsp;&nbsp;Applicant Name:</label>
                <input type="text" name="Applicant" >
                
                <label>&nbsp;&nbsp;&nbsp;Company:</label>
                <input type="text" name="Company" class="inputCompany">
                <br><br>

                <label>&nbsp;&nbsp;Owner Representative:</label>
                <input type="text" name="OwnerRepresentative" class="inputOwner" placeholder="on behalf of the owner/municipality">
                <br><br>

                <label>&nbsp; Location: &nbsp;&nbsp;</label>
                <input type="text" name="Location" class="inputLocation">
                <br><br>
                
                <label> &nbsp; BRGY:</label>
                <input type="text" name="BRGY" class="inputBRGY">
                
                <label> &nbsp;&nbsp; City:</label>
                <input type="text" name="MuniCity" class="inputBRGY">
                
                <label> &nbsp;&nbsp; Province:</label>
                <input type="text" name="Province" class="inputProvince">
                <br><br>
            </div>
            <br><br>
        <div class="divBorder">
        <br>
        <p style="text-align:center; font-size: large;" > <strong> REQUIREMENTS </strong></p>
            <label>&nbsp;&nbsp;No Applied:</label>
            <input type="text" name="NoApplied" class="inputApp">
            <p id="filledStatus" style="font-weight:bold; font-size: 14px; color: red;"></p>

            <label>&nbsp;&nbsp;No Applied (words):</label>
            <input type="text" name="NoAppword" >

            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Letter:</label>
            <select name="LetterTF" id="LetterTF" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
            <br><br>

            <label>&nbsp;&nbsp;Contact Person:</label>
            <input type="text" name="ContactP" class="inputNoApp">
            
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Contact Number:</label>
            <input type="text" name="ContactN" placeholder="ex: 09XX XXX XXXX">
            <br><br>

            <p style="color: red; font-size:18px;"><i>* Note: when inputting the Area value, do not include commas "," in the number. Ex: 12,000</i> ❌<i>, 12000</i> ✅</p>
        
        <div style="border: 3px solid rgba(255, 255, 255, 0.78); border-radius: 5px; background-color:rgba(214, 235, 208, 0.34); border-width: 5px;">
            <p style="text-align:center; font-size: large;" > <strong> No. Applied fill-up form: </strong></p>
            <br>
            
            <div class="tct-group" id="group1" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT1" placeholder="TCT 1">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN1" placeholder="Lot Number 1">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area1" placeholder="Area (sqm) 1">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group2" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT2" placeholder="TCT 2">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN2" placeholder="Lot Number 2">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area2" placeholder="Area (sqm) 2">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group3" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT3" placeholder="TCT 3">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN3" placeholder="Lot Number 3">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area3" placeholder="Area (sqm) 3">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group4" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT4" placeholder="TCT 4">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN4" placeholder="Lot Number 4">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area4" placeholder="Area (sqm) 4">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group5" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT5" placeholder="TCT 5">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN5" placeholder="Lot Number 5">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area5" placeholder="Area (sqm) 5">
                <br><br>
            </div>
            <br>
            
            <div class="tct-group" id="group6" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT6" placeholder="TCT 6">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN6" placeholder="Lot Number 6">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area6" placeholder="Area (sqm) 6">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group7" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT7" placeholder="TCT 7">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN7" placeholder="Lot Number 7">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area7" placeholder="Area (sqm) 7">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group8" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT8" placeholder="TCT 8">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN8" placeholder="Lot Number 8">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area8" placeholder="Area (sqm) 8">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group9" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT9" placeholder="TCT 9">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN9" placeholder="Lot Number 9">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area9" placeholder="Area (sqm) 9">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group10" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT10" placeholder="TCT 10">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN10" placeholder="Lot Number 10">
                
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area10" placeholder="Area (sqm) 10">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group11" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT11" placeholder="TCT 11">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN11" placeholder="Lot Number 11">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area11" placeholder="Area (sqm) 11">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group12" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT12" placeholder="TCT 12">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN12" placeholder="Lot Number 12">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area12" placeholder="Area (sqm) 12">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group13" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT13" placeholder="TCT 13">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN13" placeholder="Lot Number 13">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area13" placeholder="Area (sqm) 13">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group14" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT14" placeholder="TCT 14">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN14" placeholder="Lot Number 14">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area14" placeholder="Area (sqm) 14">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group15" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT15" placeholder="TCT 15">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN15" placeholder="Lot Number 15">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area15" placeholder="Area (sqm) 15">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group16" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT16" placeholder="TCT 16">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN16" placeholder="Lot Number 16">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area16" placeholder="Area (sqm) 16">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group17" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT17" placeholder="TCT 17">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN17" placeholder="Lot Number 17">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area17" placeholder="Area (sqm) 17">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group18" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT18" placeholder="TCT 18">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN18" placeholder="Lot Number 18">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area18" placeholder="Area (sqm) 18">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group19" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT19" placeholder="TCT 19">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN19" placeholder="Lot Number 19">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area19" placeholder="Area (sqm) 19">
                <br><br>
            </div>
            <br>

            <div class="tct-group" id="group20" style="display:none; padding-left: 15%; padding-right: 10%;">
                <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TCT:</label>
                <input type="text" name="TCT20" placeholder="TCT 20">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LOTN:</label>
                <input type="text" name="LotN20" placeholder="Lot Number 20">
                
                <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Area:</label>
                <input type="text" name="Area20" placeholder="Area (sqm) 20">
                <br><br>
            </div>
        </div>
        <br><br>
            
            <label>Lot Data:</label>
            <input type="text" name="LotData" >

            <label> &nbsp;&nbsp; PSU/PSD/CSD</label>
            <input type="text" name="PPC" >

            <label> &nbsp;&nbsp;Approved:</label>
            <select name="Approved" id="Approved" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <label> &nbsp;&nbsp; SPA:</label>
            <select name="SPA" id="SPA" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
            <br><br>
            <label>Secretary:</label>
            <select name="Sec" id="Sec" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
            
            <label>&nbsp;&nbsp;Deed of Sale:</label>
            <select name="DoS" id="DoS" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
        
            <label> &nbsp;&nbsp;Inspection:</label>
            <select name="Inspect" id="Inspect" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <label> &nbsp;&nbsp;Map Prep:</label>
            <select name="Map" id="Map" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>

            <label> &nbsp;&nbsp; Geotagged Photos:</label>
            <select name="geo" id="geo" class="TrueFalseStyle">
                <option value="None">N/A</option>
                <option value="True">True</option>
                <option value="False">False</option>
            </select>
            <br><br>

            <label>&nbsp;&nbsp;Total: &nbsp;&nbsp;&nbsp; </label>
            <input type="text" name="Total" >

            <br><br>
            <label> &nbsp;&nbsp;Others:</label>
            <input type="text" name="Others" >
            <br><br>
        </div>
        <br><br>

        <div class="divBorder">
            <br><br>
            <label>Amount:</label>
            <input type="text" name="Amount" >

            <label>Amount Words:</label>
            <input type="text" name="TotalWords" >

            <br><br>
            <label>Findings (Protected & Within):</label><br><br>
            <textarea name="Findings" ></textarea>

            <br><br>
            <label>Purpose:</label><br><br>
            <textarea name="Purpose" ></textarea>

            <br><br>
            <label>Remarks:</label><br><br>
            <textarea name="Remarks" ></textarea>

            <br><br>
            <label>Name Approved: &nbsp;&nbsp;&nbsp;&nbsp;</label>
            <input type="text" name="Director" class="inputDirector" style="margin-left:3px;">

            <label>&nbsp;&nbsp;CESO Rank:</label>
            <select name="Rank1" id="Rank1" class="TrueFalseStyle">
                <option value="CESO I">CESO I</option>
                <option value="CESO II">CESO II</option>
                <option value="CESO III">CESO III</option>
                <option value="CESO IV">CESO IV</option>
            </select>
            
            <label>&nbsp;&nbsp;Position:</label>
            <select name="director_pos" id="director_pos" class="inputDirector">
                <option value="Regional Executive Director/PAMB Chairperson">Regional Executive Director/PAMB Chairperson</option>
            </select>

             <br><br>
            <label>Name Recommend: </label>
            <input type="text" name="NameRecommend" class="inputDirector" style="margin-left:3px;">

            <label>&nbsp;&nbsp;CESO Rank:</label>
            <select name="Rank2" id="Rank2" class="TrueFalseStyle">
                <option value="CESE">CESE</option>
            </select>

            <label>&nbsp;&nbsp;Position:</label>
            <select name="PositionRecommend" id="PositionRecommend" class="inputDirector">
                <option value="OIC-Assistant Regional Director for
Technical Services">OIC-Assistant Regional Director for
Technical Services</option>
            </select>

            <br><br>
            <label>Chief CDD: </label>
            <input type="text" name="ChiefCDD" class="inputDirector" style="margin-left:3px;">

            <label>&nbsp;&nbsp;Position: </label>
            <input type="text" name="ChiefCDDPos" class="inputDirector" style="margin-left:3px;">

            <br><br>
            <label>Link:</label>
            <br><br>
            <input type="text" name="links" class="inputLink" placeholder="https://example.com">
            <br><br>

            <label>Control Number:</label>
            <input type="text" name="ControlNumber" >
            
            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Date Approved:</label>
            <input type="text" name="DateApproved" >

            <label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Date Released:</label>
            <input type="text" name="DateReleased" >
            <br><br>
        </div>
        <button type="submit" onmousedown="mouseclick.play()">Submit</button>
        </form>
    </div>
</body>
</html>