<?php
require 'vendor/autoload.php'; // Ensure Dompdf is installed
require 'db.php'; // Database connection

use Dompdf\Dompdf;
use Dompdf\Options;

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate ID input
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No valid ID provided.");
}

$id = intval($_GET['id']); // Sanitize ID

// Fetch data from database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if record exists
if ($result->num_rows == 0) {
    die("Error: No record found with ID " . $id);
}

$row = $result->fetch_assoc();

// Fetch necessary data
$LotN1 = isset($row['LotN1']) ? htmlspecialchars($row['LotN1']) : 'N/A';
$LotN2 = isset($row['LotN2']) ? htmlspecialchars($row['LotN2']) : 'N/A';
$LotN3 = isset($row['LotN3']) ? htmlspecialchars($row['LotN3']) : 'N/A';
$LotN4 = isset($row['LotN4']) ? htmlspecialchars($row['LotN4']) : 'N/A';
$LotN5 = isset($row['LotN5']) ? htmlspecialchars($row['LotN5']) : 'N/A';
$LotN6 = isset($row['LotN6']) ? htmlspecialchars($row['LotN6']) : 'N/A';
$LotN7 = isset($row['LotN7']) ? htmlspecialchars($row['LotN7']) : 'N/A';
$LotN8 = isset($row['LotN8']) ? htmlspecialchars($row['LotN8']) : 'N/A';
$LotN9 = isset($row['LotN9']) ? htmlspecialchars($row['LotN9']) : 'N/A';
$LotN10 = isset($row['LotN10']) ? htmlspecialchars($row['LotN10']) : 'N/A';
$LotN11 = isset($row['LotN11']) ? htmlspecialchars($row['LotN11']) : 'N/A';
$LotN12 = isset($row['LotN12']) ? htmlspecialchars($row['LotN12']) : 'N/A';
$LotN13 = isset($row['LotN13']) ? htmlspecialchars($row['LotN13']) : 'N/A';
$LotN14 = isset($row['LotN14']) ? htmlspecialchars($row['LotN14']) : 'N/A';
$LotN15 = isset($row['LotN15']) ? htmlspecialchars($row['LotN15']) : 'N/A';
$LotN16 = isset($row['LotN16']) ? htmlspecialchars($row['LotN16']) : 'N/A';
$LotN17 = isset($row['LotN17']) ? htmlspecialchars($row['LotN17']) : 'N/A';
$LotN18 = isset($row['LotN18']) ? htmlspecialchars($row['LotN18']) : 'N/A';
$LotN19 = isset($row['LotN19']) ? htmlspecialchars($row['LotN19']) : 'N/A';
$LotN20 = isset($row['LotN20']) ? htmlspecialchars($row['LotN20']) : 'N/A';
$TCT1 = isset($row['TCT1']) ? htmlspecialchars($row['TCT1']) : 'N/A';
$TCT2 = isset($row['TCT2']) ? htmlspecialchars($row['TCT2']) : 'N/A';
$TCT3 = isset($row['TCT3']) ? htmlspecialchars($row['TCT3']) : 'N/A';
$TCT4 = isset($row['TCT4']) ? htmlspecialchars($row['TCT4']) : 'N/A';
$TCT5 = isset($row['TCT5']) ? htmlspecialchars($row['TCT5']) : 'N/A';
$TCT6 = isset($row['TCT6']) ? htmlspecialchars($row['TCT6']) : 'N/A';
$TCT7 = isset($row['TCT7']) ? htmlspecialchars($row['TCT7']) : 'N/A';
$TCT8 = isset($row['TCT8']) ? htmlspecialchars($row['TCT8']) : 'N/A';
$TCT9 = isset($row['TCT9']) ? htmlspecialchars($row['TCT9']) : 'N/A';
$TCT10 = isset($row['TCT10']) ? htmlspecialchars($row['TCT10']) : 'N/A';
$TCT11 = isset($row['TCT11']) ? htmlspecialchars($row['TCT11']) : 'N/A';
$TCT12 = isset($row['TCT12']) ? htmlspecialchars($row['TCT12']) : 'N/A';
$TCT13 = isset($row['TCT13']) ? htmlspecialchars($row['TCT13']) : 'N/A';
$TCT14 = isset($row['TCT14']) ? htmlspecialchars($row['TCT14']) : 'N/A';
$TCT15 = isset($row['TCT15']) ? htmlspecialchars($row['TCT15']) : 'N/A';
$TCT16 = isset($row['TCT16']) ? htmlspecialchars($row['TCT16']) : 'N/A';
$TCT17 = isset($row['TCT17']) ? htmlspecialchars($row['TCT17']) : 'N/A';
$TCT18 = isset($row['TCT18']) ? htmlspecialchars($row['TCT18']) : 'N/A';
$TCT19 = isset($row['TCT19']) ? htmlspecialchars($row['TCT19']) : 'N/A';
$TCT20 = isset($row['TCT20']) ? htmlspecialchars($row['TCT20']) : 'N/A';
$Area1 = isset($row['Area1']) ? htmlspecialchars($row['Area1']) : 'N/A';
$Area2 = isset($row['Area2']) ? htmlspecialchars($row['Area2']) : 'N/A';
$Area3 = isset($row['Area3']) ? htmlspecialchars($row['Area3']) : 'N/A';
$Area4 = isset($row['Area4']) ? htmlspecialchars($row['Area4']) : 'N/A';
$Area5 = isset($row['Area5']) ? htmlspecialchars($row['Area5']) : 'N/A';
$Area6 = isset($row['Area6']) ? htmlspecialchars($row['Area6']) : 'N/A';
$Area7 = isset($row['Area7']) ? htmlspecialchars($row['Area7']) : 'N/A';
$Area8 = isset($row['Area8']) ? htmlspecialchars($row['Area8']) : 'N/A';
$Area9 = isset($row['Area9']) ? htmlspecialchars($row['Area9']) : 'N/A';
$Area10 = isset($row['Area10']) ? htmlspecialchars($row['Area10']) : 'N/A';
$Area11 = isset($row['Area11']) ? htmlspecialchars($row['Area11']) : 'N/A';
$Area12 = isset($row['Area12']) ? htmlspecialchars($row['Area12']) : 'N/A';
$Area13 = isset($row['Area13']) ? htmlspecialchars($row['Area13']) : 'N/A';
$Area14 = isset($row['Area14']) ? htmlspecialchars($row['Area14']) : 'N/A';
$Area15 = isset($row['Area15']) ? htmlspecialchars($row['Area15']) : 'N/A';
$Area16 = isset($row['Area16']) ? htmlspecialchars($row['Area16']) : 'N/A';
$Area17 = isset($row['Area17']) ? htmlspecialchars($row['Area17']) : 'N/A';
$Area18 = isset($row['Area18']) ? htmlspecialchars($row['Area18']) : 'N/A';
$Area19 = isset($row['Area19']) ? htmlspecialchars($row['Area19']) : 'N/A';
$Area20 = isset($row['Area20']) ? htmlspecialchars($row['Area20']) : 'N/A';
$applicant = isset($row['applicant']) ? htmlspecialchars($row['applicant']) : 'N/A';
$purpose = isset($row['purpose']) ? htmlspecialchars($row['purpose']) : 'N/A';
$amount = isset($row['amount']) ? htmlspecialchars($row['amount']) : 'N/A';
$totalwords = isset($row['totalwords']) ? htmlspecialchars($row['totalwords']) : 'N/A';
$Area_sqm2 = isset($row['Area_sqm2']) ? htmlspecialchars($row['Area_sqm2']) : 'N/A';
$Area_sqm3 = isset($row['Area_sqm3']) ? htmlspecialchars($row['Area_sqm3']) : 'N/A';
$findings = isset($row['findings']) ? htmlspecialchars($row['findings']) : 'N/A';
$location = isset($row['location']) ? htmlspecialchars($row['location']) : 'N/A';
$noapplied = isset($row['NoApplied']) ? htmlspecialchars($row['NoApplied']) : 'N/A';
$ownerrepresentative = isset($row['OwnerRepresentative']) ? htmlspecialchars($row['OwnerRepresentative']) : 'N/A';
$Director = isset($row['Director']) ? htmlspecialchars($row['Director']) : 'N/A';
$director_pos = isset($row['director_pos']) ? htmlspecialchars($row['director_pos']) : 'N/A';

$NameRec = isset($row['NameRecommend']) ? htmlspecialchars($row['NameRecommend']) : 'N/A';
$PosRec = isset($row['PositionRecommend']) ? htmlspecialchars($row['PositionRecommend']) : 'N/A'; 

$Rank1 = isset($row['Rank1']) ? htmlspecialchars($row['Rank1']) : 'N/A';
$Rank2 = isset($row['Rank2']) ? htmlspecialchars($row['Rank2']) : 'N/A';

$areas = [];
$tcts = [];
$lotNumbers = []; // Store Lot Numbers
$totalArea = 0.0000; // Default total to 4 decimal places

// Fetch all columns from the database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
if (!$row) {
    die("Error: No record found.");
}
// Loop through dynamically (up to $noapplied)
for ($i = 1; $i <= $noapplied; $i++) {
    $lotKey = "LotN" . $i;
    $tctKey = "TCT" . $i;
    $areaKey = "Area" . $i;

    // Validate Lot Number field
    $lotNumbers[] = !empty($row[$lotKey]) ? htmlspecialchars($row[$lotKey]) : "N/A";

    // Validate TCT field
    $tcts[] = !empty($row[$tctKey]) ? htmlspecialchars($row[$tctKey]) : "N/A";

    // Validate Area field
    if (is_numeric($row[$areaKey])) {
        $areaValue = floatval($row[$areaKey]); // Convert to float
        $areas[] = $areaValue; // Store the value
        $totalArea += $areaValue; // Add to total
    } else {
        $areas[] = 0.0000; // Default if invalid
    }
}
// Initialize table HTML
// Initialize table HTML
$tableHTML = "";
if ($noapplied > 1) {
    $tableHTML .= '<table border="1" cellspacing="0" cellpadding="0" style="width: 95%; line-height: 0.6; border-collapse: collapse; font-size: 16px; text-align: center; margin-left:20px;">';
    // Table Header
    $tableHTML .= "<tr style='font-weight: bold;'>
                    <th style='width: 70%;'>Lot No.</th>
                    <th style='width: 80%;'>TCT No.</th>
                    <th style='width: 30%;'>Area (ha)</th>
                   </tr>";
    // Loop through all applied lots
    foreach ($areas as $index => $areaValue) {
        $tableHTML .= "<tr>
                        <td>" . $lotNumbers[$index] . "</td>
                        <td>" . $tcts[$index] . "</td>
                        <td>" . number_format($areaValue / 10000, 4) . "</td>
                      </tr>";
    }
    // Total Row
    $tableHTML .= "<tr style='font-weight: bold;'>
                    <td colspan='2' style='text-align:right; padding-right:15px;'>TOTAL</td>
                    <td style='text-align:center;'>" . number_format($totalArea / 10000, 4) . "</td>
                   </tr>";

    $tableHTML .= '</table>';
} else {
    $tableHTML .= '<p style="font-weight: bold; text-align: center; margin-top:10px;">No table. You have only 1 or no lots.</p>';
}

// Dompdf options
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);
$backgroundImage = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/Legal.png";
$dompdf = new Dompdf($options);

$backgroundImage2 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI_Header2.png";
$backgroundImage3 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Footer.png";


//padding body: top, right, bottom, left
// Start HTML generation
$html = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
    @page { size: Legal; margin: 150px 0px 0px 0px; }
    body {
        line-height: 1.1;
        font-family: "Times New Roman", serif;
        font-size: 16px;
        padding: 0px 60px 100px 70px;
        text-align: justify;
        margin-left:-10px;
    }
    .header-content {
        position: fixed;
        top: -95px; /* also relative to margin */
        left: 0;
        right: 0;
        height: 110px;
        background: url("' . $backgroundImage2 . '") no-repeat;
        background-size: cover;
    }
    .footer-content {
        position: fixed;
        bottom: -80px; /* also relative to margin */
        left: 0;
        right: 0;
        height: 100px;
        background: url("' . $backgroundImage3 . '") no-repeat;
        background-size: cover;
    }
    .content { font-size: 16px; line-height: 1.2;}
        h2, h4 { text-align: center; font-weight: bold; }
        .approved-section2 { text-align: center; line-height: 0.9; margin-left: 285px; }
        table {
        width: 50%;
        border-collapse: collapse;
        font-size: 18px; /* Same as body text */
        text-align: center;
    }
    th, td {
        border: 1px solid black;
        padding: 8px;
        font-size: 16px; /* Ensures table text matches body font size */
    }
    .underline {
        border-bottom: 1px solid black;
        display: inline-block;
        width: 100px;
    }
    .underline2 {
        border-bottom: 1px solid black;
        display: inline-block;
        width: 120px;
    }
    .signature {
        text-align: center;
        margin-top: 40px;
        margin-right: 336px;
    }
    .approved-section2 {
        text-align: center;
        line-height: 0.9;
        display: flex;
        align-items: flex-end; /* Aligns content to the right */
        flex-direction: column;
        /* Ensures text is aligned to the right */
        margin-left: 285px; /* Adjust as needed */
    }
    .approved-section3 {
        text-align: center;
        line-height: 0.9;
        display: flex;
        align-items: flex-end; /* Aligns content to the right */
        flex-direction: column;
        /* Ensures text is aligned to the right */
         margin-left: 165px; /* Adjust as needed */
        margin-bottom:45px;
    }
    </style>
</head>
<body >
    <div style="position: fixed; top: -140px; left: 0; right: 0; height: 100px; text-align: center;">
        <img src="' . $backgroundImage2 . '" style="width: 100%; height: auto;" />
    </div>

    <div style="position: fixed; bottom: 40px; left: 0; right: 0; height: 70px; text-align: center;">
        <img src="' . $backgroundImage3 . '" style="width: 100%; height: auto;" />
    </div>

    <div class="content" style="margin-left:40px; margin-right:50px;">
        <p style=" margin-top:-30px;"></p>
        <h2>CERTIFICATION</h2>
        <h4 style="margin-top:-20px;">NIPAS Certification No. <span class="underline"></span></h4>

        <p><strong>TO WHOM IT MAY CONCERN:</strong></p>
        <p style="text-indent:40px;">
            This is to certify that based on the verification made by this Office, the following lots located at <strong>'.$location.'</strong> with an area of <strong> '.  number_format($totalArea/10000, 4) . ' hectares 
            </strong> are '.$findings.'</strong>.
        </p>

        <!-- Display table or message -->
        <div>' . $tableHTML . '</div>

        <p style="text-indent:40px;">
            This Certification is issued in accordance with the provision of DAO No. 2022-10, otherwise known as the Revised DENR Manual of Authorities 
            on Technical Matters, and as requested by <strong>' . $applicant . '</strong>,'.$ownerrepresentative.' for the purpose of <strong>' . $purpose . '</strong>.
        </p>

        <p style="margin-top:20px; text-indent:40px;">
            A verification fee amounting to <strong>'.$totalwords.' (<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>' . $amount . ')</strong> was paid under  
            <strong>OR No.</strong> <span class="underline2"></span> dated <span class="underline2"></span>.
        </p>

        <p style="margin-top:32px; text-indent:40px;">
            Issued this day of <strong><span class="underline2"></span></strong> at Mayapa Main Road, along SLEX, Brgy. Mayapa, Calamba City, Laguna.
        </p>
        <p></p>
        <br>
        <p style="text-indent:34px;">Recommending Approval:</p>

        <div class="signature">
            <p><strong> '.$NameRec.'</strong>, <em><i>'.$Rank2.'</i></em> <br>'.$PosRec.'</p>
        </div>
            <br><br>
        <p class="approved-section3">Approved by:</p>
        <div class="approved-section2">
            <p><strong>'.$Director.'</strong>, <em><i>'.$Rank1.'</i></em> <br>
                '.$director_pos.'</p>
        </div>
    </div>
</body>
</html>';

// Load HTML to Dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('Legal', 'portrait');
$dompdf->render();

// Force file download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="NIPAS_Certification_' . $applicant . '.pdf"');
echo $dompdf->output();

exit;
?>