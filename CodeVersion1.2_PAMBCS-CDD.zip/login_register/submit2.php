<?php
session_start();
// Database connection
$host = "localhost";
$user = "root"; // Default username
$password = ""; // Default password is empty
$dbname = "nipas_db"; // Your database name

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$created_by = $_SESSION['name'] ?? 'Unknown';

// Retrieve form data safely
$dats = isset($_POST['dats']) ? $_POST['dats'] : null;
$received = isset($_POST['Received']) ? $_POST['Received'] : null;
$date = isset($_POST['Date']) ? $_POST['Date'] : null;
$time = isset($_POST['Time']) ? $_POST['Time'] : null;
$originating = isset($_POST['Originating']) ? $_POST['Originating'] : null;
$actioned = isset($_POST['actioned']) ? $_POST['actioned'] : null;
$position = isset($_POST['position']) ? $_POST['position'] : null;
$applicant = isset($_POST['Applicant']) ? $_POST['Applicant']: null;
$company = isset($_POST['Company']) ? $_POST['Company'] : null;
$ownerrepresentative = isset($_POST['OwnerRepresentative']) ? $_POST['OwnerRepresentative'] : null;
$location = isset($_POST['Location']) ? $_POST['Location'] : null;
$brgy = isset($_POST['BRGY']) ? $_POST['BRGY'] : null;
$municity = isset($_POST['MuniCity']) ? $_POST['MuniCity'] : null;
$province = isset($_POST['Province']) ? $_POST['Province'] : null;
$noapplied = isset($_POST['NoApplied']) ? $_POST['NoApplied'] : null;
$noappword = isset($_POST['NoAppword']) ? $_POST['NoAppword'] : null;
$lettertf = isset($_POST['LetterTF']) ? $_POST['LetterTF'] : null;
$contactp = isset($_POST['ContactP']) ? $_POST['ContactP'] : null;
$contactn = isset($_POST['ContactN']) ? $_POST['ContactN'] : null;
$tct1 = isset($_POST['TCT1']) ? $_POST['TCT1'] : null;
$tct2 = isset($_POST['TCT2']) ? $_POST['TCT2'] : null;
$tct3 = isset($_POST['TCT3']) ? $_POST['TCT3'] : null;
$tct4 = isset($_POST['TCT4']) ? $_POST['TCT4'] : null;
$tct5 = isset($_POST['TCT5']) ? $_POST['TCT5'] : null;
$tct6 = isset($_POST['TCT6']) ? $_POST['TCT6'] : null;
$tct7 = isset($_POST['TCT7']) ? $_POST['TCT7'] : null;
$tct8 = isset($_POST['TCT8']) ? $_POST['TCT8'] : null;
$tct9 = isset($_POST['TCT9']) ? $_POST['TCT9'] : null;
$tct10 = isset($_POST['TCT10']) ? $_POST['TCT10'] : null;
$tct11 = isset($_POST['TCT11']) ? $_POST['TCT11'] : null;
$tct12 = isset($_POST['TCT12']) ? $_POST['TCT12'] : null;
$tct13 = isset($_POST['TCT13']) ? $_POST['TCT13'] : null;
$tct14 = isset($_POST['TCT14']) ? $_POST['TCT14'] : null;
$tct15 = isset($_POST['TCT15']) ? $_POST['TCT15'] : null;
$tct16 = isset($_POST['TCT16']) ? $_POST['TCT16'] : null;
$tct17 = isset($_POST['TCT17']) ? $_POST['TCT17'] : null;
$tct18 = isset($_POST['TCT18']) ? $_POST['TCT18'] : null;
$tct19 = isset($_POST['TCT19']) ? $_POST['TCT19'] : null;
$tct20 = isset($_POST['TCT20']) ? $_POST['TCT20'] : null;

$LotN1= isset($_POST['LotN1']) ? $_POST['LotN1'] : null;
$LotN2 = isset($_POST['LotN2']) ? $_POST['LotN2'] : null;
$LotN3 = isset($_POST['LotN3']) ? $_POST['LotN3'] : null;
$LotN4= isset($_POST['LotN4']) ? $_POST['LotN4'] : null;
$LotN5 = isset($_POST['LotN5']) ? $_POST['LotN5'] : null;
$LotN6 = isset($_POST['LotN6']) ? $_POST['LotN6'] : null;
$LotN7 = isset($_POST['LotN7']) ? $_POST['LotN7'] : null;
$LotN8= isset($_POST['LotN8']) ? $_POST['LotN8'] : null;
$LotN9 = isset($_POST['LotN9']) ? $_POST['LotN9'] : null;
$LotN10 = isset($_POST['LotN10']) ? $_POST['LotN10'] : null;
$LotN11 = isset($_POST['LotN11']) ? $_POST['LotN11'] : null;
$LotN12 = isset($_POST['LotN12']) ? $_POST['LotN12'] : null;
$LotN13 = isset($_POST['LotN13']) ? $_POST['LotN13'] : null;
$LotN14 = isset($_POST['LotN14']) ? $_POST['LotN14'] : null;
$LotN15 = isset($_POST['LotN15']) ? $_POST['LotN15'] : null;
$LotN16 = isset($_POST['LotN16']) ? $_POST['LotN16'] : null;
$LotN17 = isset($_POST['LotN17']) ? $_POST['LotN17'] : null;
$LotN18 = isset($_POST['LotN18']) ? $_POST['LotN18'] : null;
$LotN19 = isset($_POST['LotN19']) ? $_POST['LotN19'] : null;
$LotN20 = isset($_POST['LotN20']) ? $_POST['LotN20'] : null;

$Area1 = isset($_POST['Area1']) ? $_POST['Area1'] : null;
$Area2 = isset($_POST['Area2']) ? $_POST['Area2'] : null;
$Area3 = isset($_POST['Area3']) ? $_POST['Area3'] : null;
$Area4 = isset($_POST['Area4']) ? $_POST['Area4'] : null;
$Area5 = isset($_POST['Area5']) ? $_POST['Area5'] : null;
$Area6 = isset($_POST['Area6']) ? $_POST['Area6'] : null;
$Area7 = isset($_POST['Area7']) ? $_POST['Area7'] : null;
$Area8 = isset($_POST['Area8']) ? $_POST['Area8'] : null;
$Area9 = isset($_POST['Area9']) ? $_POST['Area9'] : null;
$Area10 = isset($_POST['Area10']) ? $_POST['Area10'] : null;
$Area11 = isset($_POST['Area11']) ? $_POST['Area11'] : null;
$Area12 = isset($_POST['Area12']) ? $_POST['Area12'] : null;
$Area13 = isset($_POST['Area13']) ? $_POST['Area13'] : null;
$Area14 = isset($_POST['Area14']) ? $_POST['Area14'] : null;
$Area15 = isset($_POST['Area15']) ? $_POST['Area15'] : null;
$Area16 = isset($_POST['Area16']) ? $_POST['Area16'] : null;
$Area17 = isset($_POST['Area17']) ? $_POST['Area17'] : null;
$Area18 = isset($_POST['Area18']) ? $_POST['Area18'] : null;
$Area19 = isset($_POST['Area19']) ? $_POST['Area19'] : null;
$Area20 = isset($_POST['Area20']) ? $_POST['Area20'] : null;

$lotdata = isset($_POST['LotData']) ? $_POST['LotData'] : null;

$approved = isset($_POST['Approved']) ? $_POST['Approved'] : null;
$ppc = isset($_POST['PPC']) ? $_POST['PPC'] : null;

$total = isset($_POST['Total']) ? $_POST['Total'] : null;
$spa = isset($_POST['SPA']) ? $_POST['SPA'] : null;
$sec = isset($_POST['Sec']) ? $_POST['Sec'] : null;
$dos = isset($_POST['DoS']) ? $_POST['DoS'] : null;
$others = isset($_POST['Others']) ? $_POST['Others'] : null;
$inspect = isset($_POST['Inspect']) ? $_POST['Inspect'] : null;
$map = isset($_POST['Map']) ? $_POST['Map'] : null;
$geo = isset($_POST['geo']) ? $_POST['geo'] : null;
$amount = isset($_POST['Amount']) ? $_POST['Amount'] : null;
$totalwords = isset($_POST['TotalWords']) ? $_POST['TotalWords'] : null;
$findings = isset($_POST['Findings']) ? $_POST['Findings'] : null;
$purpose = isset($_POST['Purpose']) ? $_POST['Purpose'] : null;
$remarks = isset($_POST['Remarks']) ? $_POST['Remarks'] : null;
$Director = isset($_POST['Director']) ? $_POST['Director'] : null;
$director_pos = isset($_POST['director_pos']) ? $_POST['director_pos'] : null; 
$NameRec = isset($_POST['NameRecommend']) ? $_POST['NameRecommend'] : null;
$PosRec = isset($_POST['PositionRecommend']) ? $_POST['PositionRecommend'] : null;
$ChiefCDD = isset($_POST['ChiefCDD']) ? $_POST['ChiefCDD'] : null;
$ChiefCDDPos = isset($_POST['ChiefCDDPos']) ? $_POST['ChiefCDDos'] : null;
$links = isset($_POST['links']) ? $_POST['links'] :null;

$Rank1 = isset($_POST['Rank1']) ? $_POST['Rank1'] : null;
$Rank2 = isset($_POST['Rank2']) ? $_POST['Rank2'] : null;

$ControlNumber = isset($_POST['ControlNumber']) ? $_POST['ControlNumber'] :null;
$DateApproved = isset($_POST['DateApproved']) ? $_POST['DateApproved'] :null;
$DateReleased = isset($_POST['DateReleased']) ? $_POST['DateReleased'] :null;


// Prepare and execute SQL statement
$stmt = $conn->prepare("INSERT INTO nipas_table 
    (dats, Received, date, time, originating, actioned,position, Applicant, Company, ownerrepresentative, Location, brgy, Municity, province, NoApplied, NoAppword, lettertf, contactp, contactn, tct1,tct2,tct3,tct4,tct5,tct6,tct7,tct8,tct9,tct10,tct11,tct12,tct13,tct14,tct15,tct16,tct17,tct18,tct19,tct20, LotN1,LotN2,LotN3,LotN4,LotN5,LotN6,LotN7,LotN8,LotN9,LotN10,LotN11,LotN12,LotN13,LotN14,LotN15,LotN16,LotN17,LotN18,LotN19,LotN20, Area1,Area2,Area3,Area4,Area5,Area6,Area7,Area8,Area9,Area10,Area11,Area12,Area13,Area14,Area15,Area16,Area17,Area18,Area19,Area20, LotData, approved, ppc, total, spa, sec, dos, others, inspect, map, geo, amount, TotalWords, findings, purpose, remarks,Director,director_pos,NameRecommend,PositionRecommend,ChiefCDD,ChiefCDDPos,links, Rank1, Rank2, ControlNumber, DateApproved, DateReleased, created_by) 
    VALUES (?, ?,? ,?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? ,? ,?,?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

$stmt->bind_param("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", 
    $dats, $received, $date, $time, $originating, $actioned, $position , $applicant, $company, $ownerrepresentative, $location, $brgy, $municity, $province, $noapplied, $noappword, $lettertf, $contactp, $contactn, $tct1,$tct2,$tct3,$tct4,$tct5,$tct6,$tct7,$tct8,$tct9,$tct10,$tct11,$tct12,$tct13,$tct14,$tct15,$tct16,$tct17,$tct18,$tct19,$tct20, $LotN1,$LotN2,$LotN3,$LotN4,$LotN5,$LotN6,$LotN7,$LotN8,$LotN9,$LotN10,$LotN11,$LotN12,$LotN13,$LotN14,$LotN15,$LotN16,$LotN17,$LotN18,$LotN19,$LotN20, $Area1,$Area2,$Area3,$Area4,$Area5,$Area6,$Area7,$Area8,$Area9,$Area10,$Area11,$Area12,$Area13,$Area14,$Area15,$Area16,$Area17,$Area18,$Area19,$Area20, $lotdata, $approved, $ppc, $total, $spa, $sec, $dos, $others, $inspect, $map, $geo, $amount, $totalwords, $findings, $purpose, $remarks,$Director,$director_pos,$NameRec,$PosRec,$links,$ChiefCDD, $ChiefCDDPos, $Rank1, $Rank2, $ControlNumber, $DateApproved, $DateReleased, $created_by);

    if ($stmt->execute()) {
        echo "<script>alert('Data saved successfully!'); window.location.href='nipas.php';</script>";
    } else {
        echo "<script>alert('Error: Could not save data.'); window.location.href='form.html';</script>";
    }

$stmt->close();
$conn->close();
?>
