<?php
require 'dbpamb.php'; // make sure this connects to your DB

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);

    // Optional: check if it exists first before deleting
    $stmt = $conn->prepare("DELETE FROM clearance WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: PAMBIDATA.php?msg=deleted");
        exit();
    } else {
        echo "Failed to delete record.";
    }
}
?>