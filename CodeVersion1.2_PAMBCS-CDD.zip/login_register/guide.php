<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>How To</title>

    <script>
    /* Time and date */
          function updateTime() {
              const optionsTime = { timeZone: "Asia/japan", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true };
              const optionsDate = { timeZone: "Asia/japan", weekday: "long", year: "numeric", month: "long", day: "numeric" };
              const time = new Date().toLocaleTimeString("en-US", optionsTime);
              const date = new Date().toLocaleDateString("en-US", optionsDate);
              document.getElementById("time").innerText = time;
              document.getElementById("date").innerText = date;
          }
          setInterval(updateTime, 1000);

          var mouseclick = new Audio();
          mouseclick.src = "https://uploads.sitepoint.com/wp-content/uploads/2023/06/1687569402mixkit-fast-double-click-on-mouse-275.wav";

  </script>

  <style>
    /* Reset & Base */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body{
  background-color: cadetblue;
  font-family: "Source Sans Pro", "Arial", sans-serif;
  font-size: 18px;
  color:rgb(235, 234, 231);
  line-height: normal;    
}
p{
  padding-left: 2%;
  padding-right: 2%;
}
h1,h2,h3{
  color:white;
}
h1{            
  text-align: center;
}
h2{
  padding-left: 2%;
}
.indentRight{
  margin-right: 30px;
}
.DivPambi{
  border: 2px solid rgb(79, 111, 62);
  border-radius: 10px;
  padding-right: 30px;
  padding-left: 30px;
  line-height: 25px;
  width: 90%;
  margin-left: 5%;
  margin-right: 5%;
  background-position: center;
}
.TimeYes{
  position: relative;
  text-align: right;
  color: rgb(252, 252, 252);
  top: 12px;
  font-style: Times;
  font-size:16px;
  margin-right: 0px;
  padding-left: 0%;
  padding-right: 0%;
}
.Emblem{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/Seal_of_the_Department_of_Environment_and_Natural_Resources.svg.png");
  background-size: 60px 60px;
  background-repeat: no-repeat;
  height: 60px;
  margin-top:0px;
  margin-left:-40px;
}
/* Header */
header {
  background-color: rgba(21, 86, 50, 0.937);
  display: flex;
  justify-content: space-between;
  padding: 20px 10%;
  align-items: center;
  color: white;
  box-shadow: 0px 5px 5px rgb(53, 53, 53);
  height: 90px;
}
.NIPASpic{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Icon.png");
  background-size: contain;
  height: 200px;
  background-repeat: no-repeat;
  background-position: center;
}
.PAMBpic{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMB_Icon.png");
  background-size: contain;
  height: 200px;
  background-repeat: no-repeat;
  background-position: center;
}
.btn {
  display: inline-block;
  margin: 10px;
  padding: 8px 15px;
  font-size: 1em;
  font-style: oblique;
  color: whitesmoke;
  background:rgb(28, 98, 39);
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.3s, transform 0.2s;
  text-decoration: none;
  height: fit-content;
  width: fit-content;
  font-weight: 500;
}
.btn.LogOut {
  margin-right: -4px;
  background: #a3342c;
  font-size: 16px;
}
.btn.HowTo{
  margin-right:-10px;
  background:rgb(67, 153, 80);
  font-size: 16px;            
}
.btn.Back{
  margin-right:-10px;
  background:rgb(67, 153, 80);
  font-size: 16px;            
}
.btn.secondary {
  background:rgb(28, 98, 39);
}
.btn.Databases {
  margin-top: 10px;
  padding: 8px 12px;
  background: #24ab58;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  font-style: normal;
  font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
}
.btn.Three {
  background:rgb(28, 98, 39);
}
.btn:hover {
  opacity: 0.9;
  transform: scale(1.05);
}
.logo {
  font-size: 24px;
  font-weight: bold;
}
nav ul {
  display: flex;
  list-style: none;
}
nav ul li {
  margin-left: 20px;
}
nav ul li a {
  color: white;
  text-decoration: none;
  font-weight: 700;
}

/* Hero Section */
.hero {
  position: relative;
  text-align: center;
}
.hero img {
  width: 100%;
  height: auto;
}
.hero-caption {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
}

/* Features */
.features {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 40px 10%;
  background: #f9f9f9;
}
.feature-card {
  width: 550px;
  background: rgb(234, 234, 234);
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.234);
}
.feature-card .icon {
  font-size: 40px;
}
.feature-card button {
  margin-top: 10px;
  padding: 8px 12px;
  background: #0095ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.feature-card button:hover {
  background: #0077cc;
}
/*Calendar Features*/
.features2 {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 40px 10%;
  background: #f9f9f9;
}
.feature-card2 {
  width: 900px;
  height: 500px;
  background: white;
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}
.feature-card2 .icon {
  font-size: 40px;
}
.feature-card2 button {
  margin-top: 10px;
  padding: 8px 12px;
  background: #0095ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.feature-card2 button:hover {
  background: #0077cc;
}

/* Footer */
footer {
  background-color: rgba(21, 86, 50, 0.937);
  color: white;
  padding: 30px 10%;
  font-size: 16px;
  line-height: 22px;
  font-weight: lighter;
  
  font-style: normal;
}
.footer-brand {
  margin-bottom: 20px;
}
.footer-links {
  display: flex;
  justify-content: space-between;
  
}
.footer-links div h4 {
  margin-bottom: 10px;
  text-indent: -20px;
}
.footer-links ul {
  list-style: none;
}
.footer-links ul li {
  margin-bottom: 0px;
  margin-left: -30px;
}
.footer-links ul li a {
  color: white;
  text-decoration: none;
}
.footer-copy {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
}

/**/
#transition-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  z-index: 9999;
  pointer-events: none;
}

.panel {
  flex: 1;
  background-color: #97ba9f;
  transform: translateY(-100%);
  animation: slideDown 1s forwards;
}

@keyframes slideDown {
  to {
    transform: translateY(0);
  }
}
/** */
.MainPage{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/something/refs/heads/main/newfrontpagee.png");
  background-size: contain;
  height: 900px;
  background-repeat: no-repeat;
  background-position: center;
}
.PAMB{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/pambb.png");
  background-size: contain;
  height: 400px;
  margin-top: -7px;
  background-position: center;    
  background-repeat: no-repeat;
}        
.PAMBdata{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/pamb_search.png");
  background-size: contain;
  height: 500px;
  margin-top: -7px;
  background-position: center;    
  background-repeat: no-repeat;
}
.NIPAS{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/something/refs/heads/main/nipasc.png");
  background-size: contain;
  height: 300px;
  margin-top: -7px;
  background-position: center;    
  background-repeat: no-repeat;
}
.NipasData{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/something/refs/heads/main/nipasusers.png");
  background-size: contain;
  height: 500px;
  background-repeat: no-repeat;
  background-position: center;
}
.indentText{
  text-indent: 40px;
  line-height: 30px;
}
.PageBorder{
  border:2px solid black;
  border-radius: 10px;
  width: 55%;
  padding:10px;          
}
* {
  box-sizing: border-box;
}
.column {
  float: left;
  width: 30%;
  padding: 5px;
  align-content: center;
}
/* Clearfix (clear floats) */
.row::after {
  align-content: center;
  clear: both;
  display: table;
  width: 30%;
  margin-left: 20%;
}
table{              
/*border: 2px solid black;*/
  width: fit-content;
}
</style>
</head>

<body>
  <!--transition code Start-->
    <div id="transition-overlay"></div>
  <!--transition code END-->

  <!-- Header -->
  <header>
    <div class="Emblem"> <p class="logo" style="margin-left:70px; margin-top:17px; padding-left: 0%; padding-right: 0%;">CDD - NIPAS & PAMB Management System</p></div> 
    <nav>
      <p class="TimeYes" id ="time" style="margin-top:-20px; margin-right: -10px;"></p>
      <p class="TimeYes" id ="date" style="margin-right: -10px;"></p>
    </nav>
  </header>
  <header style="height: 50px;">
    <div class="logo"></div>
    <nav>
      <ul>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li> 
        <li><a href="https://github.com/OJT-DENR/something/raw/refs/heads/main/PAMBCS-CDD-SystemManuscriptForUsers.pdf" download class="btn HowTo" onmousedown="mouseclick.play()">Download Manuscript</a></li>
        <li><a href="user_page.php" class="btn Back" onmousedown="mouseclick.play()">Back</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Image -->
  <br>

  <h1> Website Guide: </h1>
  <p style="margin-top: -15px; color: cadetblue;">---</p>
        <p style="text-align: center;">Welcome to the new DENR PAMB and NIPAS management database. 
          This will serve as your guide on how to use the website properly.
        </p>
        <br>
        <h2>Main Page:</h2>
        <p class="indentText">In here you can see all of the functions that this website offers. 
          It can tell you the Time & Date, Mission & Vision, About page, Calendar and the Database and Input form 
          for NIPAS and PAMB. The calendar allows users to view and manage important dates, events, and deadlines. 
          Users can click on a date to see event details, add or edit entries, and receive reminders for upcoming activities. 
          Lastly, when clicked "how to" button, this displays a helpful user guide explaining how to navigate and use the website. 
          The guide typically includes step-by-step instructions, illustrations, and explanations of each feature to assist first-time 
          or returning users.
            
        </p>
        <br>
            <div class="MainPage"></div>
        <br>
        <div class="DivPambi">
            <br>
        <h1>PAMB:</h1>
        <p>Here we can see 2 buttons, PAMB and Database. By clicking PAMB, you will be redirected to another page that enables 
          you to input information to put in the database.
        </p>
        <br>
        <div class="PAMB"></div>
        <br>
        <p>After filling-up the form just click submit and the page will refresh and you will see the ID change to indicate that you have successfully added new data for the database.</p>
        <p>To check the database, click the "back" button then click the "Database" button.</p>
        <br>
        <table>

            <tr>
            <th><img src="https://raw.githubusercontent.com/OJT-DENR/something/refs/heads/main/pambformm.png" alt="Snow" style="width:50%;"></th>
            </tr>

        </table>
        <br>
        <p>In here you can see the search bar, download all (PDF or XLSX) button, delete all button, Edit, and Download PDF or button.</p>
        <br>
            <div class="PAMBdata"></div>
        <br>
        <h3>⚪️ Search Bar</h3>
        <p class="indentText">The search bar allows you to search Id, Clearance Number, Proponent, Resolution Title, Resolution Number, and PAMB Meeting Date of a specific data that you want to see. 
          Another feature of the search bar is its filter function where you can filter out the specific attribute that you want to search. 
          For example, if you want to search laguna specifically on "location" you can just click the location on the filter so that it will only 
          show laguna on the location category. </p>
        <p style="margin-top: -15px; color: cadetblue;">---</p>
        <h3>⚪️ Download All (PDF or XLSX)</h3>
        <p class="indentText">By clicking this, you will be able to download all the data from this database in a PDF and XLSX format. Plus, with the filter function you can filter out which data you 
          want to be downloaded in bulk.</p>
        <p style="margin-top: -15px; color: cadetblue;">---</p>
        <h3>⚪️ Edit</h3>
        <p class="indentText">This will allow you to edit each information inside the database. This will help you whenever you enter the wrong data or things change in the future.</p>
        <p style="margin-top: -15px; color: cadetblue;">---</p>
        <h3>⚪️ Delete</h3>
        <p class="indentText">This will allow you to delete specific row inside the database. </p>
        <p style="margin-top: -15px; color: cadetblue;">---</p>
        <h3>⚪️ Download PDF</h3>
        <p class="indentText">This will download the specific row of data inside the database and turning it into the PAMB Clearance format. <br><i>*Note: whenever you want change the format inside the 
          pdf, you can convert it into word by using PDF to Word websites.</i></p>
    <br>    
    </div>
        <br><br>
        <div class="DivPambi">
            <br>
            <h1>NIPAS:</h1>
            <p>This is the same as the PAMB where we have 2 buttons, the NIPAS and Database. They serve the same way at the previous buttons but now it leads you to the NIPAS fill-up form and the NIPAS database.
            </p>
            <div class="NIPAS"></div>
            <br>
            <p></p>  
            <p>After filling-up the form just click submit and the page will refresh and you will see the ID change to indicate that you have successfully added new data for the database.</p>
            <p>To check the database, click the "back" button then click the "Database" button.</p>
            <table>
                <tr>
                  <th><img src="https://raw.githubusercontent.com/OJT-DENR/something/refs/heads/main/nipascrt.png" alt="Snow" style="width:65%;"></th>
                </tr>
            </table>
            <p>In here you can see the search bar, download all (PDF or XLSX) button, Delete, Edit, Download Nipas Cert, Download Nipas Cert More, Download Assessment, and Download Memorandum.</p>
            <p><i>*Note: The order of the database is oldest to newest. If you want to change the order, just click the arrow key on the ID to change it from ascending to descending order.</i></p>
            <br>
            <div class="NipasData"></div>
            <br>
            <h3>⚪️ Search Bar</h3>
            <p class="indentText">The search bar allows you to search DATS, Actioned By, Location, Applicant, Company, Control Number, Findings, and Purpose, Date Received of a specific data that 
              you want to see. Another feature of the search bar is its filter function where you can filter out the specific attribute that you want to search. For example, if you want to search 
              number specifically on "DATS" you can just click the DATS on the filter so that it will only show number on the DATS category. </p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Download All (PDF or XLSX)</h3>
            <p class="indentText">By clicking this, you will be able to download all the data from this database in a PDF and XLSX format. Plus, with the filter function you can filter out which 
              data you want to be downloaded in bulk.</p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Download NIPAS Certification</h3>
            <p class="indentText">By clicking this, you will be able to download the data from the row and it will automatically create a NIPAS Certificate for single lot in a PDF format.</p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Download NIPAS Certification More Lots</h3>
            <p class="indentText">By clicking this, you will be able to download the data from the row and it will automatically create a NIPAS Certificate for more lots in a PDF format.</p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Download Assesment Form</h3>
            <p class="indentText">This will create an Assessment form based on the data inside the specific row and turns it into a PDF.</p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Download Memorandum Form</h3>
            <p class="indentText">This will create a Memorandum form based on the data inside the specific row and turns it into a PDF.</p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Delete All Button</h3>
            <p class="indentText">This will delete all the data in your database so be careful when clicking this button. We recommend to only click this button after downloading all the data from this database every 3 to 4 months to create back-ups of your data before deleting everything in the database.</p>
            <p style="margin-top: -15px; color: cadetblue;">---Made by .... .- .-.. .- / -. .- --. / .--. .- -.- .- .... .. .-. .- .--. / .--. .- -. --. / .. - .-. .- -. ... .-.. .- - .</p>
            <h3>⚪️ Edit</h3>
            <p class="indentText">This will allow you to edit each information inside the database. This will help you whenever you enter the wrong data or things change in the future.</p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <h3>⚪️ Delete</h3>
            <p class="indentText">This will allow you to delete specific row inside the database. </p>
            <p style="margin-top: -15px; color: cadetblue;">---</p>
            <br>    
        </div>
            <br>
    <!--END-->
  <!-- Footer -->
  <footer>
    <div class="footer-brand">
      <h2 style="text-indent: -45px;">CDD - NIPAS & PAMB Management System</h2>
    </div>
    <div class="footer-links">
      <div>
        <h4>Company</h4>
        <ul>
          <li><p>About</p></li>
          <li><p>This website offers DENR CDD employees to help automate the process <br>of making PDF forms for each NIPAS and PAMB documents
            whilst giving <br>them a proper database where each input can be documented and updated.</p></li>
            <br>
          <li><p>Mission</p></li>
          <li><p>To mobilize our citizenry in protecting, conserving, and managing the <br>
            environment and natural resources for the present and future
            generations.</p></li>
            <br>
          <li><p>Vision</p></li>
          <li><p>A nation enjoying and sustaining its natural resources and a clean and <br>healthy environment.</p></li>
        </ul>
      </div>
      <div>
        <h4>Community</h4>
        <ul>
          <li style="text-indent: 11px;"><a href="https://calabarzon.denr.gov.ph/">Official Website</a></li>
        </ul>
      </div>
    </div>
    <p class="footer-copy">© 2025 DENR Region 4A</p>
  </footer>
</body>

<!--Transition Script-->
<script>
  const overlay = document.getElementById('transition-overlay');

  function createPanels() {
    overlay.innerHTML = '';
    for (let i = 0; i < 10; i++) {
      const panel = document.createElement('div');
      panel.classList.add('panel');
      panel.style.animationDelay = `${i * 0.1}s`;
      overlay.appendChild(panel);
    }
  }

  document.querySelectorAll('a[href]').forEach(link => {
    link.addEventListener('click', function (e) {
      const url = this.href;

      // Skip transition if link has class 'HowTo'
      if (this.classList.contains('HowTo')) {
        return;
      }

      if (url && !url.includes('#') && this.target !== "_blank") {
        e.preventDefault();
        createPanels();
        overlay.style.pointerEvents = 'auto';
        setTimeout(() => {
          window.location.href = url;
        }, 1500);
      }
    });
  });

  window.addEventListener('pageshow', () => {
    overlay.innerHTML = '';
    overlay.style.pointerEvents = 'none';
  });
</script>

</html>