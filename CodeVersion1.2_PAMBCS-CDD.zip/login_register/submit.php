<?php
session_start();

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the name of the logged-in user from the session
$created_by = $_SESSION['name'] ?? 'Unknown';

// Get form data safely
$clearance_no = $_POST['clearance_no'] ?? null;
$nameofpa = $_POST['NameOfPA'] ?? null;
$proponent = $_POST['proponent'] ?? null;
$Purpose = $_POST['Purpose'] ?? null;
$Resolution_No = $_POST['Resolution_No'] ?? null;
$Resolution_Title = $_POST['Resolution_Title'] ?? null;
$PAMB_Meeting_data = $_POST['PambMeetingDate'] ?? null;
$Description_Title = $_POST['DescriptionTitle'] ?? null;
$Des_cription = $_POST['Desc_ription'] ?? null;
$Terms_Conditions = $_POST['TermsConditions'] ?? null;
$rest_riction = $_POST['Restrictions'] ?? null;
$director_name = $_POST['DirectorName'] ?? null;
$DirectorRank = $_POST['DirectorRank'] ?? null;
$position = $_POST['Position'] ?? null;

// Prepare statement with created_by
$stmt = $conn->prepare("INSERT INTO clearance 
    (clearance_no, NameOfPA, proponent, Purpose, Resolution_No, Resolution_Title, PambMeetingDate, DescriptionTitle, Desc_ription, TermsConditions, Restrictions, DirectorName, DirectorRank, Position, created_by) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("sssssssssssssss", 
    $clearance_no, $nameofpa, $proponent, $Purpose, $Resolution_No, 
    $Resolution_Title, $PAMB_Meeting_data, $Description_Title, 
    $Des_cription, $Terms_Conditions, $rest_riction ,$director_name , $DirectorRank, $position, $created_by
);
// Execute and redirect
if ($stmt->execute()) {
    echo "<script>alert('Data saved successfully!'); window.location.href='pamb.php';</script>";
} else {
    echo "<script>alert('Error: Could not save data.'); window.location.href='form.html';</script>";
}
$stmt->close();
$conn->close();
?>
