<?php
require 'db.php'; // Make sure this sets up $conn

// Sanitize inputs
$search = isset($_GET['search']) ? trim($conn->real_escape_string($_GET['search'])) : '';
$filter = isset($_GET['filter']) ? trim($_GET['filter']) : 'all';

// Allowed columns for filtering
$allowed_columns = ['DATS', 'actioned', 'Location', 'Applicant', 'ControlNumber', 'Findings', 'Company', 'Purpose' , 'DateRecieved' , 'DateReleased'];

// Start query
$query = "SELECT * FROM nipas_table";

// Apply WHERE clause only if a search term is entered
if (!empty($search)) {
    if ($filter === 'all') {
        $conditions = [];
        foreach ($allowed_columns as $column) {
            $conditions[] = "`$column` LIKE '%$search%'";
        }
        $query .= " WHERE " . implode(" OR ", $conditions);
    } elseif (in_array($filter, $allowed_columns)) {
        $query .= " WHERE `$filter` LIKE '%$search%'";
    }
}

// Execute query
$result = $conn->query($query);
if (!$result) {
    die("SQL Error: " . $conn->error);
}

// Set headers for CSV
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="nipas_records.csv"');

// Output CSV
$output = fopen('php://output', 'w');

// If there are rows, print header and rows
if ($result->num_rows > 0) {
    fputcsv($output, array_keys($result->fetch_assoc())); // Header
    $result->data_seek(0); // Reset result pointer

    while ($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }
} else {
    fputcsv($output, ['No matching records found.']);
}

fclose($output);
$conn->close();
exit;
