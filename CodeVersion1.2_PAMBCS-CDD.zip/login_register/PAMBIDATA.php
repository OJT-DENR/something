   <?php
session_start();

if (!isset($_SESSION['name'])) {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['name'];

// DB Connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = isset($_POST['search']) ? trim($_POST['search']) : '';
$filter = $_POST['filter'] ?? 'all';
$from_month = $_POST['from_month'] ?? '';
$to_month = $_POST['to_month'] ?? '';

$allowed_columns = ['id','clearance_no', 'proponent', 'Resolution_Title', 'Resolution_No','DateReleased', 'PambMeetingDate'];
$conditions = [];

// Search condition
if (!empty($search)) {
    $searchEscaped = $conn->real_escape_string($search);

    if ($filter === 'all') {
        $searchParts = [];
        foreach ($allowed_columns as $col) {
            $searchParts[] = "$col LIKE '%$searchEscaped%'";
        }
        $conditions[] = '(' . implode(' OR ', $searchParts) . ')';
    } elseif (in_array($filter, $allowed_columns)) {
        $conditions[] = "$filter LIKE '%$searchEscaped%'";
    }
}

// Date range filter on PambMeetingDate (assumed format YYYY-MM-DD)
if (!empty($from_month) && !empty($to_month)) {
    // Format for first day of from_month and last day of to_month
    $fromDate = date('Y-m-01', strtotime($from_month));
    $toDate = date('Y-m-t', strtotime($to_month));
 $conditions[] = "(STR_TO_DATE(DateReleased, '%M %e %Y') BETWEEN '$fromDate' AND '$toDate')";
}

// Build WHERE clause
$where = '';
if (!empty($conditions)) {
    $where = ' WHERE ' . implode(' AND ', $conditions);
}

// Final query
$query = "SELECT * FROM clearance $where";

// Count query for total results
$countQuery = "SELECT COUNT(*) as total FROM clearance $where";

$countResult = $conn->query($countQuery);
$countRow = $countResult->fetch_assoc();
$total_results = $countRow['total'] ?? 0;

// Run main query
$result = $conn->query($query);

// Helper for dropdown selection
function selected($field, $value) {
    return (($_POST[$field] ?? '') === $value) ? 'selected' : '';
}
?>
    <!DOCTYPE html>
    <html lang="en">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <head>
        <meta charset="UTF-8">
        <title>PAMB Clearance Records</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <style>
            body {
                font-family: sans-serif;
                background-color: rgba(21, 86, 50, 0.73);
                /*background: linear-gradient(to bottom, , rgba(27, 56, 77, 0.54));*/
                background-repeat: repeat-y;
                padding: 20px;
            }
            .button-container {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }
            .button-container button {
                padding: 10px 15px;
                font-size: 16px;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                transition: background 0.3s, transform 0.2s;
            }
            .btn:hover {
                opacity: 0.9;
                
                transform: scale(1.05);
            }
            .clear-btn { background-color: rgb(173, 51, 34); color: white; transition: background 0.3s, transform 0.2s;}
            .search-btn { background-color: blue; color: white; }
            .back-btn { background-color:rgb(14, 111, 97); color: white; }
            .Download-btn { background-color:rgb(45, 167, 65); color: white; }
            table { background-color: white; width: 50%; }
            .container { max-width:100%; height: 100%; }
            
            /* "Show X entries" dropdown */
            .dataTables_wrapper .dataTables_length
            .dataTables_wrapper .dataTables_length label {
                color: white !important;
            }
            /* Page info like "Showing 1 to 10 of 57 entries" */
            .dataTables_wrapper .dataTables_info {
                color: white !important;
            }
            .btn-success{
                transition: background 0.3s, transform 0.2s;
            }
            .btn-danger{
                transition: background 0.3s, transform 0.2s;
            }
            .btn-warning{
                transition: background 0.3s, transform 0.2s;
            }
            .btn-primary{
                transition: background 0.3s, transform 0.2s;
            }
            .dataTables_info {
                margin-left: auto;
                color: white;
            }
            .dataTables_length label {
                color: white;
            }
            .dataTables_paginate {
                color: white;
            }


        </style>
    </head>

    <body>
    <div class="button-container">
        <button class="btn back-btn" onclick="window.location.href='user_page.php';">Back</button>
    </div>
    <div class="container">
        <h2 class="text-center my-4 text-white fw-bold" style="font-size: 300%;">PAMB Clearance Records</h2>
        <!-- Download Buttons -->
        <form method="POST" action="download_all.php" class="mb-3 d-inline" >
            <input type="hidden" name="search" value="<?php echo htmlspecialchars($_POST['search'] ?? '', ENT_QUOTES); ?>">
            <input type="hidden" name="filter" value="<?php echo htmlspecialchars($_POST['filter'] ?? '', ENT_QUOTES); ?>">
            <button type="submit" class="btn btn-success"style="background-color:rgb(45, 167, 65);">Download PDF</button>
        </form>
        <form method="POST" action="download_allex.php" class="mb-3 d-inline">
            <input type="hidden" name="search" value="<?php echo htmlspecialchars($_POST['search'] ?? '', ENT_QUOTES); ?>">
            <input type="hidden" name="filter" value="<?php echo htmlspecialchars($_POST['filter'] ?? '', ENT_QUOTES); ?>">
            <button type="submit" class="btn btn-success" style="background-color:rgb(45, 167, 65);">Download XLSX</button>
        </form>
        <!-- Search Form -->
        <form method="POST" class="mb-3 d-flex flex-wrap gap-2 align-items-center" style="margin-top:10px;">
            
            <input type="text" name="search" class="form-control me-2" placeholder="Enter keyword..."
                value="<?php echo htmlspecialchars($_POST['search'] ?? '', ENT_QUOTES); ?>">

            <select name="filter" class="form-select me-2" style="max-width: 200px;">
                <option value="all" <?= selected('filter', 'all'); ?>>All Columns</option>
                <option value="id" <?= selected('filter', 'id'); ?>>ID</option>
                <option value="clearance_no" <?= selected('filter', 'clearance_no'); ?>>Clearance No.</option>
                <option value="proponent" <?= selected('filter', 'proponent'); ?>>Proponent</option>
                <option value="Resolution_Title" <?= selected('filter', 'Resolution_Title'); ?>>Resolution Title</option>
                <option value="Resolution_No" <?= selected('filter', 'Resolution_No'); ?>>Resolution No.</option>
                <option value="PambMeetingDate" <?= selected('filter', 'PambMeetingDate'); ?>>PAMB Meeting Date</option>
                <option value="DateReleased" <?= selected('filter', 'DateReleased'); ?>>Dateapproved</option>

            </select>
        <label style="color:white;">From:</label>
        <input type="month" name="from_month" class="form-control" value="<?= $_POST['from_month'] ?? '' ?>" style="max-width: 160px;">
        <label style="color:white;">To:</label>
        <input type="month" name="to_month" class="form-control" value="<?= $_POST['to_month'] ?? '' ?>" style="max-width: 160px;">
        <button type="submit" class="btn btn-primary">Search</button>
        </form>
        <!--Search Notification-->
        <?php if (!empty($search)): ?>
        <div class="alert alert-info" style="background-color:  rgba(116, 174, 202, 0.54); color: white; border:none;">
            Found <strong><?= $total_results; ?></strong> result(s) for "<strong><?= htmlspecialchars($search); ?></strong>" 
            in <strong><?= $filter === 'all' ? 'all columns' : ucfirst(str_replace('_', ' ', $filter)); ?></strong>.
        </div>
    <?php endif; ?>
        <div>
    
        <!-- Table Display -->
        <table id="clearanceTable" class="table table-striped table-bordered text-center" >
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Clearance No.</th>
                    <th>Name of PA</th>
                    <th>Proponent</th>
                    <th>Purpose</th>
                    <th>Resolution No.</th>
                    <th>Resolution Title</th>
                    <th>PAMB Meeting Date</th>
                    <th>Description</th>
                    <th>Terms & Conditions</th>
                    <th>Restrictions</th>
                    <th>DateApproved</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= htmlspecialchars($row['clearance_no']); ?></td>
                    <td><?= htmlspecialchars($row['NameOfPA']); ?></td>
                    <td><?= nl2br(htmlspecialchars($row['proponent'])); ?></td>
                    <td><?= nl2br(htmlspecialchars($row['Purpose'])); ?></td>
                    <td><?= nl2br(htmlspecialchars($row['Resolution_No'])); ?></td>
                    <td><?= substr(htmlspecialchars($row['Resolution_Title']), 0, 90) . '...'; ?></td>
                    <td><?= htmlspecialchars($row['PambMeetingDate']); ?></td>
                    <td><?= substr(htmlspecialchars($row['Desc_ription']), 0, 90) . '...'; ?></td>
                    <td><?= substr(htmlspecialchars($row['TermsConditions']), 0, 90) . '...'; ?></td>
                    <td><?= substr(htmlspecialchars($row['Restrictions']), 0, 90) . '...'; ?></td>
                    <td><?= substr(htmlspecialchars($row['DateReleased']), 0, 90) . '...'; ?></td>
                    <td>
                        <form method="POST" action="delete_pamb.php" onsubmit="return confirm('Are you sure you want to delete this record?');">
                            <input type="hidden" name="id" value="<?= $row['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form> <br>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#updateModal<?= $row['id']; ?>">Update</button><br><br>
                        <a href="generate_pdf.php?id=<?= $row['id']; ?>" class="btn Download-btn">Download PDF</a>
                    </td>
                </tr>

                <!-- Update Modal -->
                <div class="modal fade" id="updateModal<?php echo $row['id']; ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content" style="width: 150%; margin-left:-150px;">
                            <div class="modal-header" style="background-color: rgb(26, 112, 94); color: white;">
                                <h5 class="modal-title">Update Record ID: <?php echo $row['id']; ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form action="update_process.php" method="POST">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <label class="label" for="created_by">Created By:</label>
                                <!-- FIX: Use null coalescing operator to avoid undefined key error -->
                                <input type="text" id="created_by" name="created_by" value="<?php echo htmlspecialchars($row['created_by'] ?? ''); ?>" readonly class="form-control">

                                    <div class="mb-3"><label class="form-label">Clearance No.:</label>
                                        <input type="text" name="clearance_no" class="form-control" value="<?php echo $row['clearance_no']; ?>" required>
                                    </div>
                                    
                                    <div class="mb-3"><label class="form-label">Name of PA:</label>
                                        <input type="text" name="NameOfPA" class="form-control" value="<?php echo $row['NameOfPA']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Proponent:</label>
                                        <input type="text" name="proponent" class="form-control" value="<?php echo $row['proponent']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Purpose:</label>
                                        <input type="text" name="Purpose" class="form-control" value="<?php echo $row['Purpose']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Resolution No.:</label>
                                        <input type="text" name="Resolution_No" class="form-control" value="<?php echo $row['Resolution_No']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Resolution Title:</label>
                                        <textarea name="Resolution_Title" class="form-control" required><?php echo $row['Resolution_Title']; ?></textarea>
                                    </div>
                                    <div class="mb-3"><label class="form-label">PAMB Meeting Date:</label>
                                        <input type="text" name="PambMeetingDate" class="form-control" value="<?php echo $row['PambMeetingDate']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Description Title:</label>
                                        <input type="text" name="DescriptionTitle" class="form-control" value="<?php echo $row['DescriptionTitle']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Description:</label>
                                        <textarea name="Desc_ription" class="form-control" required><?php echo $row['Desc_ription']; ?></textarea>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Terms and Conditions:</label>
                                        <textarea name="TermsConditions" class="form-control" required><?php echo $row['TermsConditions']; ?></textarea>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Restrictions:</label>
                                        <textarea name="Restrictions" class="form-control"><?php echo $row['Restrictions']; ?></textarea>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Director:</label>
                                        <input type="text" name="DirectorName" class="form-control" value="<?php echo $row['DirectorName']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Rank:</label>
                                        <input type="text" name="DirectorRank" class="form-control" value="<?php echo $row['DirectorRank']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">Position:</label>
                                        <input type="text" name="Position" class="form-control" value="<?php echo $row['Position']; ?>" required>
                                    </div>
                                    <div class="mb-3"><label class="form-label">?DateApproved</label>
                                        <input type="text" name="DateReleased" class="form-control" value="<?php echo $row['DateReleased']; ?>">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    </div>

    <script>
        $('#clearanceTable').DataTable({
    "paging": true,
    "searching": false,
    "lengthMenu": [5, 10, 25],
    "pageLength": 5,
    "order": [],
    "dom": '<"top d-flex justify-content-between align-items-center mb-2"lif>rt<"bottom"p><"clear">'
    });
    </script>

    </body>
    </html>

    <?php $conn->close(); ?>