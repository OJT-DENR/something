<?php
session_start();
$Name = "Name"; // Default fallback

// Connect to DB
$conn = new mysqli("localhost", "root", "", "users_db"); // ✅ DB name is users_db
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check session
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];

    // ✅ TABLE name should be `users`, not `users_db`
    $stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($fetchedName);

    if ($stmt->fetch()) {
        $Name = $fetchedName;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>CDD-PAMBCS</title>

    <script>
    /* Time and date */
          function updateTime() {
              const optionsTime = { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true };
              const optionsDate = { timeZone: "Asia/Manila", weekday: "long", year: "numeric", month: "long", day: "numeric" };
              const time = new Date().toLocaleTimeString("en-US", optionsTime);
              const date = new Date().toLocaleDateString("en-US", optionsDate);
              document.getElementById("time").innerText = time;
              document.getElementById("date").innerText = date;
          }
          setInterval(updateTime, 1000);
          var mouseclick = new Audio();
          mouseclick.src = "https://uploads.sitepoint.com/wp-content/uploads/2023/06/1687569402mixkit-fast-double-click-on-mouse-275.wav";
    </script>
    
<style>
/* Reset & Base */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: 'Segoe UI', sans-serif;
  color: #333;
}
.TimeYes{
  position: relative;
  text-align: right;
  color: rgb(252, 252, 252);
  top: 12px;
  font-style: Times;
  margin-right: 0px;
}
.Emblem{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/Seal_of_the_Department_of_Environment_and_Natural_Resources.svg.png");  
  background-size: 60px 60px;
  background-repeat: no-repeat;
  height: 60px;
  margin-top:0px;
  margin-left:-40px;
}
/* Header */
header {
  background-color: rgba(21, 86, 50, 0.937);
  display: flex;
  justify-content: space-between;
  padding: 20px 10%;
  align-items: center;
  color: white;
  box-shadow: 0px 5px 5px rgb(53, 53, 53);
  height: 90px;
}
.NIPASpic{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Icon.png");
  background-size: contain;
  height: 200px;
  background-repeat: no-repeat;
  background-position: center;
}
.PAMBpic{
  background-image: url("https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMB_Icon.png");
  background-size: contain;
  height: 200px;
  background-repeat: no-repeat;
  background-position: center;
}
.btn {
  display: inline-block;
  margin: 10px;
  padding: 8px 15px;
  font-size: 1em;
  font-style: oblique;
  color: whitesmoke;
  background:rgb(28, 98, 39);
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.3s, transform 0.2s;
  text-decoration: none;
  height: fit-content;
  width: fit-content;
  font-weight: 500;
}
.btn.LogOut {
  margin-right: -4px;
  background: #a3342c;
}
.btn.HowTo{
  margin-right:-10px;
  background:rgb(67, 153, 80);            
}
.btn.secondary {
  background:rgb(28, 98, 39);
}
.btn.Databases {
  margin-top: 10px;
  padding: 8px 12px;
  background: #24ab58;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  font-style: normal;
  font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
}
.btn.Three {
  background:rgb(28, 98, 39);
}
.btn:hover {
  opacity: 0.9;
  transform: scale(1.05);
}
.logo {
  font-size: 24px;
  font-weight: bold;
}
nav ul {
  display: flex;
  list-style: none;
}
nav ul li {
  margin-left: 20px;
}
nav ul li a {
  color: white;
  text-decoration: none;
  font-weight: 700;
}

/* Hero Section */
.hero {
  position: relative;
  text-align: center;
}
.hero img {
  width: 100%;
  height: auto;
}
.hero-caption {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
}
/* Features */
.features {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 40px 10%;
  background: #f9f9f9;
}
.feature-card {
  width: 550px;
  background: rgb(234, 234, 234);
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.234);
}
.feature-card .icon {
  font-size: 40px;
}
.feature-card button {
  margin-top: 10px;
  padding: 8px 12px;
  background: #0095ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.feature-card button:hover {
  background: #0077cc;
}
/*Calendar Features*/
.features2 {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 40px 10%;
  background: #f9f9f9;
}
.feature-card2 {
  width: 900px;
  height: 500px;
  background: white;
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}
.feature-card2 .icon {
  font-size: 40px;
}
.feature-card2 button {
  margin-top: 10px;
  padding: 8px 12px;
  background: #0095ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.feature-card2 button:hover {
  background: #0077cc;
}

/* Footer */
footer {
  background-color: rgba(21, 86, 50, 0.937);
  color: white;
  padding: 30px 10%;
}
.footer-brand {
  margin-bottom: 20px;
}
.footer-links {
  display: flex;
  justify-content: space-between;
}
.footer-links div h4 {
  margin-bottom: 10px;
}
.footer-links ul {
  list-style: none;
}
.footer-links ul li {
  margin-bottom: 5px;
}
.footer-links ul li a {
  color: white;
  text-decoration: none;
}
.footer-copy {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
}
/**/
#transition-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  z-index: 9999;
  pointer-events: none;
}
.panel {
  flex: 1;
  background-color: #97ba9f;
  transform: translateY(-100%);
  animation: slideDown 1s forwards;
}
@keyframes slideDown {
  to {
    transform: translateY(0);
  }
}
</style>
</head>

<body>
  <!--transition code Start-->
    <div id="transition-overlay"></div>
  <!--transition code END-->

  <!-- Header -->
  <header>
    <div class="Emblem"> <p class="logo" style="margin-left:70px; margin-top:13px;">CDD - NIPAS & PAMB Management System</p></div> 
    <nav>
      <p class="TimeYes" id ="time" style="margin-top:-20px;"></p>
      <p class="TimeYes" id ="date"></p>
    </nav>
  </header>
  <!-- Header END-->
  <header style="height: 50px;">
<p style="color: white; font-weight: bold;">Welcome, <?php echo htmlspecialchars($Name); ?>!</p>

    <div class="logo"></div>
    <nav>
      <ul>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
        <li><a href="guide.php" class="btn HowTo" onmousedown="mouseclick.play()">How To</a></li>
        <li><a href="index.php" class="btn LogOut" onmousedown="mouseclick.play()">Log-out</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Image -->
  <section class="hero">
    <img src="https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/CDD%20PAMBCS.gif" alt="City panorama"/>
  </section>
  <!-- Features -->
  <br>
    <h1 style="text-align: center;">Fill-out & Database</h1>
  <br>
  <section class="features">
    <div class="feature-card">
      
      <h3>PAMB Clearance</h3>
      <div class="PAMBpic"></div>
      <p>Fill-out form for PAMB clearance. Everything that will be inputed here will go inside the corresponding database.</p>
      <a href="pamb.php" class="btn Databases" onmousedown="mouseclick.play()">Go to Form</a>
    </div>
    <div class="feature-card">
      
      <h3>NIPAS Certification</h3>
      <div class="NIPASpic"></div>
      <p>Fill-out form for NIPAS Certificate. Everything that will be inputed here will go inside the corresponding database.</p>
      <a href="nipas.php" class="btn Databases" onmousedown="mouseclick.play()">Go to Form</a>
    </div>
  
    <div class="feature-card">
      <div class="icon">💼</div>
      <h3>PAMB Clearance Database</h3>
      <p></p>
      <a href="PAMBIDATA.php" class="btn Databases" onmousedown="mouseclick.play()">DATABASE</a>
    </div>
    <div class="feature-card">
      <div class="icon">💼</div>
      <h3>NIPAS Database</h3>
      <p></p>
      <a href="updatenipas.php" class="btn Databases" onmousedown="mouseclick.play()">DATABASE</a>
    </div>
  </section>
  <br><br>
<section class="features">
    <div class="feature-card2">
        <h1 style="text-align: center;">Calendar</h1>
      <iframe src="https://calendar.google.com/calendar/embed?height=410&wkst=1&ctz=Asia%2FManila&showTitle=0&showPrint=0&src=b2p0ZGVucjhAZ21haWwuY29t&src=ZW4ucGhpbGlwcGluZXMjaG9saWRheUBncm91cC52LmNhbGVuZGFyLmdvb2dsZS5jb20&color=%23039BE5&color=%238E24AA" style="border-width:0" width="800" height="410" frameborder="0" scrolling="no"></iframe>
    </div>
  </section>
  <!-- Footer -->
  <footer>
    <div class="footer-brand">
      <h2>CDD - NIPAS & PAMB Management System</h2>
    </div>
    <div class="footer-links">
      <div>
        <h4>Company</h4>
        <ul>
          <li><p>About</p></li>
          <li><p>This website offers DENR CDD employees to help automate the process <br>of making PDF forms for each NIPAS and PAMB documents
            whilst giving <br>them a proper database where each input can be documented and updated.</p></li>
            <br>
          <li><p>Mission</p></li>
          <li><p>To mobilize our citizenry in protecting, conserving, and managing the <br>
            environment and natural resources for the present and future
            generations.</p></li>
            <br>
          <li><p>Vision</p></li>
          <li><p>A nation enjoying and sustaining its natural resources and a clean and <br>healthy environment.</p></li>
        </ul>
      </div>
      <div>
        <h4>Community</h4>
        <ul>
          <li><a href="https://calabarzon.denr.gov.ph/">Official Website</a></li>
        </ul>
      </div>
    </div>
    <p class="footer-copy">© 2025 DENR Region 4A</p>
  </footer>

</body>
<!--Transition Script-->
<script>
  const overlay = document.getElementById('transition-overlay');

    function createPanels() {
      overlay.innerHTML = '';
      for (let i = 0; i < 10; i++) {
        const panel = document.createElement('div');
        panel.classList.add('panel');
        panel.style.animationDelay = `${i * 0.1}s`;
        overlay.appendChild(panel);
      }
    }

    document.querySelectorAll('a[href]').forEach(link => {
      link.addEventListener('click', function (e) {
        const url = this.href;
          if (url && !url.includes('#') && this.target !== "_blank")
          {
            e.preventDefault();
            createPanels();
            overlay.style.pointerEvents = 'auto';
            setTimeout(() => {
              window.location.href = url;}, 1500);
          }
      });
    });

  window.addEventListener('pageshow', () => {
    overlay.innerHTML = '';
    overlay.style.pointerEvents = 'none';
  });

</script>
</html>
