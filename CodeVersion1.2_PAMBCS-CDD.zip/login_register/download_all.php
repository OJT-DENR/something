<?php
require 'vendor/autoload.php'; // Load Dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

// Database Connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle filter from POST
$search = isset($_POST['search']) ? $conn->real_escape_string($_POST['search']) : '';
$filter = isset($_POST['filter']) ? $_POST['filter'] : 'all'; // Default filter is 'all'

// Base query
$query = "SELECT * FROM clearance";

// Apply search and filter if provided
if (!empty($search)) {
    if ($filter === 'all') {
        // Search in all columns
        $query = "SELECT * FROM clearance WHERE 
            id LIKE '%$search%' OR 
            proponent LIKE '%$search%' OR 
            Resolution_Title LIKE '%$search%' OR 
            Resolution_No LIKE '%$search%' OR 
            PambMeetingDate LIKE '%$search%' OR
            DateReleased LIKE '%$search%' OR
            clearance_no LIKE '%$search%'";
    } elseif (in_array($filter, ['id', 'proponent', 'Resolution_Title', 'Resolution_No', 'PambMeetingDate','DateReleased', 'clearance_no'])) {
        // Search in specific column based on the filter
        $query = "SELECT * FROM clearance WHERE `$filter` LIKE '%$search%'";
    }
}

$result = $conn->query($query);

if ($result->num_rows > 0) {
    // Initialize Dompdf
    $options = new Options();
    $options->set('defaultFont', 'Arial');
    $dompdf = new Dompdf($options);

    // Start HTML content
    $html = "
    <h2 style='text-align: center;'>PAMB Clearance Records</h2>
    <table border='1' cellspacing='0' cellpadding='1' width='100%' align='left'>
        <tr>
            <th>Clearance No.</th>
            <th>Name of PA</th>
            <th>Proponent</th>
            <th>Purpose</th>
            <th>Resolution No.</th>
            <th>Resolution Title</th>
            <th>PAMB Meeting Date</th>
            <th>Description Title</th>
            <th>Description</th>
            <th>Terms and Conditions</th>
            <th>Restrictions</th>
            <th>DateReleased</th>
        </tr>";

    // Fetch the records and generate the table
    while ($row = $result->fetch_assoc()) {
        $html .= "
        <tr>
            <td>{$row['clearance_no']}</td>
            <td>{$row['NameOfPA']}</td>
            <td>{$row['proponent']}</td>
            <td>{$row['Purpose']}</td>
            <td>{$row['Resolution_No']}</td>
            <td>{$row['Resolution_Title']}</td>
            <td>{$row['PambMeetingDate']}</td>
            <td>{$row['DescriptionTitle']}</td>
            <td>{$row['Desc_ription']}</td>
            <td>{$row['TermsConditions']}</td>
            <td>{$row['Restrictions']}</td>
            <td>{$row['DateReleased']}</td>
        </tr>";
    }

    $html .= "</table>";

    // Load HTML into Dompdf and generate the PDF
    $dompdf->loadHtml($html);
    $dompdf->setPaper('Tabloid', 'landscape');
    $dompdf->render();
    $dompdf->stream("PAMB_clearance_records_filtered.pdf", ["Attachment" => 1]);
} else {
    echo "No matching records found.";
}

$conn->close();
?>
