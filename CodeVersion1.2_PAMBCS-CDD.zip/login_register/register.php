<?php

session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? ''
];
$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : '';
}

//
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($password !== $confirm_password) {
        $_SESSION['register_error'] = 'Passwords do not match!';
        $_SESSION['active_form'] = 'register';
        header('Location: register.php');
        exit();
    }

    // Continue with your existing logic to save the user...
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>Full-Stack Login & Register Form With User & Admin Page | Codehal</title>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
            background-color:rgb(124, 156, 131);
        }

        .container {
            margin: 0 15px;
        }
        .form-box {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: none;
        }
        .form-box.active{

            display:block ;
        } 
        h2 {
            font-size: 34px;
            text-align: center;
            margin-bottom: 20px;
        }

        input,
        select{
            width: 100%;
            padding: 12px;
            background: #eee;
            border-radius: 6px;
            border: none;
            outline: none;
            font-size: 16px;
            color: #333;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 12px;
            background:rgb(35, 131, 57);
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color:rgb(255, 255, 255);
            font-weight: 500;
            margin-bottom: 20px;
            transition: 0.5s;
        }
        button:hover {
            background:rgb(42, 172, 81);
        }

        p {
            font-size: 14.5px;
            text-align: center;
            margin-bottom: 10px;
        }

        p a {
            color:rgb(195, 239, 208);
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
        .error-message {
            padding: 12px;
            background: #f8d7da;
            border-radius: 6px;
            font-size: 16px;
            color: #a42834;
            text-align: center;
            margin-bottom: 20px;
        }
        .btn {
            width: 400%;
            padding: 12px;
            background:rgb(35, 131, 57);
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color:rgb(255, 255, 255);
            font-weight: 500;
            margin-bottom: 20px;
            transition: 0.5s;
        }
        .btn:hover {
            background:rgb(42, 172, 81);
            opacity: 0.9;
            transform: scale(1.05);
        }
        .btn.Back{
            background-color: #333;
            margin-left: 80px;
            padding-left: 40%;
            padding-right: 40%;
        }
        a{
            text-decoration: none;
        }
        @media only screen and (max-width: 600px) {
        
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
            background: linear-gradient(to bottom,rgb(59, 98, 156) 0%,rgb(58, 143, 93) 100%);
            background-repeat: no-repeat;
            background-size: cover;
        }
        h2 {
            font-size: 34px;
            text-align: center;
            margin-bottom: 20px;
            color: whitesmoke;
        }
        button {
            width: 100%;
            padding: 12px;
            background:rgb(67, 194, 96);
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color:rgb(255, 255, 255);
            font-weight: 500;
            margin-bottom: 20px;
            transition: 0.5s;
        }
        }
    </style>

</head>

<body>
    <div class="container">
        <div class id="register-form">
            <form action="login_register.php" method="post">
                <h2 style="color: #eee;">Register</h2>
                <?= showError($errors['register']); ?>
                <input type="text" name="name" placeholder="Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="password" name="confirm_password" placeholder="Retype password" required>
                <select name="role">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <button type="submit" name="register">Register</button>
                <a href="admin_page.php" class="btn Back">Back</a>
            </form>
        </div>
    
        </div>
        <script src="script.js"></script>

        <script>
        document.querySelector("form").addEventListener("submit", function(e) {
            const password = document.querySelector('input[name="password"]').value;
            const confirm = document.querySelector('input[name="confirm_password"]').value;

            if (password !== confirm) {
                alert("Passwords do not match!");
                e.preventDefault();
            }
        });
        </script>


</body>

</html>