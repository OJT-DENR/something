<?php
require 'vendor/autoload.php'; // Ensure Dompdf is installed
require 'db.php'; // Database connection

use Dompdf\Dompdf;
use Dompdf\Options;

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate ID input
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No valid ID provided.");
}

$id = intval($_GET['id']); // Sanitize ID

// Fetch data from database
$query = "SELECT * FROM nipas_table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if record exists
if ($result->num_rows == 0) {
    die("Error: No record found with ID " . $id);
}

$row = $result->fetch_assoc();

// Newly added database fields
$noapplied = isset($row['NoApplied']) ? htmlspecialchars($row['NoApplied']) : 'N/A';
$LotN = isset($row['LotN']) ? htmlspecialchars($row['LotN']) : 'N/A';
$TCT = isset($row['TCT']) ? htmlspecialchars($row['TCT']) : 'N/A';
$applicant = isset($row['applicant']) ? htmlspecialchars($row['applicant']) : 'N/A';
$purpose = isset($row['purpose']) ? htmlspecialchars($row['purpose']) : 'N/A';
$amount = isset($row['amount']) ? htmlspecialchars($row['amount']) : 'N/A';
$totalwords = isset($row['totalwords']) ? htmlspecialchars($row['totalwords']) : 'N/A';
$area1 = isset($row['Area1']) ? htmlspecialchars($row['Area1']) : 'N/A';
$findings = isset($row['findings']) ? htmlspecialchars($row['findings']) : 'N/A';
$location = isset($row['location']) ? htmlspecialchars($row['location']) : 'N/A';
$noappword = isset($row['NoAppword']) ? htmlspecialchars($row['NoAppword']): 'N/A'; 
$ownerrepresentative = isset($row['OwnerRepresentative']) ? htmlspecialchars($row['OwnerRepresentative']) : 'N/A';

$Director = isset($row['Director']) ? htmlspecialchars($row['Director']) : 'N/A';
$director_pos = isset($row['director_pos']) ? htmlspecialchars($row['director_pos']) : 'N/A';
$ChiefCDD = isset($row['ChiefCDD']) ? htmlspecialchars($row['ChiefCDD']) : 'N/A';
$ChiefCDDPos = isset($row['ChiefCDDPos']) ? htmlspecialchars($row['ChiefCDDPos']) : 'N/A';

$x = 50;
$x *= $noapplied;
$str = $applicant;
$str = strtoupper($str);
$str2 = $location;
$str2 = strtoupper($str2);
$str3 = $noappword;
$str3 = strtoupper($str3);

$areas = [];
$tcts = [];
$lotNumbers = []; // Store Lot Numbers
$totalArea = 0.0000; // Default total to 4 decimal places

if (!$row) {
    die("Error: No record found.");
}

// Loop through dynamically (up to $noapplied)
for ($i = 1; $i <= $noapplied; $i++) {
    $lotKey = "LotN" . $i;
    $tctKey = "TCT" . $i;
    $areaKey = "Area" . $i;

    // Validate Lot Number field
    $lotNumbers[] = !empty($row[$lotKey]) ? htmlspecialchars($row[$lotKey]) : "N/A";

    // Validate TCT field
    $tcts[] = !empty($row[$tctKey]) ? htmlspecialchars($row[$tctKey]) : "N/A";

    // Validate Area field
    if (is_numeric($row[$areaKey])) {
        $areaValue = floatval($row[$areaKey]); // Convert to float
        $areas[] = $areaValue; // Store the value
        $totalArea += $areaValue; // Add to total
    } else {
        $areas[] = 0.0000; // Default if invalid
    }
}



// Dompdf options
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true); // Allow external images
$backgroundImage = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMB_Updated_HeaderFooter.png";
$backgroundImage2 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Header.png";
$backgroundImage3 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/NIPAS_Footer.png";
$dompdf = new Dompdf($options);

// Define HTML content with proper data
$html = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
    @page { 
            size: A4; 
            margin: 100px 0px 80px 0px;
    }
    body {
        line-height: 1.1;
        font-family: "Times New Roman", serif;
        font-size: 16px;
        padding: 0px 20px 100px 70px; 
        text-align: justify;    
    }
    .header-content {
        position: fixed;
        top: -100px; /* also relative to margin */
        left: 0;
        right: 0;
        height: 122px;
        background: url("' . $backgroundImage2 . '") no-repeat;
        background-size: cover;
    }
    .footer-content {
        position: fixed;
        bottom: -80px; /* also relative to margin */
        left: 0;
        right: 0;
        height: 100px;
        background: url("' . $backgroundImage3 . '") no-repeat;
        background-size: cover;
    }
    .content {
        padding-right:30px;
        font-size: 16px;
        line-height: 1.2;
        padding-left:20px;
        padding-top:5px;
    }
    .content2 {
        padding-right:30px;
        font-size: 16px;
        line-height: 1.2;
    }
    h2, h4 {
        text-align: center;
        font-weight: bold;
    }
    .signature {
        text-align: center;
        margin-top: 40px;
        margin-right: 230px;
    }
    .underline {
        border-bottom: 1px solid black;
        display: inline-block;
        width: 85px;
    }
    .marginTop{
        margin-top:-20px;
    }
    .approved-section2 {
        text-align: center;
        line-height: 0.9;
        display: flex;
        align-items: flex-end; /* Aligns content to the right */
        flex-direction: column;
         /* Ensures text is aligned to the right */
        margin-left: 285px; /* Adjust as needed */
    }
    span {
        content: "\20B1";
    }
    .marginLow{
        text-align:center;
        margin-top:-20px;
    }
    .marginLow2{
        text-align:center;
        margin-top:-20px;
        margin-bottom:-3px;
    }    
    .PuntaRight{
        text-align:right;
        margin-bottom:-20px;
    }
    </style>
</head>
<body>
    <div class="header-content" style="background-color: red;"></div>
    <div class="footer-content" style="background-color: blue;"></div>
    <div class="content" style="margin-top:30px; margin-left:20px; margin-right:30px;">
        <p></p> 
        <p> <strong>MEMORANDUM</strong></p>
    <table style="width:100%">
        <tr style="height:50px;">
        <td> <strong>  FOR <p style="margin-top:-10px;"></p></td>
        <td style="color:white;"> ---</td>
        <td><strong> :  </strong><p style="margin-top:-5px;"></p></strong> </td>
        <td> The Chief, Finance Division <p style="margin-top:-10px;"></p></td>
        </tr>
        <tr>
        <td> <strong>  FROM <p style="margin-top:-10px;"></p></td>
        <td style="color:white;"> ---</td>
        <td><strong> : </strong><p style="margin-top:-5px;"></p> </strong> </td>
        <td> The OIC, Conversation and Development Division <p style="margin-top:-6px;"></p> </td>
        </tr>
        <tr>
        <td> <strong> SUBJECT <p></p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td style="color:white;"> ---</td>
        <td><strong> : </strong><p></p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </strong> </td>
        <td style="text-align: Justify;">  <strong> CERTIFICATION FEE FOR '.$str3. ' (' .$noapplied.') PARCELS OF LAND FOR NIPAS CERFICATION BY '.$str.' COVERING AN AGGREGATE 
        AREA OF '. number_format($totalArea/10000, 4) . ' HECTARES LOCATED AT '.$str2.'  </strong> </td>
        <p></p> </tr>
        <tr>
        <td> <strong>  DATE <p></p> </td>
        <td style="color:white;"> ---</td>
        <td><strong> : </strong><p></p> </strong> </td>
        <td> </td>
        </tr>
    </table>
        <p style="margin-top:-35px;"><strong>______________________________________________________________________</strong></p>
        <p style="text-indent:55px;">Pursuant to DAO No. 2022-10, may we request issuance of Order of Payment and Official Receipt as<strong> Certification Fee </strong>for the
        NIPAS Certification of '.$noappword.' (' .$noapplied.') parcels of land <strong>approximately '. number_format($totalArea/10000, 4) . ' hectares</strong> located in <strong>'.$location.'</strong> '.$ownerrepresentative.', amounting
         to <strong><span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>'.$x.'.00 only.</strong></p>
        <p style="text-align:center;"><u>PURPOSE OF PAYMENT</u></p>
        <table align="center">
        <tr>
        <td>Accreditation Fee &nbsp;&nbsp;&nbsp;</td>
        <td>(57-900)1998-99 &nbsp;&nbsp;&nbsp;</td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>____X____)</td>
        </tr>
        <tr>
        <td>Permit Fee</td>
        <td>(56-9-005)</td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>____X____)</td>
        </tr>
        <tr>
        <td>Filing Fee</td>
        <td>(56-9-005)</td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>____X____)</td>
        </tr>
        <tr>
        <td>PD 1586</td>
        <td>((84-323)</td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>____X____)</td>
        </tr>
        <tr>
        <td>pA/C Fee</td>
        <td>((56-114)</td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>____X____)</td>
        </tr>
        <tr>
        <td>Inspection Fee</td>
        <td>(10.00/head)</td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>____X____)</td>
        </tr>
        <tr>
        <td><strong>Certification Fee</strong></td>
        <td>(P50.00/lot)</td>
        <td><u><span style=" font-family: DejaVu Sans;">&#x20B1;</span>'.$x.'.00</u></td>
        </tr>
        <tr>
        <td></td>
        <td>(<span style="font-size:16px; font-family: DejaVu Sans;">&#x20B1;</span>50.00/lot x ' .$noapplied.')</td>
        <td></td>
        </tr>
        </table>
    <p></p>
    <p style="margin-top:-10px;">For your information and consideration</p>
    <p></p>
    <p></p>
    <p style="text-align:right;"><strong>'.$ChiefCDD.'</strong></p>
    </div>
</body>
</html>';

// Load HTML to Dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait'); // Set paper size
$dompdf->render(); // Render PDF

// Force file download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="NIPAS_Memorandum_' . $applicant . '.pdf"');
echo $dompdf->output();

exit;
?>
