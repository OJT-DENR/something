<?php
require 'vendor/autoload.php'; // Ensure Dompdf is installed
require 'db_connect.php'; // Database connection

use Dompdf\Dompdf;
use Dompdf\Options;

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate ID input
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No valid ID provided.");
}

$id = intval($_GET['id']); // Sanitize ID

// Fetch data from database
$query = "SELECT * FROM clearance WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$rest_riction = isset($row['rest_riction']) && !empty(trim($row['rest_riction'])) 
    ? nl2br($row['rest_riction']) 
    : '';

if (!empty($rest_riction)) {
    $html .= '
        <tr>
            <td colspan="2">
                <p>Further, the followings are the restrictions of this clearance:</p>
                <p>' . $rest_riction . '</p>
            </td>
        </tr>';
}

// Check if record exists
if ($result->num_rows == 0) {
    die("Error: No record found with ID " . $id);
}

$row = $result->fetch_assoc();

// Newly added database fields
$clearance_no = isset($row['clearance_no']) ? htmlspecialchars($row['clearance_no']) : 'N/A';
$nameofpa = isset($row['NameOfPA']) ? htmlspecialchars($row['NameOfPA']) : 'N/A';
$proponent = isset($row['proponent']) ? htmlspecialchars($row['proponent']) : 'N/A';
$Purpose = isset($row['Purpose']) ? htmlspecialchars($row['Purpose']) : 'N/A';
$Resolution_No = isset($row['Resolution_No']) ? htmlspecialchars($row['Resolution_No']) : 'N/A';
$Resolution_Title = isset($row['Resolution_Title']) ? htmlspecialchars($row['Resolution_Title']) : 'N/A';
$PAMB_Meeting_data = isset($row['PambMeetingDate']) ? htmlspecialchars($row['PambMeetingDate']) : 'N/A';
$Description_Title = isset($row['DescriptionTitle']) ? htmlspecialchars($row['DescriptionTitle']) : 'N/A';
$Des_cription = isset($row['Desc_ription']) ? htmlspecialchars($row['Desc_ription']) : 'N/A';
$Terms_Conditions = isset($row['TermsConditions']) ? nl2br(htmlspecialchars($row['TermsConditions'])) : 'N/A';
$rest_riction = isset($row['Restrictions']) ? nl2br($row['Restrictions']) : 'N/A';
$director_name = isset($row['DirectorName']) ? htmlspecialchars($row['DirectorName']) : 'N/A';
$DirectorRank = isset($row['DirectorRank']) ? htmlspecialchars($row['DirectorRank']) : 'N/A';
$position = isset($row['Position']) ? htmlspecialchars($row['Position']) : 'N/A';

// Dompdf options
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true); // Allow external images
$dompdf = new Dompdf($options);

// ✅ Background Image from GitHub
$backgroundImage = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI_BG.png";
$backgroundImage2 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI_Header2.png";
$backgroundImage3 = "https://raw.githubusercontent.com/OJT-DENR/images/refs/heads/main/PAMBI_FooterNew.png";

// PDF Content
$html = '
    <html>
    <head>
        <style>
        @page { 
            size: Folio; 
            margin: 100px 0px 80px 0px;        
        }
        .header-content {
            position: fixed;
            top: -90px; /* also relative to margin */
            left: 0;
            right: 0;
            height: 110px;
            background: url("' . $backgroundImage2 . '") no-repeat;
            background-size: cover;
        }
        .footer-content {
            position: fixed;
            bottom: -80px; /* also relative to margin */
            left: 0;
            right: 0;
            height: 100px;
            background: url("' . $backgroundImage3 . '") no-repeat;
            background-size: cover;
        }
        body { 
            line-height: 1.1;
            font-family: "Times New Roman", serif;
            font-size: 16px;
            text-align: justify;
            padding: 55px 90px 60px 105px;
            background-size: cover;
            margin-top:-5px;
            margin-left:-10px;
        }
        .container {
            text-align: justify;
            background: rgba(246, 2, 2, 0); /* Light background for readability */
            padding: 20px;
            border-radius: 10px;
        }
        .title {
            font-size:21.5px;
            margin-top:5px;
            text-align: center;
            font-weight: bold;
            margin-bottom:-16px;
        }
        .activity-box {
            border: 1px solid black;
            padding: 10px;                
            margin: 20px 0;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        button {
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="text"] {
            font-family: "Times New Roman", Times, serif;
            margin-top: 2px;
            text-align: center;
            background: rgba(246, 2, 2, 0);
            border: none;
            outline: none;
            font-weight: bold;
        }
        .approved-section {
            display: flex;
            flex-direction: column;
            align-items: flex-end; /* Aligns content to the right */
            text-align: right; /* Ensures text is aligned to the right */
            margin-right: 140px; /* Adjust as needed */
        } 
        .approved-section2 {
            text-indent: 55px;
            line-height: 0.9;
            display: flex;
            align-items: flex-end; /* Aligns content to the right */
            flex-direction: column;
            text-align: left; /* Ensures text is aligned to the right */
            margin-left: 285px; /* Adjust as needed */
        } 
        .approved-section3 {
            line-height: 0.1;
        } 
        </style>
    </head>
    <body>
     
        <div class="header-content" style="background-color: red;"></div>
        <div class="footer-content" style="background-color: blue;"></div>

        <div class="content">
            <div>    
                <p class="title">PAMB CLEARANCE </p>
                <p style="text-align:center;"><strong> PP' . $clearance_no . ' </strong></p>
                <p style="margin-top:-5px;"></p>
            </div>   
            <p style="text-indent:40px; text-align:justify;"> After a thorough review and evaluation of the submitted documents from the 
                Protected Area Management Office of ' . $nameofpa . ', this <strong>PAMB Clearance</strong>  is
                hereby issued to <strong>'.$proponent.'</strong>  for the '.$Purpose.' as endorsed through <strong>'.$Resolution_No.'</strong> 
                 entitled <i>"'.$Resolution_Title. '"</i> passed during the '.$PAMB_Meeting_data.' through the Department of Environmental and Natural Resources
                 CALABARZON Region.
            </p>
            <p style="text-indent:50px; margin-bottom:-10px;">This PAMB Clearance is issued with the following details:</p>        
            <div class="activity-box">
                <p></p>
                <p style="text-align:center; margin-top:-20px;"><strong>'.$Description_Title.' DESCRIPTION</strong></p>                
                <p style="text-indent:62px; margin-bottom:5px;">' . $Des_cription. '</p>
            </div>
                <p style="text-indent:40px; margin-top:-5px;">This Clearance is issued pursuant to the provisions of Republic Act No. 7586, or National Integrated Protected Area System 
                    (NIPAS) Act of 1992, as amended by Republic Act No. 11038, or Expanded National Integrated Protected Area System (ENlPAS) 
                    Act of 2018 and its Implementing Rules and Regulations (IRR) stipulated in DAO No. 2019-05 subject to compliance with other 
                    mandatory requirements of other concerned agencies and/or offices such as, but not limited to, the following: 
                </p>
            <div style="margin-left:0px; text-align:justify;">'.$Terms_Conditions.'</div>
                '. (!empty($row['Restrictions']) ? '
                <p style="text-indent:20px;">Further, the followings are the restrictions of this clearance:</p>
                <div style="margin-left:18px;">'. nl2br(htmlspecialchars($row['Restrictions'])) .'</div>
            ' : '') .'
                <p style="text-indent:33px;">
                    Issued at Department of Environment and Natural Resources IV-A (CALABARZON)
                    Office, Mayapa Main Road (along SLEX), Brgy. Mayapa, Calamba City, Province of Laguna,
                    <br>this ______________________.<br><br><br>
                </p>
                <p class="approved-section">Approved:</p><br>
                <table style="border:1px solid white; border-collapse: collapse;">
                    <tr style="border:1px solid white;">
                    <td style="border:1px solid white; width:250px;"></td>
                    <td style="border:1px solid white; text-align:center;"> <strong>'.$director_name.'</strong>, <i>'.$DirectorRank.'</i></td>
                    <td style="border:1px solid white;"></td>
                    </tr>
                    <tr style="border:1px solid white;">
                    <td style="border:1px solid white;"></td>
                    <td style="border:1px solid white; text-align:center; width:400px;">'.$position.'</td>
                    <td style="border:1px solid white;"></td>
                    </tr>
                </table>
                
    </body>
</html>
        ';

        // Create PDF
$dompdf->loadHtml($html);
$dompdf->setPaper('Folio', 'portrait'); // Set paper size
$dompdf->render(); // Render PDF
        
        // Force file download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="PAMB_Clearance_' . $proponent . '.pdf"');
echo $dompdf->output();
        
exit;
?>