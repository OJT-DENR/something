<?php
require 'vendor/autoload.php'; // Load Dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

// Database Connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "nipas_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get and sanitize filter parameters
$search = isset($_GET['search']) ? $conn->real_escape_string(trim($_GET['search'])) : '';
$filter = isset($_GET['filter']) ? trim($_GET['filter']) : 'all';
$allowed_columns = ['all', 'DATS', 'actioned', 'Location', 'Applicant', 'ControlNumber', 'Findings', 'Company', 'Purpose' , 'DateRecieved'];

// Build the filtered query
$query = "SELECT * FROM nipas_table";

if (!empty($search)) {
    if ($filter === 'all') {
        $searchable_columns = ['DATS', 'actioned', 'Location', 'Applicant', 'ControlNumber', 'Findings', 'Company', 'Purpose' , 'DateRecieved'];
        $conditions = [];
        foreach ($searchable_columns as $col) {
            $conditions[] = "`$col` LIKE '%$search%'";
        }
        $query .= " WHERE " . implode(" OR ", $conditions);
    } elseif (in_array($filter, $allowed_columns)) {
        $query .= " WHERE `$filter` LIKE '%$search%'";
    }
}

// Optional: Debug query
// echo "<pre>$query</pre>";

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    // Initialize Dompdf
    $options = new Options();
    $options->set('defaultFont', 'Arial');
    $dompdf = new Dompdf($options);

    // Start HTML content for the PDF
    $html = "
    <h2 style='text-align: center;'>Filtered NIPAS Certifications</h2>
    <table border='1' cellspacing='0' cellpadding='3' width='100%'>
        <tr>
            <th>Control Number</th>
            <th>Applicant</th>
            <th>No. of Applied Lots</th>
            <th>Total Area</th>
            <th>Province</th>
            <th>Location</th>
            <th>Findings</th>
            <th>Date Approved</th>
            <th>DateReleased</th>
        </tr>";

    // Add rows
    while ($row = $result->fetch_assoc()) {
        $html .= "
        <tr>
            <td>{$row['ControlNumber']}</td>
            <td>{$row['applicant']}</td>
            <td>{$row['NoApplied']}</td>
            <td>{$row['total']}</td>
            <td>{$row['province']}</td>
            <td>{$row['location']}</td>
            <td>{$row['findings']}</td>
            <td>{$row['DateApproved']}</td>
            <td>{$row['DateReleased']}</td>
        </tr>";
    }

    $html .= "</table>";

    // Load HTML and render PDF
    $dompdf->loadHtml($html);
    $dompdf->setPaper('Tabloid', 'landscape');
    $dompdf->render();

    // Output PDF
    $dompdf->stream("Filtered_NIPAS_Records.pdf", ["Attachment" => 1]);
} else {
    echo "No matching records found for your search.";
}

$conn->close();
?>