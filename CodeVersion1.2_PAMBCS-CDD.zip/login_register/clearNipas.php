<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "nipas_db";
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Delete all data from the table
$delete_sql = "DELETE FROM nipas_table";
if (!$conn->query($delete_sql)) {
    die("Error deleting records: " . $conn->error);
}

// ✅ Reset the ID counter (Auto Increment)
$reset_sql = "ALTER TABLE nipas_table AUTO_INCREMENT = 1";
if (!$conn->query($reset_sql)) {
    die("Error resetting ID: " . $conn->error);
}

$conn->close();

// ✅ Redirect back to the main page
echo "<script>alert('All records deleted, and ID reset to 1.'); window.location.href='updatenipas_admin.php';</script>";
?>
