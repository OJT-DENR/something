<?php
// Database Connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "clearance_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle filter from POST
$search = isset($_POST['search']) ? $conn->real_escape_string($_POST['search']) : '';
$filter = isset($_POST['filter']) ? $_POST['filter'] : 'all'; // Default filter is 'all'

// Base query
$query = "SELECT * FROM clearance";

// Apply search and filter if provided
if (!empty($search)) {
    if ($filter === 'all') {
        // Search in all columns
        $query = "SELECT * FROM clearance WHERE 
          id LIKE '%$search%' OR 
            proponent LIKE '%$search%' OR 
            Resolution_Title LIKE '%$search%' OR 
            Resolution_No LIKE '%$search%' OR 
            PambMeetingDate LIKE '%$search%' OR
            DateReleased LIKE '%$search%' OR
            clearance_no LIKE '%$search%'";
    } elseif (in_array($filter, ['id', 'proponent', 'Resolution_Title', 'Resolution_No', 'PambMeetingDate', 'DateReleased','clearance_no'])) {
        // Search in specific column based on the filter
        $query = "SELECT * FROM clearance WHERE `$filter` LIKE '%$search%'";
    }
}

$result = $conn->query($query);

// Check if records exist
if ($result->num_rows > 0) {
    // Set headers for the CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="PAMB_Clearance_Records.csv"');

    // Open output stream for writing
    $output = fopen('php://output', 'w');

    // Write header row to the CSV
    $header = [
        'Clearance No.',
        'Name of PA',
        'Proponent',
        'Purpose',
        'Resolution No.',
        'Resolution Title',
        'PAMB Meeting Date',
        'Description Title',
        'Description',
        'Terms and Conditions',
        'Date Released',
        'Restrictions'
    ];
    fputcsv($output, $header);

    // Fetch and write data rows to the CSV
    while ($row = $result->fetch_assoc()) {
        $data = [
            $row['clearance_no'],
            $row['NameOfPA'],
            $row['proponent'],
            $row['Purpose'],
            $row['Resolution_No'],
            $row['Resolution_Title'],
            $row['PambMeetingDate'],
            $row['DescriptionTitle'],
            $row['Desc_ription'],
            $row['TermsConditions'],
            $row['DateReleased'],
            $row['Restrictions']
        ];
        fputcsv($output, $data);
    }

    // Close the file stream
    fclose($output);
} else {
    echo "No matching records found.";
}

$conn->close();
?>
